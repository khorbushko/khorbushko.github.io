//
//  ContentView.swift
//  swiftUILayout
//
//  Created by Kyryl Horbushko on 12/18/20.
//

import SwiftUI

struct MeasurementBehavior<Content: View>: View {
    @State private var width: CGFloat = 100
    @State private var height: CGFloat = 100
    
    var content: Content
    
    var body: some View {
        VStack {
            content
                .border(Color.red)
                .frame(width: width, height: height)
                .border(Color.black)
            Slider(value: $width, in: 0...500)
            Slider(value: $height, in: 0...500)
        }
    }
}


struct TriangleShape: Shape {
    
    func path(in rect: CGRect) -> Path {
        Path { p in
            p.move(to: CGPoint(x: rect.maxX / 2, y: 0))
            p.addLines([
                CGPoint(x: rect.maxX, y: rect.maxY),
                CGPoint(x: rect.minX, y: rect.maxY),
                CGPoint(x: rect.maxX / 2, y: rect.minY)
            ])
        }
    }
}



struct ContentView: View {
    var body: some View {
        MeasurementBehavior(content:
//                                TriangleShape()
//            Text("Hello")
                                HStack(alignment: .myCenter) {
                                    Circle().frame(width: 6, height: 6)
                                        .foregroundColor(.blue)
                                        .visualizeCenter()

            Image(systemName: "phone")
                .border(Color.black)
                .visualizeCenter()

                                    Text("Hello")
                                        .frame(height: 100)
                                        .background(Color.yellow)
                                        .alignmentGuide(.myCenter, computeValue: { dimension in
                                            dimension[.myCenter] - 10
                                        })
                                        .visualizeCenter()
//                                    Text("Hello")
                                }
                            
        )
    }
}

extension View {
    func visualizeCenter() -> some View {
        overlay(
        Circle()
            .fill(Color.blue)
            .frame(width: 6, height: 6)
        )
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


enum AlignmentVal: AlignmentID {
    static func defaultValue(in context: ViewDimensions) -> CGFloat {
        context.height * 0.5
    }
}

extension VerticalAlignment {
    
    static let myCenter: VerticalAlignment = VerticalAlignment(AlignmentVal.self)
}

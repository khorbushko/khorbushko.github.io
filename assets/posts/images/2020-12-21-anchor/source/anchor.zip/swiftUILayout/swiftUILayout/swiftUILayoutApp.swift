//
//  swiftUILayoutApp.swift
//  swiftUILayout
//
//  Created by Kyryl Horbushko on 12/18/20.
//

import SwiftUI

@main
struct swiftUILayoutApp: App {
    var body: some Scene {
        WindowGroup {
            AnchorView()
        }
    }
}

//
//  AnchorView.swift
//  swiftUILayout
//
//  Created by Kyryl Horbushko on 12/18/20.
//

import SwiftUI

struct AnchorValue {
    
    let rectAnchor: Anchor<CGRect>
    let color: Color
}

struct ButtonView: View {
    
    enum Alignment {
        
        case left
        case center
        case right
    }
    
    let text: String
    let rectColor: Color
    let position: Int
    let alignment: ButtonView.Alignment
    @Binding var selectedIndex: Int
    
    var body: some View {
        HStack {
            
            if alignment != .left {
                Spacer()
            }
            
            Button(action: {
                selectedIndex = position
            }, label: {
                Text(text)
            })
            .padding()
            .captureColoredTextBounds(selectedIndex == position, color: rectColor)
            if alignment != .right {
                Spacer()
            }
        }
    }
}

struct AnchorView: View {
    
    @State private var selectedItemIndex: Int = 0
    
    var body: some View {
        VStack {
            ButtonView(
                text: "Hi",
                rectColor: .red,
                position: 0,
                alignment: .left,
                selectedIndex: $selectedItemIndex
            )
            ButtonView(
                text: "Hello",
                rectColor: .green,
                position: 1,
                alignment: .center,
                selectedIndex: $selectedItemIndex
            )
            ButtonView(
                text: "Aloha",
                rectColor: .blue,
                position: 2,
                alignment: .right,
                selectedIndex: $selectedItemIndex
            )
//            HStack {
//                Button(action: {
//                    selectedItemIndex = 0
//                }, label: {
//                    Text("Hi")
//                })
//                .padding()
//                .captureBounds(selectedItemIndex == 0)
//                Spacer()
//            }
//            HStack {
//                Spacer()
//                Button(action: {
//                    selectedItemIndex = 1
//                }, label: {
//                    Text("Hello")
//                })
//                .captureBounds(selectedItemIndex == 1)
//                Spacer()
//            }
//            HStack {
//                Spacer()
//                Button(action: {
//                    selectedItemIndex = 2
//                }, label: {
//                    Text("Aloha")
//                })
//                .padding()
//                .captureBounds(selectedItemIndex == 2)
//            }
        }
        .padding(32)
//        .overlayPreferenceValue(TextBoundsKey.self, { value in
//            GeometryReader { geometryProxy in
//                if let value = value {
//                    RoundedRectangle(cornerRadius: 3)
//                        .stroke(style: StrokeStyle(lineWidth: 2, lineCap: .round, dash: [1, 2], dashPhase: 0.5))
//                        .frame(width: geometryProxy[value].size.width, height: geometryProxy[value].size.height)
//                        .offset(x: geometryProxy[value].minX, y: geometryProxy[value].minY)
//                        .animation(.easeIn)
//                }
//            }
//        })
        .overlayPreferenceValue(ColoredTextBoundsKey.self, { value in
            GeometryReader { geometryProxy in
                if let value = value {
                        RoundedRectangle(cornerRadius: 3)
                            .stroke(style: StrokeStyle(lineWidth: 2, lineCap: .round, dash: [1, 2], dashPhase: 0.5))
                            .foregroundColor(value.color)
                            .frame(width: geometryProxy[value.rectAnchor].size.width, height: geometryProxy[value.rectAnchor].size.height)
                            .offset(x: geometryProxy[value.rectAnchor].minX, y: geometryProxy[value.rectAnchor].minY)
                            .animation(.easeOut)

                }
            }
        })
    }
}

struct AnchorView_Previews: PreviewProvider {
    static var previews: some View {
        AnchorView()
    }
}

struct TextBoundsKey: PreferenceKey {
    static var defaultValue: Anchor<CGRect>? = nil
    
    static func reduce(value: inout Anchor<CGRect>?, nextValue: () -> Anchor<CGRect>?) {
        value = value ?? nextValue()
    }
}

extension View {
    func captureBounds(_ shouldCaptureAnchor: Bool) -> some View {
        anchorPreference(
            key: TextBoundsKey.self,
            value: .bounds,
            transform: { anchor in
                shouldCaptureAnchor ? anchor : nil
            }
        )
    }
}

// custom data

struct ColoredTextBoundsKey: PreferenceKey {
    static var defaultValue: AnchorValue? = nil
    
    static func reduce(value: inout AnchorValue?, nextValue: () -> AnchorValue?) {
        value = value ?? nextValue()
    }
}

extension View {
    func captureColoredTextBounds(_ shouldCaptureAnchor: Bool, color: Color) -> some View {
        anchorPreference(key: ColoredTextBoundsKey.self, value: .bounds, transform: { anchor in
            shouldCaptureAnchor ? AnchorValue(rectAnchor: anchor, color: color) : nil
        })
    }
}

//
//  ViewController.h
//  entryPoint-oBJC
//
//  Created by Kyryl Horbushko on 1/20/21.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


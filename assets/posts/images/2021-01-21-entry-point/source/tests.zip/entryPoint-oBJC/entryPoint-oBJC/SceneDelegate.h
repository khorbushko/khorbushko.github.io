//
//  SceneDelegate.h
//  entryPoint-oBJC
//
//  Created by Kyryl Horbushko on 1/20/21.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end


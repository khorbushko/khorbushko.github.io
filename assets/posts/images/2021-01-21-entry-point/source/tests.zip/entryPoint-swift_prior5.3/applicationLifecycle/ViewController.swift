//
//  ViewController.swift
//  applicationLifecycle
//
//  Created by Kyryl Horbushko on 8/14/19.
//  Copyright © 2019 - present. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

}

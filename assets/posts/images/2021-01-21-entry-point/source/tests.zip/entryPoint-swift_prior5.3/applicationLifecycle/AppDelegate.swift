//
//  AppDelegate.swift
//  applicationLifecycle
//
//  Created by Kyryl Horbushko on 8/14/19.
//  Copyright © 2019 - present. All rights reserved.
//


import UIKit

class MyApplication: UIApplication {

  override func open(_ url: URL, options: [UIApplication.OpenExternalURLOptionsKey : Any] = [:], completionHandler completion: ((Bool) -> Void)? = nil) {
    if let host = url.host, host.contains("hackingwithswift.com") {
      super.open(url, options: options, completionHandler: completion)
    } else {
      completion?(false)
    }
  }

  override func canOpenURL(_ url: URL) -> Bool {

    print("MyApplication - inside can open")
    return super.canOpenURL(url)
  }
}

//@UIApplicationMain // uncomment if you don't want to use subclass UIApplication
class AppDelegate: UIResponder, UIApplicationDelegate {

  var window: UIWindow?

  // MARK: - LifeCycle

  func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
    print("AppDelegate - didFinishLaunchingWithOptions")

    let canOpen = application.canOpenURL(URL(string: "http://google.com")!)
    application.open(URL(string: "http://google.com")!, options: [:], completionHandler: nil)
    print("AppDelegate - canOpen -\(canOpen)")
    return true
  }

  func applicationWillResignActive(_ application: UIApplication) {
    print("AppDelegate - applicationWillResignActive")
  }

  func applicationDidEnterBackground(_ application: UIApplication) {
    print("AppDelegate - applicationDidEnterBackground")
  }

  func applicationWillEnterForeground(_ application: UIApplication) {
    print("AppDelegate - applicationWillEnterForeground")
  }

  func applicationDidBecomeActive(_ application: UIApplication) {
    print("AppDelegate - applicationDidBecomeActive")
  }

  func applicationWillTerminate(_ application: UIApplication) {
    print("AppDelegate - applicationWillTerminate")
  }
}

// swift-tools-version: 6.0

import PackageDescription

let package = Package(
  name: "RSACrypto",
  products: [
    .library(
      name: "RSACrypto",
      targets: ["RSACrypto"]
    ),
  ],
  targets: [
    .target(
      name: "RSACrypto"
    ),
    .testTarget(
      name: "RSACryptoTests",
      dependencies: ["RSACrypto"]
    ),
  ]
)

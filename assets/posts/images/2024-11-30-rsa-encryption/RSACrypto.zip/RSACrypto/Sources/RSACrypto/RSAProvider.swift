import Foundation
import Security

///
/// Represent a wrapper under RSA encryption
///
/// RSA is a public-key cryptosystem, one of the oldest widely used for secure data transmission. The initialism "RSA" comes from the surnames of Ron Rivest, Adi Shamir and Leonard Adleman, who publicly described the algorithm in 1977. An equivalent system was developed secretly in 1973 at Government Communications Headquarters, the British signals intelligence agency, by the English mathematician Clifford Cocks. That system was declassified in 1997.
///
/// Example:
///
///     do {
///       let rsaProvider = try RSAProvider(identifier: "test3", keySize: .size4096)
///       let pair = try rsaProvider.obtainKeysPair()
///
///       let message = "hello 1.2.3"
///       let cryptor = RSACryptor(keys: pair)
///       let msgEncryptedData = try cryptor.encrypt(plainTextInput: message)
///       let decryptedMsg = try cryptor.decrypt(encryptedData: msgEncryptedData)
///
///       print("public key - \(try pair.publicKeyString())")
///       print("private key - \(try pair.privateKeyString())")
///       print("message to encrypt - \(message)")
///       print("msgEncryptedData - \(msgEncryptedData.base64EncodedString())")
///       print("decrypted info - \(decryptedMsg)")
///     } catch {
///       print("failure - \(error)")
///     }
///
///  RSA is asymmetric – information encrypted by the public
///  key remains encrypted until unlocked by the private key.
///  This one-way nature gives RSA encryption its core security advantage.
///
///  Pros
///
///  - Extremely secure against attacks when large key sizes used
///  - Verified real-world implementation over decades
///  - Performance improvements allow much faster encryption/decryption
///  - Scales well for securing vast amounts of data
///
///  Cons
///
///  - Vulnerable if poor random number generators used in keys
///  - Can have encryption/decryption speed issues with very small
///  - devices or extremely limited processors
///  - Potential quantum computing advances could eventually threaten security
///
///
/// https://www.historytools.org/concepts/rsa-encryption
/// https://developer.apple.com/documentation/security/storing-keys-as-data
///
public struct RSAProvider {
  public enum RSAProviderFailure: Error {
    case invalidIdentifierForKey
    case keyGenerationFailed(Error)
    case noStoredKeysFound
  }

  ///
  /// rsa key size in bits, reccomended are: 512, 768, 1024, 2048
  ///
  public enum RSAKeySize: Int {
    case size512 = 512
    case size768 = 768
    case size1024 = 1024
    case size2048 = 2048
    case size4096 = 4096
  }

  ///
  /// Key type for RSA
  ///
  public enum KeyType {
    ///
    /// Public Key:
    ///
    /// Available openly, as the name implies
    /// Used by the sender to encrypt messages before transmission
    /// Information encrypted with the public key can only be
    /// decrypted by the private key
    ///
    case `public`

    /// Private Key:
    ///
    /// Kept secret by the recipient
    /// The only key able to decrypt messages encrypted with the public key
    /// If lost or compromised, encrypted messages cannot be unlocked
    ///
    case `private`
  }

  public let keySize: Self.RSAKeySize
  private let privateKeyTag: Data
  private let publicKeyTag: Data

  public init(
    identifier: String,
    keySize: Self.RSAKeySize
  ) throws {
    if let privateKeyTag = (identifier + ".private").data(using: .utf8),
       let publicKeyTag = (identifier + ".public").data(using: .utf8) {
      self.privateKeyTag = privateKeyTag
      self.publicKeyTag = publicKeyTag
      self.keySize = keySize
    } else {
      throw RSAProviderFailure.invalidIdentifierForKey
    }
  }

  public func obtainKeysPair() throws -> RSAKeyModel {
    if let pair = try? retriveStoredKeysPair() {
      return pair
    } else {
      return try generateNewPairKeys()
    }
  }

  private func keyTagFor(keyType: KeyType) -> Data {
    switch keyType {
      case .private:
        return privateKeyTag
      case .public:
        return publicKeyTag
    }
  }

  private func retriveStoredKeysPair() throws -> RSAKeyModel {
    let publicKey = try retrieveKeyFromKeychain(keyType: .public)
    let privateKey = try retrieveKeyFromKeychain(keyType: .private)
    return .init(publicKey: publicKey, privateKey: privateKey)
  }

  private func generateNewPairKeys() throws -> RSAKeyModel {
    let publicKeyAttr: CFDictionary = [
      kSecAttrIsPermanent:true,
      kSecAttrApplicationTag: publicKeyTag,
      kSecClass: kSecClassKey,
      kSecReturnData: kCFBooleanTrue ?? true
    ] as CFDictionary

    let privateKeyAttr: CFDictionary = [
      kSecAttrIsPermanent:true,
      kSecAttrApplicationTag: privateKeyTag,
      kSecClass: kSecClassKey,
      kSecReturnData: kCFBooleanTrue ?? true
    ] as CFDictionary

    let parameters: CFDictionary = [
      kSecAttrKeyType: kSecAttrKeyTypeRSA,
      kSecAttrKeySizeInBits: keySize.rawValue,
      kSecPublicKeyAttrs: publicKeyAttr,
      kSecPrivateKeyAttrs: privateKeyAttr
    ] as CFDictionary

    var error: UnsafeMutablePointer<Unmanaged<CFError>?>?
    error = nil //silence warn
    guard let privateKey = SecKeyCreateRandomKey(parameters, error),
          let publicKey = SecKeyCopyPublicKey(privateKey) else {
      throw RSAProviderFailure.keyGenerationFailed(error as! Error)
    }

    return RSAKeyModel(publicKey: publicKey, privateKey: privateKey)
  }

  private func retrieveKeyFromKeychain(keyType: KeyType) throws -> SecKey {
    let query: CFDictionary = [
      kSecClass: kSecClassKey,
      kSecAttrApplicationTag: keyTagFor(keyType: keyType),
      kSecAttrKeyType: kSecAttrKeyTypeRSA,
      kSecReturnRef: kCFBooleanTrue ?? true
    ] as CFDictionary

    var item: CFTypeRef?
    let status = SecItemCopyMatching(query, &item)
    guard status == errSecSuccess else {
      throw RSAProviderFailure.noStoredKeysFound
    }

    return item as! SecKey
  }
}


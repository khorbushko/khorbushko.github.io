//
//  SecKey+Convert.swift
//  RSACrypto
//
//  Created by Kyryl Horbushko on 11/28/24.
//

import Foundation

///
/// Convertion extentions
/// more https://developer.apple.com/documentation/security/storing-keys-as-data
///
extension SecKey {

  // MARK: SecKey+Convert

  func toData() throws -> Data {
    var error: Unmanaged<CFError>?
    guard let data = SecKeyCopyExternalRepresentation(self, &error) as? Data else {
      throw error!.takeRetainedValue() as Error
    }
    return data
  }

  func toBase64EncodedString() throws -> String {
    let data = try self.toData()
    return data.base64EncodedString()
  }
}

//
//  RSACryptor.swift
//  RSACrypto
//
//  Created by Kyryl Horbushko on 11/28/24.
//

import Foundation
import Security

public struct RSACryptor {
  public enum RSACryptorFailure: Error {
    case invalidInputData
    case keyIsNotSuitableForAlgoritm
    case processError(Error)
    case invalidDataForUTF8Decode
  }

  private let keys: RSAKeyModel

  // MARK: LifeCycle

  public init(keys: RSAKeyModel) {
    self.keys = keys
  }

  public func encrypt(plainTextInput: String) throws -> Data {
    guard let data = plainTextInput.data(using: .utf8) else {
      throw RSACryptorFailure.invalidInputData
    }

    let algorithm: SecKeyAlgorithm = .rsaEncryptionOAEPSHA256

    guard SecKeyIsAlgorithmSupported(keys.publicKey, .encrypt, algorithm) else {
      throw RSACryptorFailure.keyIsNotSuitableForAlgoritm
    }
    var error: Unmanaged<CFError>?

    guard let cipherData = SecKeyCreateEncryptedData(
      keys.publicKey,
      algorithm,
      data as CFData,
      &error
    ) as Data? else {
      throw RSACryptorFailure.processError((error?.takeRetainedValue())!)
    }

    return cipherData
  }

  public func decrypt(encryptedData: Data) throws -> String {
    let algorithm: SecKeyAlgorithm = .rsaEncryptionOAEPSHA256

    guard SecKeyIsAlgorithmSupported(keys.privateKey, .decrypt, algorithm) else {
      throw RSACryptorFailure.keyIsNotSuitableForAlgoritm
    }
    var error: Unmanaged<CFError>?

    guard let clearData = SecKeyCreateDecryptedData(
      keys.privateKey,
      algorithm,
      encryptedData as CFData,
      &error
    ) as Data? else {
      throw RSACryptorFailure.processError((error?.takeRetainedValue())!)
    }

    if let value = String(data: clearData, encoding: .utf8) {
      return value
    } else {
      throw RSACryptorFailure.invalidDataForUTF8Decode
    }
  }
}


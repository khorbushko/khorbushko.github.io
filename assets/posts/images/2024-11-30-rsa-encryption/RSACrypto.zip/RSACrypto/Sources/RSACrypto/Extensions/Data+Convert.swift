//
//  Data+Convert.swift
//  RSACrypto
//
//  Created by Kyryl Horbushko on 11/28/24.
//

import Foundation

extension Data {

  // MARK: Data+Convert

  func toPublicSecKey() throws -> SecKey {
    let options: [CFString: Any] = [
      kSecAttrKeyType: kSecAttrKeyTypeRSA,
      kSecAttrKeyClass: kSecAttrKeyClassPublic
    ]
    var error: Unmanaged<CFError>?
    guard let key = SecKeyCreateWithData(
      self as CFData,
      options as CFDictionary,
      &error
    ) else {
      throw error!.takeRetainedValue() as Error
    }

    return key
  }

  func toPrivateSecKey() throws -> SecKey {
    let options: [CFString: Any] = [
      kSecAttrKeyType: kSecAttrKeyTypeRSA,
      kSecAttrKeyClass: kSecAttrKeyClassPrivate
    ]
    var error: Unmanaged<CFError>?
    guard let key = SecKeyCreateWithData(
      self as CFData,
      options as CFDictionary,
      &error
    ) else {
      throw error!.takeRetainedValue() as Error
    }

    return key
  }
}

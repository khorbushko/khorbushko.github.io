//
//  RSAKeyModel.swift
//  RSACrypto
//
//  Created by Kyryl Horbushko on 11/28/24.
//

import Foundation
import Security

///
/// Wrapper for keys mamaging for RSA with specified identifier
///
public struct RSAKeyModel {

  private(set) var publicKey: SecKey
  private(set) var privateKey: SecKey

  init(
    publicKey: SecKey,
    privateKey: SecKey
  ) {
    self.publicKey = publicKey
    self.privateKey = privateKey
  }

  public func publicKeyString() throws -> String {
    try publicKey.toBase64EncodedString()
  }

  public func privateKeyString() throws -> String {
    try privateKey.toBase64EncodedString()
  }

  public func publicKeyData() throws -> Data {
    try publicKey.toData()
  }

  public func privateKeyData() throws -> Data {
    try privateKey.toData()
  }
}

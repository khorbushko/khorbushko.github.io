import XCTest
@testable import RSACrypto

final class RSACryptoTests: XCTestCase {

  private enum Constants {
    static let publicKeyRaw = """
MIICCgKCAgEAk0bET+MazVbeZYQP14/yv3iGrDNb30EvtyCRZr+pqzTF0/dUt3yD0UHiQd3usFbmskCkyvCzUwpbQV0k3ADac/hkcDk7WK8733KTcKAQ1IJ+fjcAEPKwguyqHHi/6JlSQ4fsaHUQ9NqFyMEUJl9fFuXfi3Km9XCKZ8IuthfsoWWRRYMvscR52VJYRcXxaillupGjxnu4S3g7CovNvqnR8CM79pokcfAoTGge4/TLtO6lA10ARHoZCWUPr9tG9O5a4Soq+SoajDGx39y5Ip/8HHj1f0OMUucSC9gLlgNqusCPNLw42Avyf/QUa+bezObFYi7X5/jR7/ACqaD265FbROfQScVetq4jLKUPArypQzhI5eyTd5wIR0TjH41gvwG6X1Hnh+TfaoRkOl2EGNwTkoU2wdkYo6DK6Dm/6rqhwMEP4ezbA1J98VFeZq1auKyLQRmuH607GeanVDjM27hfG9Xqf5x+STPoNPvRQal25w/hFDsdDv8vaZf9N+w+ksg4YuLjOTGhd6hy6zQJ2Qi/HddNOlN8eFIHumNm/Ye/qLXRS/GjBrUJahqRiu+Hk/COyBjj4EklPtzrBn9Re4xmy+kDC6iRV4a/w/AXD5+z34I12hDm1/6lNovUkJ6tBDJuFjtYaDxImqQZ5Yqo++T9mGUaCxSUp6LVqtafiySPAk0CAwEAAQ==
"""
    static let privateKeyRaw = """
MIIJJwIBAAKCAgEAk0bET+MazVbeZYQP14/yv3iGrDNb30EvtyCRZr+pqzTF0/dUt3yD0UHiQd3usFbmskCkyvCzUwpbQV0k3ADac/hkcDk7WK8733KTcKAQ1IJ+fjcAEPKwguyqHHi/6JlSQ4fsaHUQ9NqFyMEUJl9fFuXfi3Km9XCKZ8IuthfsoWWRRYMvscR52VJYRcXxaillupGjxnu4S3g7CovNvqnR8CM79pokcfAoTGge4/TLtO6lA10ARHoZCWUPr9tG9O5a4Soq+SoajDGx39y5Ip/8HHj1f0OMUucSC9gLlgNqusCPNLw42Avyf/QUa+bezObFYi7X5/jR7/ACqaD265FbROfQScVetq4jLKUPArypQzhI5eyTd5wIR0TjH41gvwG6X1Hnh+TfaoRkOl2EGNwTkoU2wdkYo6DK6Dm/6rqhwMEP4ezbA1J98VFeZq1auKyLQRmuH607GeanVDjM27hfG9Xqf5x+STPoNPvRQal25w/hFDsdDv8vaZf9N+w+ksg4YuLjOTGhd6hy6zQJ2Qi/HddNOlN8eFIHumNm/Ye/qLXRS/GjBrUJahqRiu+Hk/COyBjj4EklPtzrBn9Re4xmy+kDC6iRV4a/w/AXD5+z34I12hDm1/6lNovUkJ6tBDJuFjtYaDxImqQZ5Yqo++T9mGUaCxSUp6LVqtafiySPAk0CAwEAAQKCAgADomMtSoAqkYp27Fmcuu1lWrLOFI1flsL37KqR48hq1GhOWQPi7ERveUX9VJ3zhY13WB+I74QpWC/UztjeQfoiEv7dgxgLEfXzB2eKh7SqndbDxBUxFeATtwXionsv4Pq19mh30m268RqMj/EwmjllPgJ0dT2YAHE16sWO0kvRVsmNMtXON/g+y+ioPiB9O2zKfBYTy5FKcXrZgYYv/o5S8/eil/6uvhuseQRMIUoWmq4BRX4AcpfkErWepBVd7XTaKhl54RdbHs3SJab+6v5EcJq0S4UutYuNNcVhbA+p8J8IEN4BPNg83pfTatTULxyvVdMXox0BJAXYzENToFhlcxKvJwCdGMy2OVWaJt6ENMXFapHjCftV9y2A1WodT8Z3hoNwr2SIfxOD5rodcpE0MSXJ76dvswW50gYuu0J6cS3zs3VxuV6bR5gFL88fTxALFXjpJDNGS//Z6ceWiGBWjkWMdbN9QHHfoTJd7t8lsj6xq26xeFZdsAIb23z960WwYClKZwEs2rOe59+FOXAYoRgBGFvojqMIM4uUcl7F0rMMxnUhFuRXhGjJ5yMEXNAiYFsgbRDxTVmfsDbIbtGHWKLyilOecLchJvO9O7cRb49B5f3ZeZBBEMehalk1VzU0zU6QJLgz3nGNfC+yXYBxWkdR1A2VFTORHcEoDbFbwQKCAQEAwoWJLBD51eKMlPjfwIzt3O810lXvclYogPvKFkYDqSUa2G0acDtxnldZbMoXX2hzwIeK8vOWPBJOTBr5NZ/D/Ldqsy25rDnFI4HRzgP8fDtBNkZBWXcOuY0YppfIMHnMrz5OHPwWq3nFPMyGwsYwZ2mdbudgxrLOzgW7n6S3KymHWd9TcsWOUHUkk4VKmpSsoGJig1IXDw7j+c2gyPPb7xF/3dnCAka2pSvrdwq4SZMrtZdVBs4bcKfW9i5LLNPv7C1cXdzv1ZulRk6WYJuGAOq5sahzjD9cp4SXlw+5UIZcpQ1LFts0lNPv57jjc0x2vDVrgjf/+oWI0j+Y06mXDQKCAQEAwdKw0bFyYaROiNAN77KU3atCHR7sqRAJPDYpgySW4HkzstNRRCsNvIk4wTxpdPedMGf4GuqL6n2pcOic678dtOOf4Zpr/TI449oBIe5wz9EGaloKE+hfWEsKXFkJ4W5cyVeWpci5fQ3Tf9wll7qOd/eTlkr8iA4cpiVA7IBO43EiZSzOY94cQSlUQtHeBNmVUJ5vwcKhwk4QiJR++/EWRLs171CP7IJKO5xsE6DAS179ObT5FZBr/mEEla/PNGe85XrBuqwNaWxSkg5o8xELU9UqOdjkXJiklMdLiyL7HadMSI2a3ZYlLQFZwkBNcOQqIgoVFcyWHwJmbZjDwxRIQQKCAQBz70q2LNf6li/bigkxpc0O5LNbTUSNDLTPS0JCzC/aW/cIDt63DXbGPKFbqYcMoiB7G03BR1S/MNnhmiH1x+bzdA3wBMyozTWl1/XHp7CQCnDvfCfuvnrUNDgA8m2qFq3btHKx671HLihT+EJJS/4FZHkkZFrVkjSXresJVw6kdvfopKYDvaL4aRkHo2W3g+zvGjREuGRt4R4XAGtX2Z+3eOKQwvxShvrMrsSECquTjld6v1s51xWbqyz/RNAhQ5+3T8HBX7DByyZSJPyTT54qZbuPGyri59C9NtVyfzifubT12lpqoPNR0I8nuJY3XddWjTAqSF4UXgoR5T2cyXLxAoIBAEWdmjrG5FFjxX1oVQkZ+FQh9e4ltFUI2HhS79gVpUdc4Q/CzLaSTC3Cj6sAOtRzN3cycK+iPLztg5V1Rx95ln7pHvzWDSF1D2/vVmbMkKJj7kz2qBX8aXp6AW+n31+j1xnOJuLG1LCw7Z1IAgycSh2Ww+DAcDGh9/JJASew8iTI9tSmIj9GgJl68bPKU1ckm3fIYFWUxarXhSK5S17MefYX08hwBDGrnmQIy9zE6SxpIsS+VpTDOba1PANTkTW+aN93luuobmzGJmYlXNao8Yubzb3XRDZp8PsrFdwUpWNCOqj4i345NoMSsB2QIQCCQwvU2TvqLqVWpFmK/A0uVMECggEAHERDhoyQbiWAVlc5lF2CSFN7KenUZh3Dr0mh+pmM0KXUdRz8esE7vO6R4nxpiUfzEyHEfdPGhg+SrOjr4qfp4/pR+ZYZyP8aBt7nt9fzV6kU1GqPK+L0U2hXI6ecPgQYvf30ATDt0BbHw3lkjsff5bzZVOMjKoGEEHvXmYaJP1gc8KK3YUuGUE0XVQtrf8L7rfzc7e4srvuE+gfMHYgCd2lo61H4+c2zgFd9Zy6DcoJm1NuNuIxP/FaEUdIZxx2u44N6VkTNgNUjAkCR0osz35zssVtKCEDUS3HB2ltx8khSUmAE1tSodH5V7yDwb6SjTZPbz/ZSAb7hROKkymQEMg==
"""
    static let msg = "hello 1.2.3"
  }

  func testDataToPublicSecKeyConvert() throws {
    // given
    let inputBase64String = Constants.publicKeyRaw
    // when
    let secKey = try Data(base64Encoded: inputBase64String)?.toPublicSecKey()

    // then
    XCTAssertNotNil(secKey)
  }

  func testDataToPrivateSecKeyConvert() throws {
    // given
    let inputBase64String = Constants.privateKeyRaw

    // when
    let secKey = try Data(base64Encoded: inputBase64String)?.toPrivateSecKey()

    // then
    XCTAssertNotNil(secKey)
  }

  func testEncryptData() throws {
    // given
    let keys = try createKeys()

    // when
    let encrypt = RSACryptor(keys: keys)
    let data = try encrypt.encrypt(plainTextInput: Constants.msg)

    // then
    XCTAssertNotNil(data)
  }

  func testDecryptData() throws {
    // given
    let keys = try createKeys()

    // when
    let encrypt = RSACryptor(keys: keys)
    let data = try encrypt.encrypt(plainTextInput: Constants.msg)
    let decrypt = try encrypt.decrypt(encryptedData: data)

    // then
    XCTAssert(decrypt == Constants.msg)
  }

  private func createKeys() throws -> RSAKeyModel {
    let privateKeySec = try Data(base64Encoded: Constants.privateKeyRaw)?.toPrivateSecKey()
    let publicKKeySec = try Data(base64Encoded: Constants.publicKeyRaw)?.toPublicSecKey()
    let model = RSAKeyModel(publicKey: publicKKeySec!, privateKey: privateKeySec!)
    return model
  }
}

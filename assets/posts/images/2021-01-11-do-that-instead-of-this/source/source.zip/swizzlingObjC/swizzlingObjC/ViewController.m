//
//  ViewController.m
//  swizzlingObjC
//
//  Created by Kyryl Horbushko on 1/9/21.
//

#import "ViewController.h"
#import <objc/runtime.h>
#import "SwizzleExampleClass.h"

@interface ViewController ()

@end

@implementation ViewController

// Invoked whenever a class or category is added to the Objective-C runtime;
// implement this method to perform class-specific behavior upon loading.

+ (void)load {
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        SEL viewDidLoadMethodSelector = @selector(viewDidLoad);
        SEL myViewDidLoadMethodSelector = @selector(myViewDidLoad);
        
        Method viewDidLoadMethod = class_getInstanceMethod(self, viewDidLoadMethodSelector);
        Method myViewDidLoadMethod = class_getInstanceMethod(self, myViewDidLoadMethodSelector);
        IMP myViewDidLoadIMP = method_getImplementation(myViewDidLoadMethod);
        IMP viewDidLoadIMP = method_getImplementation(viewDidLoadMethod);
        
        // “v16@0:8“ - encoded
        const char * myViewDidLoadEncoding = method_getTypeEncoding(myViewDidLoadMethod);
        const char * viewDidLoadEncoding = method_getTypeEncoding(viewDidLoadMethod);

        BOOL methodAdded = class_addMethod([self class],
                                           viewDidLoadMethodSelector,
                                           myViewDidLoadIMP,
                                           myViewDidLoadEncoding);

        if (methodAdded) {
            class_replaceMethod([self class],
                                myViewDidLoadMethodSelector,
                                viewDidLoadIMP,
                                viewDidLoadEncoding);
        } else {
            
            // This is an atomic version of the following:
            // IMP imp1 = method_getImplementation(m1);
            // IMP imp2 = method_getImplementation(m2);
            // method_setImplementation(m1, imp2);
            // method_setImplementation(m2, imp1);
            method_exchangeImplementations(viewDidLoadMethod, myViewDidLoadMethod);
        }
    });

}

- (void)viewDidLoad {
    [super viewDidLoad];

    NSLog(@"original viewDidLoad called");
}

- (void)myViewDidLoad {
    [self myViewDidLoad];
    NSLog(@"my viewDidLoad called");

// to test Bryce Buchanan's approach call this method
//    [self testSwizleExample];
}

- (void)testSwizleExample {
    SwizzleExampleClass* example = [[SwizzleExampleClass alloc] init];
    int originalReturn = [example originalMethod];
    [example swizzleExample];
    int swizzledReturn = [example originalMethod];
    assert(originalReturn == 1);
    assert(swizzledReturn == 2);
}

@end

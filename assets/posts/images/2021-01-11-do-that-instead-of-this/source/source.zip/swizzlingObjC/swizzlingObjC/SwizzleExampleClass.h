//
//  SwizzleExampleClass.h
//  swizzlingObjC
//
//  Created by Kyryl Horbushko on 1/10/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

    // from https://blog.newrelic.com/engineering/right-way-to-swizzle/#:~:text=Swizzling%20is%20the%20act%20of,with%20another%2C%20usually%20at%20runtime.
@interface SwizzleExampleClass : NSObject
- (void)swizzleExample;
- (int) originalMethod;
@end

NS_ASSUME_NONNULL_END

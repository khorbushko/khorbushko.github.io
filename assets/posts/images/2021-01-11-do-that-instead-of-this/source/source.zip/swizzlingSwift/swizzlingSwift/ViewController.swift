//
//  ViewController.swift
//  swizzlingSwift
//
//  Created by Kyryl Horbushko on 1/10/21.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("original viewDidLoad called")
        
        let classObj = NativeSwiftClass()
        classObj.original()
    }
}

// to test uncomment line in appDelegate
extension ViewController {
    
    @objc dynamic func myViewDidLoad() {
        myViewDidLoad()
        
        print("myViewDidLoad called")
    }
    
    private static let swizzleViewDidLoad: Void = {
        
        let viewDidLoadMethodSelector: Selector = #selector(ViewController.viewDidLoad)
        let myViewDidLoadMethodSelector: Selector = #selector(ViewController.myViewDidLoad)
        
        let viewDidLoadMethod: Method = class_getInstanceMethod(ViewController.self, viewDidLoadMethodSelector)!
        let myViewDidLoadMethod: Method = class_getInstanceMethod(ViewController.self, myViewDidLoadMethodSelector)!

        let myViewDidLoadIMP: IMP = method_getImplementation(myViewDidLoadMethod)
        let viewDidLoadIMP: IMP = method_getImplementation(viewDidLoadMethod)

        let myViewDidLoadEncoding: UnsafePointer<Int8> = method_getTypeEncoding(myViewDidLoadMethod)!
        let viewDidLoadEncoding: UnsafePointer<Int8> = method_getTypeEncoding(viewDidLoadMethod)!

        let methodAdded = class_addMethod(
            ViewController.self,
            viewDidLoadMethodSelector,
            myViewDidLoadIMP,
            myViewDidLoadEncoding
        )
        
        if methodAdded {
            class_replaceMethod(
                ViewController.self,
                myViewDidLoadMethodSelector,
                viewDidLoadIMP,
                viewDidLoadEncoding
            )
        } else {
            method_exchangeImplementations(viewDidLoadMethod, myViewDidLoadMethod)
        }
    }()
    
    static func execute_swizzleViewDidLoad() {
        _ = self.swizzleViewDidLoad
    }
}

class NativeSwiftClass {
    
    dynamic func original() {
        print("original")
    }
}

// -Xfrontend -enable-dynamic-replacement-chaining
extension NativeSwiftClass {
    @_dynamicReplacement(for: original)
    func replacement() {
        original()
        print("replacement")
    }
    
    @_dynamicReplacement(for: original)
    func replacement2() {
        original()
        print("replacement2")
    }
}

//
//  SceneDelegate.swift
//  swizzlingSwift
//
//  Created by Kyryl Horbushko on 1/10/21.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

}


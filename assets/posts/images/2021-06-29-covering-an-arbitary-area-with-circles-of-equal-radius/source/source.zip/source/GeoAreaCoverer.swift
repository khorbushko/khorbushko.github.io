//
//  GeoAreaCoverer.swift
//  testBoundingBoxMap
//
//  Created by Kyryl Horbushko on 23.06.2021.
//

import Foundation
import MapKit
import CoreLocation

public final class GeoAreaCoverer {
  public static func calculate_v1(
    for points: [CLLocationCoordinate2D],
    coverPolygonArea coverArea: Measurement<UnitArea>
  ) -> [CLLocationCoordinate2D] {
    
    let coverPolygonInMeters = coverArea.converted(to: .squareMeters)
    let polygonSideSizeInMeters: CLLocationDistance = coverPolygonInMeters.value.squareRoot()
    
    let bbox = GeoBoundingBox()
    bbox.appendPoints(points)
    
    let bottomLeft = bbox.southWestCorner
    let topRight = bbox.northEastCorner
    let bottomRight = bbox.southEastCorner
        
    let approxCirclePolygonRadius: CLLocationDegrees = polygonSideSizeInMeters.toDegree
    
    let latLimit = topRight.latitude + 2 * approxCirclePolygonRadius //vertical
    let longLimit = bottomRight.longitude + 2 * approxCirclePolygonRadius // horizontal
    
    let gridHeight = 2 * approxCirclePolygonRadius * 0.75
    
    var proposedCenters: [CLLocationCoordinate2D] = []
    
    var currentLong = bottomLeft.longitude
    var currentLat = bottomLeft.latitude
        
    while currentLat < latLimit {
      currentLong = bottomLeft.longitude
      
      while currentLong < longLimit {
        let centerPoint = CLLocationCoordinate2D(latitude: currentLat, longitude: currentLong)
        proposedCenters.append(centerPoint)
        currentLong += 2 * gridHeight
      }

      currentLat += 2 * gridHeight
    }
    
    currentLong = bottomLeft.longitude - gridHeight / 2.0
    currentLat = bottomLeft.latitude + gridHeight
    
    while currentLat < latLimit {
      currentLong = bottomLeft.longitude - gridHeight / 2.0
      
      while currentLong < longLimit {
        let centerPoint = CLLocationCoordinate2D(latitude: currentLat, longitude: currentLong)
        proposedCenters.append(centerPoint)
        currentLong += 2 * gridHeight
      }

      currentLat += 2 * gridHeight
    }
    
    let hull = CoordinatesConvexHull.convexHull(points)
    let polygon = MKPolygon(coordinates: hull, count: hull.count)
    let filtered = proposedCenters.filter({ polygon.contain(coordinate: $0) })
    
    return filtered
  }
  
  public enum Filter {
    case mkPolygon
    case any(PolygonFilter.Type)
    
    var instanceType: PolygonFilter.Type {
      switch self {
        case .mkPolygon:
          return MKPolygonFilter.self
        case .any(let returnType):
          return returnType
      }
    }
  }
  
  public static func coverage(
    for points: [CLLocationCoordinate2D],
    coverPolygonArea coverArea: Measurement<UnitArea>,
    filter: Filter = Filter.mkPolygon
  ) -> [CLLocationCoordinate2D] {
    
    let coverPolygonInMeters = coverArea.converted(to: .squareMeters)
    let polygonSideSizeInMeters: CLLocationDistance = coverPolygonInMeters.value.squareRoot()
    
    let bbox = GeoBoundingBox()
    bbox.appendPoints(points)
    
    let bottomLeft = bbox.southWestCorner
    let topRight = bbox.northEastCorner
    let bottomRight = bbox.southEastCorner
    
    var proposedCenters: [CLLocationCoordinate2D] = []
    
    var currentLong = bottomLeft.longitude
    let currentLat = bottomLeft.latitude
    
    var centerPoint = CLLocationCoordinate2D(latitude: currentLat, longitude: currentLong)
    proposedCenters.append(centerPoint)
    
    let offsetPoint = centerPoint.locationByAdding(
      distance: 1,
      bearing: CLLocationDegrees.Bearing.right.value
    )
    let deegreePerMeter = abs(offsetPoint.longitude - centerPoint.longitude)
    let degreeOffsetForCurrentArea = polygonSideSizeInMeters * deegreePerMeter
    let gridHeight = degreeOffsetForCurrentArea * 0.75
    
    let latLimit = topRight.latitude + gridHeight //vertical
    let longLimit = bottomRight.longitude + degreeOffsetForCurrentArea / 2 // horizontal

    var isEven = true
    while centerPoint.latitude < latLimit {
      while centerPoint.longitude < longLimit {
        centerPoint = centerPoint.locationByAdding(
          distance: polygonSideSizeInMeters,
          bearing: CLLocationDegrees.Bearing.right.value
        )
        proposedCenters.append(centerPoint)
      }
      
      centerPoint = centerPoint.locationByAdding(
        distance: polygonSideSizeInMeters * 0.75,
        bearing: CLLocationDegrees.Bearing.up.value
      )
      centerPoint.longitude = bottomLeft.longitude +
                              (isEven ? -degreeOffsetForCurrentArea / 2 : 0)
      proposedCenters.append(centerPoint)
      currentLong = centerPoint.longitude
      
      isEven.toggle()
    }
    
    let filtrator = filter.instanceType.init(polygonCoordinates: points)
    let filtered = proposedCenters.filter(filtrator.filter)

    return filtered
  }
}

public protocol PolygonFilter {
  init(polygonCoordinates: [CLLocationCoordinate2D])
  func filter(_ coordinate: CLLocationCoordinate2D) -> Bool
}

struct MKPolygonFilter: PolygonFilter {
  let polygonCoordinates: [CLLocationCoordinate2D]
  let polygon: MKPolygon
  
  init(
    polygonCoordinates: [CLLocationCoordinate2D]
  ) {
    self.polygonCoordinates = polygonCoordinates
    self.polygon = MKPolygon(coordinates: polygonCoordinates, count: polygonCoordinates.count)
  }

  func filter(_ coordinate: CLLocationCoordinate2D) -> Bool {
    polygon.contain(coordinate: coordinate)
  }
}

// for approach 1

extension CLLocationDistance {
  // Calculate approx! degree from distance
  //
  // L = 2prA/360
  //        where A = number of degrees
  //              r - earchRadius
  var toDegree: CLLocationDegrees {
    let earthRadiusInMeters = 6378137.0
    let oneDegreeToMeter = (2 * Double.pi * earthRadiusInMeters * 1) / 360.0
    let value: CLLocationDegrees = self / oneDegreeToMeter
    return value
  }
}

/// for final

extension MKPolygon {
  func contain(coordinate: CLLocationCoordinate2D) -> Bool {
    let polygonRenderer = MKPolygonRenderer(polygon: self)
    let currentMapPoint: MKMapPoint = MKMapPoint(coordinate)
    let polygonViewPoint: CGPoint = polygonRenderer.point(for: currentMapPoint)
    return polygonRenderer.path?.contains(polygonViewPoint) == true
  }
}

extension CLLocationCoordinate2D {
  
  func earthRadius() -> CLLocationDistance {
    let earthRadiusInMetersAtSeaLevel = 6378137.0
    let earthRadiusInMetersAtPole = 6356752.314
    
    let r1 = earthRadiusInMetersAtSeaLevel
    let r2 = earthRadiusInMetersAtPole
    let beta = latitude
    
    let earthRadiuseAtGivenLatitude = (
      ( pow(pow(r1, 2) * cos(beta), 2) + pow(pow(r2, 2) * sin(beta), 2) ) /
        ( pow(r1 * cos(beta), 2) + pow(r2 * sin(beta), 2) )
    )
    .squareRoot()
    
    return earthRadiuseAtGivenLatitude
  }
  
  func locationByAdding(
    distance: CLLocationDistance,
    bearing: CLLocationDegrees
  ) -> CLLocationCoordinate2D {
    let latitude = self.latitude
    let longitude = self.longitude
    
    let earthRadiusInMeters = self.earthRadius()
    let brng = bearing.degreesToRadians
    var lat = latitude.degreesToRadians
    var lon = longitude.degreesToRadians
    
    lat = asin(
      sin(lat) * cos(distance / earthRadiusInMeters) +
        cos(lat) * sin(distance / earthRadiusInMeters) * cos(brng)
    )
    lon += atan2(
      sin(brng) * sin(distance / earthRadiusInMeters) * cos(lat),
      cos(distance / earthRadiusInMeters) - sin(lat) * sin(lat)
    )
    
    let newCoordinate = CLLocationCoordinate2D(
      latitude: lat.radiansToDegrees,
      longitude: lon.radiansToDegrees
    )
    
    return newCoordinate
  }
}

extension FloatingPoint {
  var degreesToRadians: Self { self * .pi / 180 }
  var radiansToDegrees: Self { self * 180 / .pi }
}

extension CLLocationDegrees {
  enum Bearing {
    case up
    case right
    case down
    case left
    case any(CLLocationDegrees)
    
    var value: CLLocationDegrees {
      switch self {
        case .any(let bearingValue):
          return bearingValue
        case .down:
          return 180
        case .right:
          return 90
        case .left:
          return 270
        case .up:
          return 0
      }
    }
  }
}

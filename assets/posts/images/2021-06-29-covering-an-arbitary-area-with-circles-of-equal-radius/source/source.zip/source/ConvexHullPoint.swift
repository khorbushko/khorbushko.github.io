//
//  ConvexHullPoint.swift
//  testBoundingBoxMap
//
//  Created by Kyryl Horbushko on 24.06.2021.
//

import Foundation
import Foundation

protocol ConvexHullPoint: Equatable {
  var x: Double { get }
  var y: Double { get }
}

final class ConvexHull<T> where T: ConvexHullPoint {
  private enum Orientation {
    case straight
    case clockwise
    case counterClockwise
  }
  
  // MARK: - Public
  
  public func calculateConvexHull(fromPoints points: [T]) -> [T] {
    guard points.count >= 3 else {
      return points
    }
    
    var hull = [T]()
    let (leftPointIdx, _) = points.enumerated()
      .min(by: { $0.element.x < $1.element.x })!
    
    var p = leftPointIdx
    var q = 0
    
    repeat {
      hull.append(points[p])
      
      q = (p + 1) % points.count
      
      for i in 0..<points.count where
        calculateOrientation(points[p], points[i], points[q]) == .counterClockwise {
        q = i
      }
      
      p = q
    } while p != leftPointIdx
    
    return hull
  }
  
  // MARK: - Private
  
  private func calculateOrientation(_ p: T, _ q: T, _ r: T) -> Orientation {
    let val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y)
    
    if val == 0 {
      return .straight
    } else if val > 0 {
      return .clockwise
    } else {
      return .counterClockwise
    }
  }
}

import Foundation
import CoreLocation

public enum CoordinatesConvexHull {
  static public func convexHull(_ input: [CLLocationCoordinate2D]) -> [CLLocationCoordinate2D] {
    let sorter = ConvexHull<CLLocationCoordinate2D>()
    return sorter.calculateConvexHull(fromPoints: input)
  }
}

extension CLLocationCoordinate2D: ConvexHullPoint {
  
  public static func == (lhs: CLLocationCoordinate2D, rhs: CLLocationCoordinate2D) -> Bool {
    lhs.latitude == rhs.latitude && lhs.longitude == rhs.longitude
  }
  
  var x: Double {
    latitude
  }
  
  var y: Double {
    longitude
  }
}

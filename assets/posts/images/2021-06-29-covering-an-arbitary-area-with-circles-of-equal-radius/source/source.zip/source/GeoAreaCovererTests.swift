//
//  GeoAreaConverterTests.swift
//  testBoundingBoxMapTests
//
//  Created by Kyryl Horbushko on 24.06.2021.
//

import Foundation
import XCTest
import CoreLocation

@testable import testBoundingBoxMap

final class GeoAreaCovererTests: XCTestCase {
  private enum TestData {
    static let pointA_EU = CLLocationCoordinate2D(latitude: 49.819967602647196, longitude: 23.998182602364636)
    static let pointB_EU = CLLocationCoordinate2D(latitude: 49.8192744359698, longitude: 24.003368620577174)
    static let pointC_EU = CLLocationCoordinate2D(latitude: 49.816122858190475, longitude: 24.00141681398125)
    
    static let allPoints_EU = [
      pointA_EU,
      pointB_EU,
      pointC_EU
    ]
    
    static let pointA_SA = CLLocationCoordinate2D(latitude: 9.730453208085143, longitude: -63.14921344595039)
    static let pointB_SA = CLLocationCoordinate2D(latitude: 9.731037775004362, longitude: -63.14693669472848)
    static let pointC_SA = CLLocationCoordinate2D(latitude: 9.728822878186744, longitude: -63.1480497512132)
    
    static let allPoints_SA = [
      pointA_SA,
      pointB_SA,
      pointC_SA
    ]
    
    static let pointA_NA = CLLocationCoordinate2D(latitude: 77.66060550421251, longitude: -78.47139965067363)
    static let pointB_NA = CLLocationCoordinate2D(latitude: 77.6620674915279, longitude: -78.45796738687805)
    static let pointC_NA = CLLocationCoordinate2D(latitude: 77.65972008449927, longitude: -78.45752454395141)
    
    static let allPoints_NA = [
      pointA_NA,
      pointB_NA,
      pointC_NA
    ]

  }
  
  // MARK: - General
  
  func test_generationGeoAreaCoverer_forSmallArea() {
    let points = GeoAreaCoverer.coverage(
      for: [
        CLLocationCoordinate2D(latitude: 49.819539, longitude: 23.994114),
        CLLocationCoordinate2D(latitude: 49.819539, longitude: 23.994115),
        CLLocationCoordinate2D(latitude: 49.819639, longitude: 23.994114)
        ],
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    XCTAssertEqual(points.count, 1)
  }
  
  func test_generationGeoAreaCoverer_forOnePointArea() {
    let points = GeoAreaCoverer.coverage(
      for: [CLLocationCoordinate2D].init(repeating: TestData.pointA_EU, count: 3),
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    XCTAssertEqual(points.count, 1)
  }
  
  // MARK: - Region EU
  
  func test_generationGeoAreaCovererShouldProvideExpectedQtyOfPoints_EU() {
    let points = GeoAreaCoverer.coverage(
      for: TestData.allPoints_EU,
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    XCTAssertEqual(points.count, 10)
  }
  
  func test_generationGeoAreaCovererShouldProvideExpectedValueForPoints_EU() {
    let points = GeoAreaCoverer.coverage(
      for: TestData.allPoints_EU,
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    XCTAssertEqual(points[0].latitude.roundToDecimal(6), 49.816797)
    XCTAssertEqual(points[0].longitude.roundToDecimal(6), 24.001665)
    
    XCTAssertEqual(points[1].latitude.roundToDecimal(6), 49.817471)
    XCTAssertEqual(points[1].longitude.roundToDecimal(6), 24.000969)
    
    XCTAssertEqual(points[2].latitude.roundToDecimal(6), 49.818145)
    XCTAssertEqual(points[2].longitude.roundToDecimal(6), 24.000272)

    XCTAssertEqual(points[3].latitude.roundToDecimal(6), 49.818145)
    XCTAssertEqual(points[3].longitude.roundToDecimal(6), 24.001665)
    
    XCTAssertEqual(points[4].latitude.roundToDecimal(6), 49.818819)
    XCTAssertEqual(points[4].longitude.roundToDecimal(6), 23.999576)
    
    XCTAssertEqual(points[5].latitude.roundToDecimal(6), 49.818819)
    XCTAssertEqual(points[5].longitude.roundToDecimal(6), 24.000969)
    
    XCTAssertEqual(points[6].latitude.roundToDecimal(6), 49.818819)
    XCTAssertEqual(points[6].longitude.roundToDecimal(6), 24.002362)
    
    XCTAssertEqual(points[7].latitude.roundToDecimal(6), 49.819493)
    XCTAssertEqual(points[7].longitude.roundToDecimal(6), 23.998879)
    
    XCTAssertEqual(points[8].latitude.roundToDecimal(6), 49.819493)
    XCTAssertEqual(points[8].longitude.roundToDecimal(6), 24.000272)
    
    XCTAssertEqual(points[9].latitude.roundToDecimal(6), 49.819493)
    XCTAssertEqual(points[9].longitude.roundToDecimal(6), 24.001666)
  }
  
  func test_generationGeoAreaCovererShouldPlacePointsOnExpectedDistance_EU() {
    let area = Measurement<UnitArea>.init(value: 1, unit: .hectares)
    let points = GeoAreaCoverer.coverage(
      for: TestData.allPoints_EU,
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    let coverPolygonInMeters = area.converted(to: .squareMeters)
    let polygonSideSizeInMeters: CLLocationDistance = coverPolygonInMeters.value.squareRoot()
    let expectedDistance = polygonSideSizeInMeters
    
    func locationFrom(point: CLLocationCoordinate2D) -> CLLocation {
      .init(latitude: point.latitude, longitude: point.longitude)
    }
    
    // points on same location latitude
    let locationP1 = locationFrom(point: points[2])
    let locationP3 = locationFrom(point: points[3])
    let distanceP1_P3 = locationP1.distance(from: locationP3)
    
    XCTAssertEqual(Int(distanceP1_P3), Int(expectedDistance))
    
    let locationP4 = locationFrom(point: points[4])
    let locationP5 = locationFrom(point: points[5])
    let locationP6 = locationFrom(point: points[6])
    let distanceP4_P5 = locationP4.distance(from: locationP5)
    let distanceP6_P5 = locationP6.distance(from: locationP5)
    
    XCTAssertEqual(Int(distanceP4_P5), Int(expectedDistance))
    XCTAssertEqual(Int(distanceP6_P5), Int(expectedDistance))

    let locationP7 = locationFrom(point: points[7])
    let locationP8 = locationFrom(point: points[8])
    let locationP9 = locationFrom(point: points[9])
    let distanceP7_P8 = locationP7.distance(from: locationP8)
    let distanceP9_P8 = locationP9.distance(from: locationP8)
    
    XCTAssertEqual(Int(distanceP7_P8), Int(expectedDistance))
    XCTAssertEqual(Int(distanceP9_P8), Int(expectedDistance))
  }
  
  // MARK: - Region SouthAmerica
  
  func test_generationGeoAreaCovererShouldProvideExpectedQtyOfPoints_SA() {
    let points = GeoAreaCoverer.coverage(
      for: TestData.allPoints_SA,
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    XCTAssertEqual(points.count, 3)
  }
  
  func test_generationGeoAreaCovererShouldProvideExpectedValueForPoints_SA() {
    let points = GeoAreaCoverer.coverage(
      for: TestData.allPoints_SA,
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    XCTAssertEqual(points[0].latitude.roundToDecimal(6), 9.729497)
    XCTAssertEqual(points[0].longitude.roundToDecimal(6), -63.147846)
    
    XCTAssertEqual(points[1].latitude.roundToDecimal(6), 9.730171)
    XCTAssertEqual(points[1].longitude.roundToDecimal(6), -63.148302)
    
    XCTAssertEqual(points[2].latitude.roundToDecimal(6), 9.730171)
    XCTAssertEqual(points[2].longitude.roundToDecimal(6), -63.14739)
  }
  
  func test_generationGeoAreaCovererShouldPlacePointsOnExpectedDistance_SA() {
    let area = Measurement<UnitArea>.init(value: 1, unit: .hectares)
    let points = GeoAreaCoverer.coverage(
      for: TestData.allPoints_SA,
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    let coverPolygonInMeters = area.converted(to: .squareMeters)
    let polygonSideSizeInMeters: CLLocationDistance = coverPolygonInMeters.value.squareRoot()
    let expectedDistance = polygonSideSizeInMeters
    
    func locationFrom(point: CLLocationCoordinate2D) -> CLLocation {
      .init(latitude: point.latitude, longitude: point.longitude)
    }
    
    // points on same location latitude
    let locationP1 = locationFrom(point: points[1])
    let locationP3 = locationFrom(point: points[2])
    let distanceP1_P3 = locationP1.distance(from: locationP3)
    
    XCTAssertEqual(Int(distanceP1_P3), Int(expectedDistance))
  }
  
  // MARK: - Region NorthAmerica
  
  func test_generationGeoAreaCovererShouldProvideExpectedQtyOfPoints_NA() {
    let points = GeoAreaCoverer.coverage(
      for: TestData.allPoints_NA,
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    XCTAssertEqual(points.count, 5)
  }
  
  func test_generationGeoAreaCovererShouldProvideExpectedValueForPoints_NA() {
    let points = GeoAreaCoverer.coverage(
      for: TestData.allPoints_NA,
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    XCTAssertEqual(points[0].latitude.roundToDecimal(6), 77.660395)
    XCTAssertEqual(points[0].longitude.roundToDecimal(6), -78.465082)
    
    XCTAssertEqual(points[1].latitude.roundToDecimal(6), 77.660395)
    XCTAssertEqual(points[1].longitude.roundToDecimal(6), -78.46087)
    
    XCTAssertEqual(points[2].latitude.roundToDecimal(6), 77.66107)
    XCTAssertEqual(points[2].longitude.roundToDecimal(6), -78.462975)
    
    XCTAssertEqual(points[3].latitude.roundToDecimal(6), 77.66107)
    XCTAssertEqual(points[3].longitude.roundToDecimal(6), -78.458763)

    XCTAssertEqual(points[4].latitude.roundToDecimal(6), 77.661745)
    XCTAssertEqual(points[4].longitude.roundToDecimal(6), -78.460869)
  }
  
  func test_generationGeoAreaCovererShouldPlacePointsOnExpectedDistance_NA() {
    let area = Measurement<UnitArea>.init(value: 1, unit: .hectares)
    let points = GeoAreaCoverer.coverage(
      for: TestData.allPoints_NA,
      coverPolygonArea: .init(value: 1, unit: .hectares)
    )
    
    let coverPolygonInMeters = area.converted(to: .squareMeters)
    let polygonSideSizeInMeters: CLLocationDistance = coverPolygonInMeters.value.squareRoot()
    let expectedDistance = polygonSideSizeInMeters
    
    func locationFrom(point: CLLocationCoordinate2D) -> CLLocation {
      .init(latitude: point.latitude, longitude: point.longitude)
    }
    
    // points on same location latitude
    let locationP1 = locationFrom(point: points[0])
    let locationP3 = locationFrom(point: points[1])
    let distanceP1_P3 = locationP1.distance(from: locationP3)
    
    XCTAssertEqual(Int(distanceP1_P3), Int(expectedDistance))
  }
}

import MapKit

final class MKPolygonFilterTests: XCTestCase {
  private enum TestData {
    static let pointA_EU = CLLocationCoordinate2D(latitude: 49.819967602647196, longitude: 23.998182602364636)
    static let pointB_EU = CLLocationCoordinate2D(latitude: 49.8192744359698, longitude: 24.003368620577174)
    static let pointC_EU = CLLocationCoordinate2D(latitude: 49.816122858190475, longitude: 24.00141681398125)
    
    static let allPoints_EU = [
      pointA_EU,
      pointB_EU,
      pointC_EU
    ]

  }
  
  func test_onCreateCorrectPolygonCreated() {
    let sut = MKPolygonFilter(polygonCoordinates: TestData.allPoints_EU)
    let expectedPolygon = MKPolygon(
      coordinates: TestData.allPoints_EU,
      count: TestData.allPoints_EU.count
    )
    
    XCTAssertEqual(expectedPolygon.pointCount, sut.polygon.pointCount)
    XCTAssertEqual(
      expectedPolygon.points().pointee.coordinate.latitude,
      sut.polygon.points().pointee.coordinate.latitude
    )
  }
  
  func test_filterShoudlCorrectlyDetermineIfPointsInsidePolygon() {
    let sut = MKPolygonFilter(polygonCoordinates: TestData.allPoints_EU)
    TestData.allPoints_EU.forEach {
      XCTAssertTrue(sut.filter($0))
    }
  }
  
  func test_filterShoudlCorrectlyDetermineIfPointsNOTInsidePolygon() {
    let sut = MKPolygonFilter(polygonCoordinates: [
      .init(latitude: 20, longitude: 30),
      .init(latitude: 0, longitude: 0)
    ])
    TestData.allPoints_EU.forEach {
      XCTAssertFalse(sut.filter($0))
    }
  }
}

final class CLLocationCoordinate2D_ExtensionTests: XCTestCase {
 
  // MARK: - EarchDistance
  
  func test_coordinateAtGivenLocationShouldCorrectlyProvideItsEarchRadius_center() {
    let point = CLLocationCoordinate2D(latitude: 0, longitude: 0)
    let sut = point.earthRadius()
    
    XCTAssertEqual(sut, 6378137.0)
  }
  
  func test_coordinateAtGivenLocationShouldCorrectlyProvideItsEarchRadius_pole() {
    let point = CLLocationCoordinate2D(latitude: 90, longitude: 0)
    let sut = point.earthRadius()
    
    XCTAssertEqual(sut.roundToDecimal(1), 6361074.6)
  }
  
  func test_coordinateAtGivenLocationShouldCorrectlyProvideItsEarchRadius_anyPoint() {
    let point = CLLocationCoordinate2D(latitude: 45, longitude: 0)
    let sut = point.earthRadius()
    
    XCTAssertEqual(sut.roundToDecimal(1), 6362689.6)
  }
  
  // MARK: - LocationByAddingDistance

  func test_IfAddZeroShouldBeSameLocation() {
    let point = CLLocationCoordinate2D(latitude: 49.819967602647196, longitude: 23.998182602364636)
    let sut = point.locationByAdding(distance: 0, bearing: 0)
    
    XCTAssertEqual(sut.latitude.roundToDecimal(6), point.latitude.roundToDecimal(6))
    XCTAssertEqual(sut.longitude.roundToDecimal(6), point.longitude.roundToDecimal(6))
  }
  
  func test_IfAddDistanceShouldBeCorrectLocation_changeLat() {
    let point = CLLocationCoordinate2D(latitude: 49.819967602647196, longitude: 23.998182602364636)
    let sut = point.locationByAdding(distance: 100, bearing: 0)
    
    XCTAssertEqual(sut.latitude.roundToDecimal(6), 49.820866)
    XCTAssertEqual(sut.longitude.roundToDecimal(6), point.longitude.roundToDecimal(6))
  }
  
  func test_IfAddDistanceShouldBeCorrectLocation_changeLong() {
    let point = CLLocationCoordinate2D(latitude: 49.819967602647196, longitude: 23.998182602364636)
    let sut = point.locationByAdding(distance: 100, bearing: 90)
    
    XCTAssertEqual(sut.latitude.roundToDecimal(6), point.latitude.roundToDecimal(6))
    XCTAssertEqual(sut.longitude.roundToDecimal(6), 23.999576)
  }
  
  func test_IfAddDistanceShouldBeCorrectLocation_anyDirection() {
    let point = CLLocationCoordinate2D(latitude: 49.819967602647196, longitude: 23.998182602364636)
    let sut = point.locationByAdding(distance: 100, bearing: 45)
    
    XCTAssertEqual(sut.latitude.roundToDecimal(6), 49.820603)
    XCTAssertEqual(sut.longitude.roundToDecimal(6), 23.999168)
  }
}

final class FloatingPointRadiansConvertionTests: XCTestCase {
  
  func test_shouldCorrectlyConvertToRadians() {
    let values: [Double] = [0, 1, 45, 60, 90, 120, 180]
    values.forEach { sut in
      XCTAssertEqual(sut.degreesToRadians, sut * .pi / 180)
      XCTAssertEqual(Double(sut).degreesToRadians, sut * .pi / 180)
      XCTAssertEqual(CGFloat(sut).degreesToRadians, CGFloat(sut) * .pi / 180)
      XCTAssertEqual(Float(sut).degreesToRadians, Float(sut) * .pi / 180)
    }
  }
  
  func test_shouldCorrectlyConvertToDegrees() {
    let values: [Double] = [0, 1, 2, 3]
    values.forEach { sut in
      XCTAssertEqual(sut.radiansToDegrees, sut * 180 / .pi)
      XCTAssertEqual(Double(sut).radiansToDegrees, sut * 180 / .pi)
      XCTAssertEqual(CGFloat(sut).radiansToDegrees, CGFloat(sut) * 180 / .pi)
      XCTAssertEqual(Float(sut).radiansToDegrees, Float(sut) * 180 / .pi)
    }
  }
}

final class CLLocationDegrees_BearingTests: XCTestCase {

  func test_propertyValueShouldProvideCorrectDegree_any() {
    XCTAssertEqual(CLLocationDegrees.Bearing.any(123).value, 123)
  }
  
  func test_propertyValueShouldProvideCorrectDegree_up() {
    XCTAssertEqual(CLLocationDegrees.Bearing.up.value, 0)
  }

  func test_propertyValueShouldProvideCorrectDegree_down() {
    XCTAssertEqual(CLLocationDegrees.Bearing.down.value, 180)
  }

  func test_propertyValueShouldProvideCorrectDegree_left() {
    XCTAssertEqual(CLLocationDegrees.Bearing.left.value, 270)
  }

  func test_propertyValueShouldProvideCorrectDegree_right() {
    XCTAssertEqual(CLLocationDegrees.Bearing.right.value, 90)
  }
}

// second

final class CLLocationDistanceTests: XCTestCase {
  
  func test_convertion() {
    let distance = 11139.0
    let sut = distance.toDegree
    
    XCTAssertEqual(sut.roundToDecimal(2), 0.100)
  }
  
  func test_convertion_zero() {
    let distance = 0.0
    let sut = distance.toDegree
    
    XCTAssertEqual(sut, 0)
  }
}


// MARK: - Support

extension CLLocationDegrees {
  func roundToDecimal(_ fractionDigits: Int) -> Double {
    let multiplier = pow(10, Double(fractionDigits))
    return Darwin.round(self * multiplier) / multiplier
  }
}

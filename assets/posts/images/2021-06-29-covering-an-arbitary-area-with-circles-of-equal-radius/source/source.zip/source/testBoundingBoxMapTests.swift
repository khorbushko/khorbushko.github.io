//
//  testBoundingBoxMapTests.swift
//
//
//  Created by Kyryl Horbushko on 23.06.2021.
//  https://www.keene.edu/campus/maps/tool/

import XCTest
import CoreLocation
@testable import testBoundingBoxMap

final class GeoBoundingBoxTests: XCTestCase {

  private enum Constants {
    static let pointA_EU: CLLocationCoordinate2D = .init(latitude: 48.59499618510842, longitude: 22.55773346982532)
    static let pointB_EU: CLLocationCoordinate2D = .init(latitude: 49.37328731825035, longitude: 39.57242606666667)
    static let pointC_EU: CLLocationCoordinate2D = .init(latitude: 44.539727760252916, longitude: 33.84269153469858)
    static let pointD_EU: CLLocationCoordinate2D = .init(latitude: 52.22400597886801, longitude: 32.83926094565404)
    
    static let euRegionPoints = [
      Constants.pointA_EU,
      Constants.pointB_EU,
      Constants.pointC_EU,
      Constants.pointD_EU
    ]
    
    static let pointA_SA = CLLocationCoordinate2D(latitude: 9.7295950, longitude: -63.1485865)
    static let pointB_SA = CLLocationCoordinate2D(latitude: 9.7296327, longitude: -63.1414284)
    static let pointC_SA = CLLocationCoordinate2D(latitude: 9.7253462, longitude: -63.1413755)
    static let pointD_SA = CLLocationCoordinate2D(latitude: 9.7272901, longitude: -63.1469550)
    
    static let southAmericaRegionPoints = [
      pointA_SA,
      pointB_SA,
      pointC_SA,
      pointD_SA
    ]
    
    static let pointA_NA = CLLocationCoordinate2D(latitude: 57.1087065, longitude: -109.2217359)
    static let pointB_NA = CLLocationCoordinate2D(latitude: 57.1085630, longitude: -109.2158124)
    static let pointC_NA = CLLocationCoordinate2D(latitude: 57.1067052, longitude: -109.2161337)
    static let pointD_NA = CLLocationCoordinate2D(latitude: 57.1075172, longitude: -109.2208860)
    
    static let northAmericaRegionPoints = [
      pointA_NA,
      pointB_NA,
      pointC_NA,
      pointD_NA
    ]
  }
  
  // MARK: - Init

  func test_init() {
    let sut = GeoBoundingBox()
    XCTAssertNotNil(sut)
  }
  
  // MARK: - Default

  func test_defaultValue_center() {
    let sut = GeoBoundingBox()
    let center = sut.center()

    XCTAssertEqual(center.latitude, 0)
    XCTAssertEqual(center.longitude, 0)
  }

  func test_defaultValue_northWestCorner() {
    let sut = GeoBoundingBox()
    let point = sut.northWestCorner

    XCTAssertEqual(point.latitude, 0)
    XCTAssertEqual(point.longitude, 0)
  }

  func test_defaultValue_southEastCorner() {
    let sut = GeoBoundingBox()
    let point = sut.southEastCorner

    XCTAssertEqual(point.latitude, 0)
    XCTAssertEqual(point.longitude, 0)
  }

  func test_defaultValue_northEastCorner() {
    let sut = GeoBoundingBox()
    let point = sut.northEastCorner

    XCTAssertEqual(point.latitude, 0)
    XCTAssertEqual(point.longitude, 0)
  }

  func test_defaultValue_southWestCorner() {
    let sut = GeoBoundingBox()
    let point = sut.southWestCorner

    XCTAssertEqual(point.latitude, 0)
    XCTAssertEqual(point.longitude, 0)
  }
  
  // MARK: - EU region

  func test_boundingRect_center_euRegion() {
    let sut = GeoBoundingBox()
    let nwPoint: CLLocationCoordinate2D = .init(latitude: 49.819568, longitude: 23.999935)
    let nePoint: CLLocationCoordinate2D = .init(latitude: 49.819367, longitude: 23.999935)
    let swPoint: CLLocationCoordinate2D = .init(latitude: 49.819568, longitude: 24.000074)
    let sePoint: CLLocationCoordinate2D = .init(latitude: 49.817858, longitude: 24.000074)

    sut.appendPoints([
      nwPoint,
      nePoint,
      swPoint,
      sePoint
    ])

    let center = sut.center()
    let rect = sut.coordinateRegion()

    XCTAssertEqual(rect.center.latitude, 49.818713)
    XCTAssertEqual(rect.center.longitude, 24.000004500000003)

    XCTAssertEqual(rect.center.latitude, center.latitude)
    XCTAssertEqual(rect.center.longitude, center.longitude)
  }

  func test_boundingRect_southWestCorner_euRegion() {
    let sut = createBox(Constants.euRegionPoints)

    let point = sut.southWestCorner

    XCTAssertEqual(point.latitude, 44.539727760252916)
    XCTAssertEqual(point.longitude, 22.55773346982532)
  }

  func test_boundingRect_southEastCorner_euRegion() {
    let sut = createBox(Constants.euRegionPoints)

    let point = sut.southEastCorner

    XCTAssertEqual(point.latitude, 44.539727760252916)
    XCTAssertEqual(point.longitude, 39.57242606666667)
  }

  func test_boundingRect_northWestCorner_euRegion() {
    let sut = createBox(Constants.euRegionPoints)

    let point = sut.northWestCorner

    XCTAssertEqual(point.latitude, 52.22400597886801)
    XCTAssertEqual(point.longitude, 22.55773346982532)
  }

  func test_boundingRect_northEastCorner_euRegion() {
    let sut = createBox(Constants.euRegionPoints)

    let point = sut.northEastCorner

    XCTAssertEqual(point.latitude, 52.22400597886801)
    XCTAssertEqual(point.longitude, 39.57242606666667)
  }

  func test_boundingRect_properlyDeterminePointsInside_euRegion() {
    let sut = createBox(Constants.euRegionPoints)

    let pointInside = CLLocationCoordinate2D(latitude: 46, longitude: 30)
    XCTAssertTrue(sut.contains(pointInside))
  }

  func test_boundingRect_properlyDeterminePointsInside_borderPoints_euRegion() {
    let sut = createBox(Constants.euRegionPoints)

    XCTAssertTrue(sut.contains(sut.northEastCorner))
    XCTAssertTrue(sut.contains(sut.northWestCorner))
    XCTAssertTrue(sut.contains(sut.southEastCorner))
    XCTAssertTrue(sut.contains(sut.southWestCorner))
  }

  func test_boundingRect_properlyDeterminePointsOutside_euRegion() {
    let sut = createBox(Constants.euRegionPoints)

    let pointOutside = CLLocationCoordinate2D(latitude: 20, longitude: 20)
    XCTAssertFalse(sut.contains(pointOutside))
  }
  
  // MARK: - South America Region
  
  func test_boundingRect_southAmericaRegion() {
    let sut = GeoBoundingBox()
    
    sut.appendPoints(Constants.southAmericaRegionPoints.shuffled())
    
    let center = sut.center()
    let rect = sut.coordinateRegion()
        
    XCTAssertEqual(rect.center.latitude, 9.72748945)
    XCTAssertEqual(rect.center.longitude, -63.144981)
    
    XCTAssertEqual(rect.center.latitude, center.latitude)
    XCTAssertEqual(rect.center.longitude, center.longitude)
  }
  
  func test_boundingRect_southWestCorner_southAmericaRegion() {
    let sut = createBox(Constants.southAmericaRegionPoints)
    
    let point = sut.southWestCorner
    
    XCTAssertEqual(point.latitude, 9.7253462)
    XCTAssertEqual(point.longitude, -63.1485865)
  }
  
  func test_boundingRect_southEastCorner_southAmericaRegion() {
    let sut = createBox(Constants.southAmericaRegionPoints)
    
    let point = sut.southEastCorner
    
    XCTAssertEqual(point.latitude, 9.7253462)
    XCTAssertEqual(point.longitude, -63.1413755)
  }
  
  func test_boundingRect_northWestCorner_southAmericaRegion() {
    let sut = createBox(Constants.southAmericaRegionPoints)
    
    let point = sut.northWestCorner
    
    XCTAssertEqual(point.latitude, 9.7296327)
    XCTAssertEqual(point.longitude, -63.1485865)
  }
  
  func test_boundingRect_northEastCorner_southAmericaRegion() {
    let sut = createBox(Constants.southAmericaRegionPoints)
    
    let point = sut.northEastCorner
    
    XCTAssertEqual(point.latitude, 9.7296327)
    XCTAssertEqual(point.longitude, -63.1413755)
  }
  
  func test_boundingRect_properlyDeterminePointsInside_southAmericaRegion() {
    let sut = createBox(Constants.southAmericaRegionPoints)
    
    let pointInside = CLLocationCoordinate2D(latitude: 9.727447, longitude: -63.1448291)
    XCTAssertTrue(sut.contains(pointInside))
  }
  
  func test_boundingRect_properlyDeterminePointsInside_borderPoints_southAmericaRegion() {
    let sut = createBox(Constants.southAmericaRegionPoints)
    
    XCTAssertTrue(sut.contains(sut.northEastCorner))
    XCTAssertTrue(sut.contains(sut.northWestCorner))
    XCTAssertTrue(sut.contains(sut.southEastCorner))
    XCTAssertTrue(sut.contains(sut.southWestCorner))
  }
  
  func test_boundingRect_properlyDeterminePointsOutside_southAmericaRegion() {
    let sut = createBox(Constants.southAmericaRegionPoints)
    
    let pointOutside = CLLocationCoordinate2D(latitude: 20, longitude: 20)
    XCTAssertFalse(sut.contains(pointOutside))
  }
  
  // MARK: - Norh America Region
  
  func test_boundingRect_northAmericaRegion() {
    let sut = GeoBoundingBox()
    
    sut.appendPoints(Constants.northAmericaRegionPoints.shuffled())
    
    let center = sut.center()
    let rect = sut.coordinateRegion()
    
    XCTAssertEqual(rect.center.latitude, 57.10770585)
    XCTAssertEqual(rect.center.longitude, -109.21877415)
    
    XCTAssertEqual(rect.center.latitude, center.latitude)
    XCTAssertEqual(rect.center.longitude, center.longitude)
  }
  
  func test_boundingRect_southWestCorner_northAmericaRegion() {
    let sut = createBox(Constants.northAmericaRegionPoints)
    
    let point = sut.southWestCorner
    
    XCTAssertEqual(point.latitude, 57.1067052)
    XCTAssertEqual(point.longitude, -109.2217359)
  }
  
  func test_boundingRect_southEastCorner_northAmericaRegion() {
    let sut = createBox(Constants.northAmericaRegionPoints)
    
    let point = sut.southEastCorner
    
    XCTAssertEqual(point.latitude, 57.1067052)
    XCTAssertEqual(point.longitude, -109.2158124)
  }
  
  func test_boundingRect_northWestCorner_northAmericaRegion() {
    let sut = createBox(Constants.northAmericaRegionPoints)
    
    let point = sut.northWestCorner
    
    XCTAssertEqual(point.latitude, 57.1087065)
    XCTAssertEqual(point.longitude, -109.2217359)
  }
  
  func test_boundingRect_northEastCorner_northAmericaRegion() {
    let sut = createBox(Constants.northAmericaRegionPoints)
    
    let point = sut.northEastCorner
    
    XCTAssertEqual(point.latitude, 57.1087065)
    XCTAssertEqual(point.longitude, -109.2158124)
  }
  
  func test_boundingRect_properlyDeterminePointsInside_northAmericaRegion() {
    let sut = createBox(Constants.northAmericaRegionPoints)

    let pointInside = CLLocationCoordinate2D(latitude: 57.1077989, longitude: -109.2179415)
    XCTAssertTrue(sut.contains(pointInside))
  }
  
  func test_boundingRect_properlyDeterminePointsInside_borderPoints_northAmericaRegion() {
    let sut = createBox(Constants.northAmericaRegionPoints)
    
    XCTAssertTrue(sut.contains(sut.northEastCorner))
    XCTAssertTrue(sut.contains(sut.northWestCorner))
    XCTAssertTrue(sut.contains(sut.southEastCorner))
    XCTAssertTrue(sut.contains(sut.southWestCorner))
  }
  
  func test_boundingRect_properlyDeterminePointsOutside_northAmericaRegion() {
    let sut = createBox(Constants.northAmericaRegionPoints)
    
    let pointOutside = CLLocationCoordinate2D(latitude: 20, longitude: 20)
    XCTAssertFalse(sut.contains(pointOutside))
  }

  // MARK: - Private

  private func createBox(_ points: [CLLocationCoordinate2D]) -> GeoBoundingBox {
    let sut = GeoBoundingBox()

    sut.appendPoints(points.shuffled())

    return sut
  }
}

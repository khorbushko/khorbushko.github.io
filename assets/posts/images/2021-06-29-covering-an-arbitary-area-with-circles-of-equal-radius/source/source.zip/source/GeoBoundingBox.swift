//
//  BoundingBox.swift
//  
//
//  Created by Kyryl Horbushko on 23.06.2021.
//  idea - by Will Pearse 8/05/13

/*
 
 Compas:
 
  ----N----
 NW        NE
W-----X------E
 SW        SE
  ----S----
 
 */

import Foundation
import CoreLocation
import MapKit

final public class GeoBoundingBox {
    private enum Constants {
    // https://www.usna.edu/Users/oceano/pguth/md_help/html/approx_equivalents.htm
    // 0.1 degrees ~ 11.1 km
    static let minBoxWidth: Double = 0.1
    static let defaultNE = CLLocationCoordinate2DMake(-90, -180)
    static let defaultSW = CLLocationCoordinate2DMake(90, 180)
  }
  
  public private(set) var coordinates: [CLLocationCoordinate2D] = []
  private var minimumWidthInDegrees = Constants.minBoxWidth
  
  private var _northEastCorner = Constants.defaultNE
  private var _southWestCorner = Constants.defaultSW
  
  public var northEastCorner: CLLocationCoordinate2D {
    if coordinates.count < 2 {
      return .init()
    } else {
      return _northEastCorner
    }
  }
  
  public var southWestCorner: CLLocationCoordinate2D {
    if coordinates.count < 2 {
      return .init()
    } else {
      return _southWestCorner
    }
  }
  
  public var northWestCorner: CLLocationCoordinate2D {
    if coordinates.count < 2 {
      return .init()
    } else {
      return .init(latitude: _northEastCorner.latitude, longitude: _southWestCorner.longitude)
    }
  }
  
  public var southEastCorner: CLLocationCoordinate2D {
    if coordinates.count < 2 {
      return .init()
    } else {
      return .init(latitude: _southWestCorner.latitude, longitude: _northEastCorner.longitude)
    }
  }
  
  // MARK: - Public
  
  public func drop() {
    coordinates.removeAll()
    _northEastCorner = Constants.defaultNE
    _southWestCorner = Constants.defaultSW
    minimumWidthInDegrees = Constants.minBoxWidth
  }
  
  public func appendPoints(_ points: [CLLocationCoordinate2D]) {
    points.forEach(appendPoint)
  }
  
  public func center() -> CLLocationCoordinate2D {
    if coordinates.isEmpty {
      return .init()
    }
    
    if coordinates.count == 1 {
      return coordinates[0]
    }
    
    let latitude = (_northEastCorner.latitude + _southWestCorner.latitude) / 2
    let longitude = (_northEastCorner.longitude + _southWestCorner.longitude) / 2
    
    return CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
  }
  
  public func coordinateRegion(with padding: CLLocationDegrees = 0) -> MKCoordinateRegion {
    var latDelta = _northEastCorner.latitude - _southWestCorner.latitude
    var longDelta = _northEastCorner.longitude - _southWestCorner.longitude
    
    func clamp(x: Double, low: Double, high: Double) -> Double {
      x > high
        ? high
        : (x < low ? low : x)
    }
    
    latDelta = clamp(x: latDelta, low: minimumWidthInDegrees, high: latDelta) + padding * 2
    longDelta = clamp(x: longDelta, low: minimumWidthInDegrees, high: longDelta) + padding * 2
    
    let span = MKCoordinateSpan(latitudeDelta: latDelta, longitudeDelta: longDelta)
    let region = MKCoordinateRegion(center: center(), span: span)
    return region
  }
    
  public func updateWidth(_ degree: CLLocationDegrees) {
    minimumWidthInDegrees = degree
  }
  
  public func contains(_ coordinate: CLLocationCoordinate2D) -> Bool {
    let withinLatBounds = coordinate.latitude <= _northEastCorner.latitude &&
      coordinate.latitude >= _southWestCorner.latitude
    let withinLongBounds = coordinate.longitude <= _northEastCorner.longitude &&
      coordinate.longitude >= _southWestCorner.longitude
    return withinLatBounds && withinLongBounds
  }
  
  // MARK: - Private
  
  private func appendPoint(_ coordinate: CLLocationCoordinate2D) {
    if coordinate.latitude > _northEastCorner.latitude {
      _northEastCorner.latitude = coordinate.latitude
    }
    if coordinate.longitude > _northEastCorner.longitude {
      _northEastCorner.longitude = coordinate.longitude
    }
    
    if coordinate.latitude < _southWestCorner.latitude {
      _southWestCorner.latitude = coordinate.latitude
    }
    if coordinate.longitude < _southWestCorner.longitude {
      _southWestCorner.longitude = coordinate.longitude
    }
    
    coordinates.append(coordinate)
  }
}

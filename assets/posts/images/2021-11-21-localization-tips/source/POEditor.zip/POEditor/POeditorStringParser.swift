//
//  POeditorStringParser.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 07.07.2021.
//

import Foundation

final class POeditorStringParser {
  static func convertToDictionary(_ source: String) -> [String: String] {
    var components = source.components(separatedBy: ";\n") // .strings
    if components.count == 1 {
      components = source.components(separatedBy: "\r") // .csv
    }
    
    var resultDic: [String: String] = [: ]
    
    components.forEach { (pair) in
      var pairComponents = pair.components(separatedBy: "=") // .strings
      if pairComponents.count == 1 {
        pairComponents = pair.components(separatedBy: ";") // .csv
      }
      
      if pairComponents.count == 1 {
        pairComponents = pair.components(separatedBy: "\t") // .csv
      }
      
      if pairComponents.count == 2,
         pairComponents.first?.isEmpty == false,
         pairComponents.last?.isEmpty == false {
        
        var keyValue = pairComponents.first!
        var valueValue = pairComponents.last!
        
        keyValue.clearTechCharacters()
        valueValue.clearTechCharacters()
        
        if keyValue.hasPrefix("//") { // comments
          if let lastComp = keyValue.components(separatedBy: "\n").last {
            keyValue = lastComp
            keyValue.clearTechCharacters()
            resultDic[keyValue] = valueValue
          }
        } else {
          resultDic[keyValue] = valueValue
        }
      }
    }
    return resultDic
  }
}

fileprivate extension String {
  mutating func clearTechCharacters() {
    let setToUseForClear = CharacterSet(arrayLiteral: "\"")
      .union(.whitespacesAndNewlines)
    self = self.trimmingCharacters(in: setToUseForClear)
  }
}

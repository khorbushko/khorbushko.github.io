//
//  POEditorMultipartData.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 07.07.2021.
//

import Foundation

struct POEditorMultipartData {
  private let mimeType = "text/plain"
  private let bodyParameters: [String: AnyObject]
  private let encoding: String.Encoding = .utf8
  private let endLine: String = "\r\n"
  private let boundary: String = "Boundary-\(UUID().uuidString)"

  var header: [String: String] {
    [
      "Content-Type": "multipart/form-data; boundary=\(boundary)"
    ]
  }
  
  // MARK: - Lifecycle
  
  public init(
    bodyParameters: [String: AnyObject]
  ) {
    self.bodyParameters = bodyParameters
  }
  
  var body: Data {
    var body = Data()
    
    if let boundaryStartData = "--\(boundary)\(endLine)".data(using: encoding),
       let contentTypeData = "Content-Type: \(mimeType)\(endLine)\(endLine)".data(using: encoding),
       let endLineData = "\(endLine)".data(using: encoding),
       let boundaryEndData = "--\(boundary)--\(endLine)".data(using: encoding) {
      
      bodyParameters.forEach { (pair) in
        if let key = "Content-Disposition: form-data; name=\"\(pair.key)\"\(endLine)\(endLine)".data(using: encoding),
           let value = "\(pair.value)\(endLine)".data(using: encoding) {
          
          body.append(boundaryStartData)
          body.append(key)
          body.append(value)
        }
      }
      
      body.append(boundaryStartData)
      body.append(contentTypeData)
      body.append(endLineData)
      body.append(boundaryEndData)
    }
    
    return body
  }
}

//
//  POEditorRequest.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 07.07.2021.
//

import Foundation

protocol POEditorRequest {
  
  var multipartData: POEditorMultipartData? { get }
  var method: String { get }
  var endPoint: String { get }
  var body: Data? { get }
}

extension POEditorRequest {
  var body: Data? {
    multipartData?.body
  }
}

extension POEditorRequest {
  func buildURLRequest() -> URLRequest? {
    if let url = URL(string: self.endPoint) {
      var buildingRequest = URLRequest(url: url)
      buildingRequest.httpMethod = self.method
      buildingRequest.allHTTPHeaderFields = self.multipartData?.header
      buildingRequest.httpBody = self.body
      buildingRequest.timeoutInterval = 10
      
      return buildingRequest
    } else {
      return nil
    }
  }
}

//
//  POEditoDownloadLanguage.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 07.07.2021.
//

import Foundation
import Combine

struct POEditoDownloadLanguage: POEditorRequest {
  var multipartData: POEditorMultipartData?
  let method: String
  let endPoint: String
  
  init(
    url: String
  ) {
    method = "GET"
    endPoint = url
  }
}

extension POEditoDownloadLanguage {
  
  func load() -> AnyPublisher<String, Error> {
    let session = URLSession.shared
    if let urlRequest = buildURLRequest() {
      return session.dataTaskPublisher(for: urlRequest)
        .map(\.data)
        .tryMap({
          if let string = String(data: $0, encoding: .utf8) {
            return string
          }
          throw POEditorRequestFailure.dataConvertion
        })
        .eraseToAnyPublisher()
    } else {
      return Fail(error: POEditorRequestFailure.invalidRequest)
        .eraseToAnyPublisher()
    }
  }
}

//
//  POEditoExportLanguage.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 07.07.2021.
//

import Foundation
import Combine

struct POEditoExportLanguage: POEditorRequest {
  
  let multipartData: POEditorMultipartData?
  let method: String
  let endPoint: String
  
  init(
    _ accessData: POEditorAccessProvider.ProjectAccessData,
    code: String
  ) {
    multipartData = POEditorMultipartData(bodyParameters: [
      "api_token": accessData.apiKey,
      "id": accessData.projectID,
      "language": code,
      "type": "apple_strings"
    ] as [String: AnyObject])
    method = "POST"
    endPoint = "https://api.poeditor.com/v2/projects/export"
  }
}

extension POEditoExportLanguage {
  
  func load() -> AnyPublisher<POEditorExportResult, Error> {
    let session = URLSession.shared
    if let urlRequest = buildURLRequest() {
      return session.dataTaskPublisher(for: urlRequest)
        .map(\.data)
        .decode(type: POEditorExportDataResult.self, decoder: JSONDecoder())
        .map(\.result)
        .eraseToAnyPublisher()
    } else {
      return Fail(error: POEditorRequestFailure.invalidRequest)
        .eraseToAnyPublisher()
    }
  }
}

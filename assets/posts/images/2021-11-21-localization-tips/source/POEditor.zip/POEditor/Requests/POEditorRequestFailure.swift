//
//  POEditorRequestFailure.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 07.07.2021.
//

import Foundation

enum POEditorRequestFailure: Swift.Error {
  case invalidRequest
  case dataCheck
  case dataConvertion
}

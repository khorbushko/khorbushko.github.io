//
//  POEditorListLanguages.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 07.07.2021.
//

import Foundation
import Combine

struct POEditorListLanguages: POEditorRequest {
  
  let multipartData: POEditorMultipartData?
  let method: String
  let endPoint: String
  
  init(_ accessData: POEditorAccessProvider.ProjectAccessData) {
    multipartData = POEditorMultipartData(bodyParameters: [
      "api_token": accessData.apiKey,
      "id": accessData.projectID
    ] as [String: AnyObject])
    method = "POST"
    endPoint = "https://api.poeditor.com/v2/languages/list"
  }
}

extension POEditorRequest {
  
  func load() -> AnyPublisher<LanguageResult, Error> {
    let session = URLSession.shared
    if let urlRequest = buildURLRequest() {
      return session.dataTaskPublisher(for: urlRequest)
        .map(\.data)
        .decode(type: POEditorLanguageList.self, decoder: JSONDecoder())
        .map(\.result)
        .eraseToAnyPublisher()
    } else {
      return Fail(error: POEditorRequestFailure.invalidRequest)
        .eraseToAnyPublisher()
    }
  }
}

//
//  POEditorLocalizationStorage.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 07.07.2021.
//

import Foundation
import UIKit

final class POEditorLocalizationStorage {
  
  private let fileManager = FileManager()
  private var libraryDir: URL? {
    fileManager
      .urls(for: .applicationSupportDirectory, in: .userDomainMask)
      .first?
      .appendingPathComponent("POEditorLocalization")
  }
  
  // MARK: - Lifecycle
  
  init() {
    prepareStorageFolderIfNeeded()
  }
  
  // MARK: - Public
  
  func storeForLocalization(
    languageCode: String,
    localizationValues: [String: String]
  ) {
    if let fileURL = libraryDir?.appendingPathComponent("\(languageCode).plist") {
      do {
        let data = try PropertyListSerialization.data(
          fromPropertyList: localizationValues,
          format: PropertyListSerialization.PropertyListFormat.xml,
          options: 0
        )
        do {
          try data.write(to: fileURL, options: .atomic)
        } catch {
          /*ignore*/
        }
      } catch {
        /*ignore*/
      }
    }
  }
  
  func readLocalizationFor(
    languageCode: String
  ) -> [String: String] {
    if let fileURL = libraryDir?.appendingPathComponent("\(languageCode).plist") {
      if let file = fileManager.contents(atPath: fileURL.path) {
        do {
          let values = try PropertyListDecoder().decode([String: String].self, from: file)
          return values
        } catch {
          /*ignore*/
        }
      }
    }
    
    return [: ]
  }
  
  // MARK: - Private
  
  private func prepareStorageFolderIfNeeded() {
    if let path = libraryDir {
      if !directoryExistsAtPath(path.path) {
        do {
          try fileManager.createDirectory(
            at: path,
            withIntermediateDirectories: true,
            attributes: nil
          )
        } catch {
          /*ignore*/
        }
      }
    }
  }
  
  // MARK: - Utils
  
  private func directoryExistsAtPath(_ path: String) -> Bool {
    var isDirectory = ObjCBool(true)
    let exists = FileManager.default.fileExists(atPath: path, isDirectory: &isDirectory)
    return exists && isDirectory.boolValue
  }
}

//
//  POEditorAccess.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 04.07.2021.
//

import Foundation

final class POEditorAccessProvider {
  struct ProjectAccessData {
    let apiKey: String
    let projectID: String
  }
  
  let projectData: ProjectAccessData
  
  init?() {
    if let cryptor = MFCryptor(),
       let poEditorData = Bundle.main.infoDictionary?["POEditor"] as? [String: String],
       let apiKey = poEditorData["apiKey"],
       let projectId = poEditorData["projectId"],
       let decryptedApiKey = try? cryptor.decryptString(apiKey),
       let decryptedProjectId = try? cryptor.decryptString(projectId) {
      
      projectData = ProjectAccessData(
        apiKey: decryptedApiKey,
        projectID: decryptedProjectId
      )
      
    } else {
      return nil
    }
  }
}

//
//  POEditorLanguage.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 04.07.2021.
//

import Foundation

struct POEditorLanguage: Codable {
  let name: String
  let code: String
  let translations: Int
  let percentage: Double
  let updated: String
}

struct POEditorResponse<Result: Codable>: Codable {
  let response: Response
  let result: Result
}

struct Response: Codable {
  let status: String
  let code: String
  let message: String
}

struct LanguageResult: Codable {
  let languages: [POEditorLanguage]?
}

typealias POEditorLanguageList = POEditorResponse<LanguageResult>

struct POEditorExportResult: Codable {
  let url: String
}

typealias POEditorExportDataResult = POEditorResponse<POEditorExportResult>

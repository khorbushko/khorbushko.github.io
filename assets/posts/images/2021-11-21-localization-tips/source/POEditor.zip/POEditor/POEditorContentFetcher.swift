//
//  POEditorContentFetcher.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 07.07.2021.
//

import Foundation
import Combine

final class POEditorContentFetcher {
  private let accessProvider = POEditorAccessProvider()
  
  func fetchForLanguage(languageCode: String) -> AnyPublisher<String, Error> {
    if let data = accessProvider?.projectData {
      return POEditorListLanguages(data)
        .load()
        .tryMap { response throws -> String in
          if let code = response.languages?
              .first(where: { $0.code == languageCode })?
              .code {
            return code
          } else {
            throw POEditorRequestFailure.dataCheck
          }
        }
        .flatMap({ value in
          POEditoExportLanguage(data, code: value)
            .load()
        })
        .flatMap({ value in
          POEditoDownloadLanguage(url: value.url)
            .load()
        })
        .map({ $0 })
        .eraseToAnyPublisher()
    }
    return Fail(error: POEditorRequestFailure.invalidRequest)
      .eraseToAnyPublisher()
  }
}

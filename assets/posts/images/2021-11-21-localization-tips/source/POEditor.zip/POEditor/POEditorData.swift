//
//  POEditorRequsts.swift
//  MoneyFlow
//
//  Created by Kyryl Horbushko on 06.07.2021.
//

import Foundation
import Combine
import UIKit

final class POEditorData {
  static let instance: POEditorData = .init()
  
  subscript(_ key: String) -> String? {
    get {
      currentValues?[key]
    }
  }
  
  var currentLanguage: String? {
    Locale.current.languageCode
  }
  
  private let fetcher: POEditorContentFetcher = .init()
  private let storage = POEditorLocalizationStorage()
  
  private var currentValues: [String: String]?
  
  private var cancellable: Set<AnyCancellable> = []
  private var token: AnyCancellable?
  
  private init() {
    preheatForCurrentLanguage()
    setupAutoRefresh()
  }

  func autoUpdate() {
    if let current = currentLanguage {
      fetcher
        .fetchForLanguage(languageCode: current)
        .sink { _ in
          /* do nothing */
        } receiveValue: { [weak self] rawValue in
          self?.storeRaw(value: rawValue, language: current)
        }
        .store(in: &cancellable)
    }
  }
  
  // MARK: - Private
  
  private func storeRaw(value: String, language: String) {
    let dictionaryWithValues = POeditorStringParser.convertToDictionary(value)
    storage.storeForLocalization(languageCode: language, localizationValues: dictionaryWithValues)
    currentValues = dictionaryWithValues
  }
  
  private func setupAutoRefresh() {
    token = NotificationCenter.default
      .publisher(for: UIApplication.didBecomeActiveNotification)
      .sink { [weak self] _ in
        self?.onActivate()
      }
  }
  
  private func preheatForCurrentLanguage() {
    if let current = currentLanguage {
      currentValues = storage.readLocalizationFor(languageCode: current)
    }
  }
  
  private func onActivate() {
    autoUpdate()
  }
}

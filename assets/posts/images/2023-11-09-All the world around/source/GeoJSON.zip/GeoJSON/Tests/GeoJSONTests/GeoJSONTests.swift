import XCTest
@testable import GeoJSON

final class GeoJSONTests: XCTestCase {

}

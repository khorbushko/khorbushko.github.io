//
//  GeoJSON+Load.swift
//
//
//  Created by Kyryl Horbushko on 09.11.2023.
//

import Foundation

extension GeoJson {

  public enum Failure: Error {
    case noFileFound
    case system(Error)
  }

  public static func loadCountries() async throws -> Task<GeoJson, Error> {
    Task {
      if let url = Bundle.module.url(
        forResource: "countries_110",
        withExtension: "geojson"
      ) {
        do {
          let data = try Data(contentsOf: url)
          let geoJson = try JSONDecoder().decode(GeoJson.self, from: data)
          return geoJson
        } catch {
          throw Failure.system(error)
        }
      } else {
        throw Failure.noFileFound
      }
    }
  }
}

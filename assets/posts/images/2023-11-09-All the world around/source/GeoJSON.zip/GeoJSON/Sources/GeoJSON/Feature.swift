//
//  Feature.swift
//  
//
//  Created by Kyryl Horbushko on 09.11.2023.
//

import Foundation
import CoreLocation

public struct Feature: Codable, Equatable, Hashable, Sendable {
  public let type: FeatureType
  public let properties: FeatureProperties
  public let bbox: [Double]
  public let geometry: Geometry
}

extension Feature: Identifiable {
  public var id: String {
    "\(type) \(properties.abbrev) \(properties.nameEn) \(properties.continent.rawValue)"
  }

  public var name: String {
    properties.abbrev
  }
}

extension Feature {
  public var bBox: [CLLocationCoordinate2D] {
    if bbox.count % 2 == 0 {
      let data = bbox.chunked(into: 2)
        .map({ CLLocationCoordinate2D(latitude: $0[1], longitude: $0[0]) })
      return data
    }
    return []
  }

  public var center: CLLocationCoordinate2D {
    .init(latitude: properties.labelY, longitude: properties.labelX)
  }
}

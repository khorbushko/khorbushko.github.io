//
//  Geometry.swift
//
//
//  Created by Kyryl Horbushko on 09.11.2023.
//

import Foundation

public struct Geometry: Codable, Equatable, Hashable, Sendable {
  public let type: GeometryType
  public let coordinates: Coordinates
}

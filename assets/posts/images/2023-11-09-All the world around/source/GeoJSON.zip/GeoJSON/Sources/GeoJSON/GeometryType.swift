//
//  GeometryType.swift
//  
//
//  Created by Kyryl Horbushko on 09.11.2023.
//

import Foundation

public enum GeometryType: String, Codable, Equatable, Hashable, Sendable {
  case multiPolygon = "MultiPolygon"
  case polygon = "Polygon"
  case point = "Point"
  case lineString = "LineString"
  case multiPoint = "MultiPoint"
  case multiLineString = "MultiLineString"
  case geometryCollection = "GeometryCollection"
}

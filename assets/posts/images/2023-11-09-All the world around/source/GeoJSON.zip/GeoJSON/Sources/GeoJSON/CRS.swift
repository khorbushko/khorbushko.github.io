//
//  CRS.swift
//  
//
//  Created by Kyryl Horbushko on 09.11.2023.
//

import Foundation

public struct CRS: Codable, Equatable, Hashable, Sendable {
  public struct Properties: Codable, Equatable, Hashable, Sendable {
    public let name: String
  }

  public let type: String
  public let properties: Properties
}

//
//  Coordinates.swift
//
//
//  Created by Kyryl Horbushko on 09.11.2023.
//

import Foundation

public struct Coordinates: Codable, Equatable, Hashable, Sendable {

  public typealias Point = [Double]
  public typealias Line = [[Double]]
  public typealias Polygon = [[[Double]]]
  public typealias MultiPolygon = [[[[Double]]]]

  public var point: Point?
  public var line: Line?
  public var polygon: Polygon?
  public var multiPolygon: MultiPolygon?

  public init(from decoder: Decoder) throws {
    let container = try decoder.singleValueContainer()

    if let point = try? container.decode(Point.self) {
      self.point = point
      return
    }
    if let line = try? container.decode(Line.self) {
      self.line = line
      return
    }
    if let polygon = try? container.decode(Polygon.self) {
      self.polygon = polygon
      return
    }
    if let multiPolygon = try? container.decode(MultiPolygon.self) {
      self.multiPolygon = multiPolygon
      return
    }

    throw DecodingError.valueNotFound(
      Coordinates.self,
      .init(codingPath: [], debugDescription: "")
    )
  }
}

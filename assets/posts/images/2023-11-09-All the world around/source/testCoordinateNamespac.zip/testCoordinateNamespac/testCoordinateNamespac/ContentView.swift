//
//  ContentView.swift
//  testCoordinateNamespac
//
//  Created by Kyryl Horbushko on 07.11.2023.
//

import SwiftUI

import GeoJSON

struct ContentView: View {

  @State private var features: [Feature] = []
  @State private var selectedFeatureName: String? = nil
  @State private var zoom: Double = 1
  @State private var zoomAnchor: UnitPoint = .center
  @State private var offsetX: Double = 0
  @State private var offsetY: Double = 0

  var body: some View {

    VStack {
      Image(systemName: "globe")
        .imageScale(.large)
        .foregroundStyle(.tint)
      Text("Hello, world!")

      ZStack {
        GeometryReader { proxy in

          ForEach(features, id: \.self) { element in

            MapPolygon(element)
              .stroke(.red, style: StrokeStyle(lineWidth: 0.25))
              .fill(element.name == selectedFeatureName ? .blue : .yellow)
              .onTapGesture { _ in
                let unselected = element.name == selectedFeatureName

                let bb = element.bBox
                  .map({ $0.toPointIn(.init(origin: .zero, size: proxy.size)) })
                let elementWidth = abs(bb[0].x - bb[1].x)
                let elementHeight = abs(bb[0].y - bb[1].y)

                let elementWidthN =  proxy.size.width / elementWidth
                let elementHeightN = proxy.size.height / elementHeight

                let maxKoef = min(min(elementWidthN, elementHeightN) * 0.9, 10)

                let anchor = UnitPoint(
                  x: (bb[1].x - abs(bb[1].x - bb[0].x)/2) / proxy.size.width,
                  y: (bb[1].y - abs(bb[1].y - bb[0].y)/2) / proxy.size.height
                )

                zoom = unselected ? 1.0 : maxKoef
                selectedFeatureName = unselected ? nil : element.name
                zoomAnchor = unselected ? .center : anchor
                offsetX = unselected ? 0 : (0.5 - anchor.x) * proxy.size.width
                offsetY = unselected ? 0 : (-anchor.y) * proxy.size.height
              }
              .overlay {
                Group {
                  let center = element.center
                    .toPointIn(.init(origin: .zero, size: proxy.size))

                  let fontSize: CGFloat = 6 * (zoom / 10)
                  Text(element.name)
                    .minimumScaleFactor(0.1)
                    .font(.system(size: fontSize))
                    .opacity(element.name == selectedFeatureName ? 1 : 0)
                    .offset(x: center.x - proxy.size.width / 2 - fontSize / 2,
                            y: center.y - proxy.size.height / 2 - fontSize / 2)
                }
              }
              .zIndex(element.name == selectedFeatureName ? 1000 : 1)
          }
        }
        .aspectRatio(contentMode: .fit)
        .scaleEffect(zoom, anchor: zoomAnchor)
        .offset(x: offsetX, y: offsetY)
        .animation(.easeInOut, value: selectedFeatureName)
      }
      .task {
        do {
          let geoJSON = try await GeoJson.loadCountries().value
          features = geoJSON.features
        } catch {
          print(error)
        }
      }

      Spacer()
    }
    .background(.blue.opacity(0.5))
  }
}

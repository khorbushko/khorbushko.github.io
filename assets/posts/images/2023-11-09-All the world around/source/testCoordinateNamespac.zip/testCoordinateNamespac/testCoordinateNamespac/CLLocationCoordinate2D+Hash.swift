//
//  CLLocationCoordinate2D+Hash.swift
//  testCoordinateNamespac
//
//  Created by Kyryl Horbushko on 09.11.2023.
//

import UIKit
import CoreLocation

extension CLLocationCoordinate2D: Hashable {
  public static func == (lhs: CLLocationCoordinate2D, rhs: CLLocationCoordinate2D) -> Bool {
    lhs.latitude == rhs.latitude && lhs.longitude == lhs.longitude
  }

  public func hash(into hasher: inout Hasher) {
    hasher.combine(latitude.hashValue)
    hasher.combine(longitude.hashValue)
  }
}

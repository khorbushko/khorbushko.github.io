//
//  testCoordinateNamespacApp.swift
//  testCoordinateNamespac
//
//  Created by Kyryl Horbushko on 07.11.2023.
//

import SwiftUI

@main
struct testCoordinateNamespacApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}

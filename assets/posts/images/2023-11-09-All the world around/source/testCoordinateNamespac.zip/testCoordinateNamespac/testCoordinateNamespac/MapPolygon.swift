//
//  MapPolygon.swift
//  testCoordinateNamespac
//
//  Created by Kyryl Horbushko on 09.11.2023.
//

import Foundation
import UIKit
import SwiftUI
import CoreLocation

import GeoJSON

struct MapPolygon: Shape {

  let coordinatePolygonPoints: [[CLLocationCoordinate2D]]

  func path(in rect: CGRect) -> Path {
    let root = coordinatePolygonPoints.map {
      $0.map { $0.toPointIn(rect) }
    }

    let path: UIBezierPath = root.map { points in
      if points.isEmpty {
        return UIBezierPath()
      }

      let path = UIBezierPath()
      path.move(to: points[0])
      for point in points {
        if point.x.isNaN || point.y.isNaN {
          print(point)
        }
        path.addLine(to: point)
      }
      path.close()

      return path
    }
      .reduce(.init(), { $0.append($1); return $0 })

    return .init(path.cgPath)
  }
}

extension MapPolygon: Hashable, Equatable {

  public func hash(into hasher: inout Hasher) {
    hasher.combine(coordinatePolygonPoints.hashValue)
  }
}

extension CLLocationCoordinate2D {
  func toPointIn(_ rect: CGRect) -> CGPoint {
    let y = ((-1 * latitude) + 90) * (rect.height / 180)
    let x = (longitude + 180) * (rect.width / 360)
    return .init(x: x, y: y)
  }
}

extension MapPolygon {
  init(_ feature: Feature) {
    self = .init(coordinatePolygonPoints: feature.polygons)
  }
}

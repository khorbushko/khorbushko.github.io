//
//  Feature+Polygon.swift
//
//
//  Created by Kyryl Horbushko on 09.11.2023.
//

import Foundation
import CoreLocation

public typealias GeoJsonPolygon = [CLLocationCoordinate2D]

extension Feature {
  public var polygons: [GeoJsonPolygon] {
    func toPointsMap(_ pointMap: [[Double]]) -> [CLLocationCoordinate2D] {
      pointMap
        .map { coordinate in
            .init(latitude: coordinate[1], longitude: coordinate[0])
        }
    }

    var objects: [GeoJsonPolygon] = []
    if geometry.type == .polygon,
       let coordinates = geometry.coordinates.polygon {
      objects = coordinates
        .map(toPointsMap(_:))
    }
    if geometry.type == .multiPolygon,
       let coordinates = geometry.coordinates.multiPolygon {
      objects = coordinates
        .map({ $0
          .map(toPointsMap(_:))
        })
        .flatMap({ $0 })
    }

    return objects
  }
}

import Foundation
import CoreLocation

// MARK: - GeoJson
public struct GeoJson: Codable, Equatable, Hashable, Sendable {
  public let type, name: String
  public let crs: CRS

  public let features: [Feature]
  public let bbox: [Double]
}

//
//  FeatureProperties.swift
//
//
//  Created by Kyryl Horbushko on 09.11.2023.
//

import Foundation

public struct FeatureProperties: Codable, Equatable, Hashable, Sendable {
  public let featurecla: FclassIso
  public let scalerank, labelrank: Int
  public let sovereignt, sovA3: String
  public let adm0Dif, level: Int
  public let type: TYPEEnum
  public let tlc: String?
  public let admin, adm0A3: String
  public let geouDif: Int
  public let geounit, guA3: String
  public let suDif: Int
  public let subunit, suA3: String
  public let brkDiff: Int
  public let name, nameLong, brkA3, brkName: String
  public let abbrev, postal: String
  public let formalEn, formalFr, nameCiawf, noteAdm0: String?
  public let noteBrk: String?
  public let nameSort: String
  public let nameAlt: String?
  public let mapcolor7, mapcolor8, mapcolor9, mapcolor13: Int
  public let popEst: Double
  public let popRank, popYear, gdpMd, gdpYear: Int
  public let economy: Economy
  public let incomeGrp: IncomeGrp
  public let fips10, isoA2, isoA2Eh, isoA3: String
  public let isoA3Eh, isoN3, isoN3Eh, unA3: String
  public let wbA2, wbA3: String
  public let woeId, woeIdEh: Int
  public let woeNote, adm0Iso: String
  public let adm0Diff: String?
  public let adm0Tlc, adm0A3Us, adm0A3Fr, adm0A3Ru: String
  public let adm0A3Es, adm0A3Cn, adm0A3Tw, adm0A3In: String
  public let adm0A3Np, adm0A3Pk, adm0A3De, adm0A3Gb: String
  public let adm0A3Br, adm0A3Il, adm0A3Ps, adm0A3Sa: String
  public let adm0A3Eg, adm0A3Ma, adm0A3Pt, adm0A3Ar: String
  public let adm0A3Jp, adm0A3Ko, adm0A3Vn, adm0A3Tr: String
  public let adm0A3Id, adm0A3Pl, adm0A3Gr, adm0A3It: String
  public let adm0A3Nl, adm0A3Se, adm0A3Bd, adm0A3Ua: String
  public let adm0A3Un, adm0A3Wb: Int
  public let continent, regionUn: Continent
  public let subregion: String
  public let regionWb: RegionWb
  public let nameLen, longLen, abbrevLen, tiny: Int
  public let homepart: Int
  public let minZoom, minLabel, maxLabel, labelX: Double
  public let labelY: Double
  public let neId: Int
  public let wikidataid, nameAr, nameBn, nameDe: String
  public let nameEn, nameEs, nameFa, nameFr: String
  public let nameEl, nameHe, nameHi, nameHu: String
  public let nameId, nameIt, nameJa, nameKo: String
  public let nameNl, namePl, namePt, nameRu: String
  public let nameSv, nameTr, nameUk, nameUr: String
  public let nameVi, nameZh, nameZht: String
  public let fclassIso: FclassIso
  public let tlcDiff: String?
  public let fclassTlc: FclassIso
  public let fclassUs: String?
  public let fclassFr: FclassIso?
  public let fclassRu: String?
  public let fclassEs, fclassCn, fclassTw: FclassIso?
  public let fclassIn: String?
  public let fclassNp, fclassPk, fclassDe, fclassGb: FclassIso?
  public let fclassBr, fclassIl, fclassPs, fclassSa: FclassIso?
  public let fclassEg, fclassMa, fclassPt, fclassAr: FclassIso?
  public let fclassJp, fclassKo, fclassVn, fclassTr: FclassIso?
  public let fclassId, fclassPl, fclassGr, fclassIt: FclassIso?
  public let fclassNl, fclassSe, fclassBd, fclassUa: FclassIso?

  enum CodingKeys: String, CodingKey {
    case featurecla, scalerank
    case labelrank = "LABELRANK"
    case sovereignt = "SOVEREIGNT"
    case sovA3 = "SOV_A3"
    case adm0Dif = "ADM0_DIF"
    case level = "LEVEL"
    case type = "TYPE"
    case tlc = "TLC"
    case admin = "ADMIN"
    case adm0A3 = "ADM0_A3"
    case geouDif = "GEOU_DIF"
    case geounit = "GEOUNIT"
    case guA3 = "GU_A3"
    case suDif = "SU_DIF"
    case subunit = "SUBUNIT"
    case suA3 = "SU_A3"
    case brkDiff = "BRK_DIFF"
    case name = "NAME"
    case nameLong = "NAME_LONG"
    case brkA3 = "BRK_A3"
    case brkName = "BRK_NAME"
    case abbrev = "ABBREV"
    case postal = "POSTAL"
    case formalEn = "FORMAL_EN"
    case formalFr = "FORMAL_FR"
    case nameCiawf = "NAME_CIAWF"
    case noteAdm0 = "NOTE_ADM0"
    case noteBrk = "NOTE_BRK"
    case nameSort = "NAME_SORT"
    case nameAlt = "NAME_ALT"
    case mapcolor7 = "MAPCOLOR7"
    case mapcolor8 = "MAPCOLOR8"
    case mapcolor9 = "MAPCOLOR9"
    case mapcolor13 = "MAPCOLOR13"
    case popEst = "POP_EST"
    case popRank = "POP_RANK"
    case popYear = "POP_YEAR"
    case gdpMd = "GDP_MD"
    case gdpYear = "GDP_YEAR"
    case economy = "ECONOMY"
    case incomeGrp = "INCOME_GRP"
    case fips10 = "FIPS_10"
    case isoA2 = "ISO_A2"
    case isoA2Eh = "ISO_A2_EH"
    case isoA3 = "ISO_A3"
    case isoA3Eh = "ISO_A3_EH"
    case isoN3 = "ISO_N3"
    case isoN3Eh = "ISO_N3_EH"
    case unA3 = "UN_A3"
    case wbA2 = "WB_A2"
    case wbA3 = "WB_A3"
    case woeId = "WOE_ID"
    case woeIdEh = "WOE_ID_EH"
    case woeNote = "WOE_NOTE"
    case adm0Iso = "ADM0_ISO"
    case adm0Diff = "ADM0_DIFF"
    case adm0Tlc = "ADM0_TLC"
    case adm0A3Us = "ADM0_A3_US"
    case adm0A3Fr = "ADM0_A3_FR"
    case adm0A3Ru = "ADM0_A3_RU"
    case adm0A3Es = "ADM0_A3_ES"
    case adm0A3Cn = "ADM0_A3_CN"
    case adm0A3Tw = "ADM0_A3_TW"
    case adm0A3In = "ADM0_A3_IN"
    case adm0A3Np = "ADM0_A3_NP"
    case adm0A3Pk = "ADM0_A3_PK"
    case adm0A3De = "ADM0_A3_DE"
    case adm0A3Gb = "ADM0_A3_GB"
    case adm0A3Br = "ADM0_A3_BR"
    case adm0A3Il = "ADM0_A3_IL"
    case adm0A3Ps = "ADM0_A3_PS"
    case adm0A3Sa = "ADM0_A3_SA"
    case adm0A3Eg = "ADM0_A3_EG"
    case adm0A3Ma = "ADM0_A3_MA"
    case adm0A3Pt = "ADM0_A3_PT"
    case adm0A3Ar = "ADM0_A3_AR"
    case adm0A3Jp = "ADM0_A3_JP"
    case adm0A3Ko = "ADM0_A3_KO"
    case adm0A3Vn = "ADM0_A3_VN"
    case adm0A3Tr = "ADM0_A3_TR"
    case adm0A3Id = "ADM0_A3_ID"
    case adm0A3Pl = "ADM0_A3_PL"
    case adm0A3Gr = "ADM0_A3_GR"
    case adm0A3It = "ADM0_A3_IT"
    case adm0A3Nl = "ADM0_A3_NL"
    case adm0A3Se = "ADM0_A3_SE"
    case adm0A3Bd = "ADM0_A3_BD"
    case adm0A3Ua = "ADM0_A3_UA"
    case adm0A3Un = "ADM0_A3_UN"
    case adm0A3Wb = "ADM0_A3_WB"
    case continent = "CONTINENT"
    case regionUn = "REGION_UN"
    case subregion = "SUBREGION"
    case regionWb = "REGION_WB"
    case nameLen = "NAME_LEN"
    case longLen = "LONG_LEN"
    case abbrevLen = "ABBREV_LEN"
    case tiny = "TINY"
    case homepart = "HOMEPART"
    case minZoom = "MIN_ZOOM"
    case minLabel = "MIN_LABEL"
    case maxLabel = "MAX_LABEL"
    case labelX = "LABEL_X"
    case labelY = "LABEL_Y"
    case neId = "NE_ID"
    case wikidataid = "WIKIDATAID"
    case nameAr = "NAME_AR"
    case nameBn = "NAME_BN"
    case nameDe = "NAME_DE"
    case nameEn = "NAME_EN"
    case nameEs = "NAME_ES"
    case nameFa = "NAME_FA"
    case nameFr = "NAME_FR"
    case nameEl = "NAME_EL"
    case nameHe = "NAME_HE"
    case nameHi = "NAME_HI"
    case nameHu = "NAME_HU"
    case nameId = "NAME_ID"
    case nameIt = "NAME_IT"
    case nameJa = "NAME_JA"
    case nameKo = "NAME_KO"
    case nameNl = "NAME_NL"
    case namePl = "NAME_PL"
    case namePt = "NAME_PT"
    case nameRu = "NAME_RU"
    case nameSv = "NAME_SV"
    case nameTr = "NAME_TR"
    case nameUk = "NAME_UK"
    case nameUr = "NAME_UR"
    case nameVi = "NAME_VI"
    case nameZh = "NAME_ZH"
    case nameZht = "NAME_ZHT"
    case fclassIso = "FCLASS_ISO"
    case tlcDiff = "TLC_DIFF"
    case fclassTlc = "FCLASS_TLC"
    case fclassUs = "FCLASS_US"
    case fclassFr = "FCLASS_FR"
    case fclassRu = "FCLASS_RU"
    case fclassEs = "FCLASS_ES"
    case fclassCn = "FCLASS_CN"
    case fclassTw = "FCLASS_TW"
    case fclassIn = "FCLASS_IN"
    case fclassNp = "FCLASS_NP"
    case fclassPk = "FCLASS_PK"
    case fclassDe = "FCLASS_DE"
    case fclassGb = "FCLASS_GB"
    case fclassBr = "FCLASS_BR"
    case fclassIl = "FCLASS_IL"
    case fclassPs = "FCLASS_PS"
    case fclassSa = "FCLASS_SA"
    case fclassEg = "FCLASS_EG"
    case fclassMa = "FCLASS_MA"
    case fclassPt = "FCLASS_PT"
    case fclassAr = "FCLASS_AR"
    case fclassJp = "FCLASS_JP"
    case fclassKo = "FCLASS_KO"
    case fclassVn = "FCLASS_VN"
    case fclassTr = "FCLASS_TR"
    case fclassId = "FCLASS_ID"
    case fclassPl = "FCLASS_PL"
    case fclassGr = "FCLASS_GR"
    case fclassIt = "FCLASS_IT"
    case fclassNl = "FCLASS_NL"
    case fclassSe = "FCLASS_SE"
    case fclassBd = "FCLASS_BD"
    case fclassUa = "FCLASS_UA"
  }
}

public enum Continent: String, Codable, Equatable, Hashable, Sendable {
  case africa = "Africa"
  case americas = "Americas"
  case antarctica = "Antarctica"
  case asia = "Asia"
  case europe = "Europe"
  case northAmerica = "North America"
  case oceania = "Oceania"
  case sevenSeasOpenOcean = "Seven seas (open ocean)"
  case southAmerica = "South America"
}

public enum Economy: String, Codable, Equatable, Hashable, Sendable {
  case the1DevelopedRegionG7 = "1. Developed region: G7"
  case the2DevelopedRegionNonG7 = "2. Developed region: nonG7"
  case the3EmergingRegionBric = "3. Emerging region: BRIC"
  case the4EmergingRegionMikt = "4. Emerging region: MIKT"
  case the5EmergingRegionG20 = "5. Emerging region: G20"
  case the6DevelopingRegion = "6. Developing region"
  case the7LeastDevelopedRegion = "7. Least developed region"
}

public enum FclassIso: String, Codable, Equatable, Hashable, Sendable {
  case admin0Country = "Admin-0 country"
  case admin0Dependency = "Admin-0 dependency"
  case admin1StatesProvinces = "Admin-1 states provinces"
  case unrecognized = "Unrecognized"
}

public enum IncomeGrp: String, Codable, Equatable, Hashable, Sendable {
  case the1HighIncomeOecd = "1. High income: OECD"
  case the2HighIncomeNonOecd = "2. High income: nonOECD"
  case the3UpperMiddleIncome = "3. Upper middle income"
  case the4LowerMiddleIncome = "4. Lower middle income"
  case the5LowIncome = "5. Low income"
}

public enum RegionWb: String, Codable, Equatable, Hashable, Sendable {
  case antarctica = "Antarctica"
  case eastAsiaPacific = "East Asia & Pacific"
  case europeCentralAsia = "Europe & Central Asia"
  case latinAmericaCaribbean = "Latin America & Caribbean"
  case middleEastNorthAfrica = "Middle East & North Africa"
  case northAmerica = "North America"
  case southAsia = "South Asia"
  case subSaharanAfrica = "Sub-Saharan Africa"
}

public enum TYPEEnum: String, Codable, Equatable, Hashable, Sendable {
  case country = "Country"
  case dependency = "Dependency"
  case disputed = "Disputed"
  case indeterminate = "Indeterminate"
  case sovereignCountry = "Sovereign country"
  case sovereignty = "Sovereignty"
}

public enum FeatureType: String, Codable, Equatable, Hashable, Sendable {
  case feature = "Feature"
}


// swift-tools-version: 5.9

import PackageDescription

let package = Package(
  name: "GeoJSON",
  platforms: [.iOS(.v14)],
  products: [
    .library(
      name: "GeoJSON",
      targets: ["GeoJSON"]
    ),
  ],
  targets: [
    .target(
      name: "GeoJSON",
      path: "Sources",
      resources: [
        .process("Resources/countries_110.geojson")
      ]
    ),
    .testTarget(
      name: "GeoJSONTests",
      dependencies: ["GeoJSON"]
    ),
  ],
  swiftLanguageVersions: [.v5]
)

//
//  
//  BartyCrouch.swift
//  testLocalization
//
//  Created by Kyryl Horbushko on 22.03.2021.
//
//

import Foundation

enum BartyCrouch {
  enum SupportedLanguage: String {

    case english = "en"
    case spanish = "es"
    case ukrainian = "uk-UA"
  }

  static func translate(
    key: String,
    translations: [SupportedLanguage: String],
    comment: String? = nil
  ) -> String {
    let typeName = String(describing: BartyCrouch.self)
    let methodName = #function

    debugPrint(
      "Warning: [BartyCrouch]",
      "Untransformed \(typeName).\(methodName) method call found with key '\(key)' and base translations '\(translations)'.",
      "Please ensure that BartyCrouch is installed and configured correctly."
    )

    return "BC: TRANSFORMATION FAILED!"
  }
}

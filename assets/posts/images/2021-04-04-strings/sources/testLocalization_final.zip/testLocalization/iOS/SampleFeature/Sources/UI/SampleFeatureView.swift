//
//  SampleFeatureView.swift
//  testLocalization
//
//  Created by Kyryl Horbushko on 22.03.2021.
//

import Combine
import SwiftUI

public struct SampleFeatureView: View {

  public init() { }

  public var body: some View {
      let title = L10n.Sample.feature
      Text(title)
  }
}

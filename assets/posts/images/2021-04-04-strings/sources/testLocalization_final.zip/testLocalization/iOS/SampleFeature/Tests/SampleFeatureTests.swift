//
//  
//  SampleFeatureTests.swift
//  testLocalization
//
//  Created by Kyryl Horbushko on 22.03.2021.
//
//

import SampleFeature
import Combine
import ComposableArchitecture
import XCTest

extension SampleFeatureEnvironment {
  static func resetServers() {
    <#function body#>
  }

  static var mock = SampleFeatureEnvironment(
    <#fields#>
  )
}

final class SampleFeatureTests: XCTestCase {
  override func setUp() {
    super.setUp()

    SampleFeatureEnvironment.resetServers()
  }

  override func tearDown() {
    super.tearDown()

    <#cleanUp#>
  }

  func /*@START_MENU_TOKEN@*/testSomething/*@END_MENU_TOKEN@*/() {
    let store = TestStore(
      initialState: SampleFeatureState(),
      reducer: SampleFeatureReducers.defaultReducer,
      environment: .mock
    )

    store.assert(
      .send(<#parameters#>) {
        <#function body#>
      },
      .do {
        <#function body#>
      },
      .receive(<#parameters#>) {
        <#function body#>
      }
    )
  }
}

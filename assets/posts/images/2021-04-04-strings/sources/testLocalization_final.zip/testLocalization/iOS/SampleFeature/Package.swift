// swift-tools-version:5.3
// The swift-tools-version declares the minimum version of Swift required to build this package.
// localizableSP
// bartyCrouch

import PackageDescription

let package = Package(
    name: "SampleFeature",
    defaultLocalization: "en",
    platforms: [
        .iOS(.v14),
    ],
    products: [
        .library(
            name: "SampleFeature",
            targets: ["SampleFeature"]
        ),
    ],
    dependencies: [
    ],
    targets: [
        .target(
            name: "SampleFeature",
            dependencies: [],
            path: "Sources"
        ),
        .testTarget(
            name: "SampleFeatureTests",
            dependencies: [
                .target(name: "SampleFeature"),
            ],
            path: "Tests"
        ),
    ],
    swiftLanguageVersions: [.v5]
)

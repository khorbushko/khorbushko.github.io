//
//  ContentView.swift
//  Shared
//
//  Created by Kyryl Horbushko on 18.03.2021.
//

import SwiftUI
import SampleFeature

struct ContentView: View {
    var body: some View {
      SampleFeatureView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//
//  ContentView.swift
//  Shared
//
//  Created by Kyryl Horbushko on 18.03.2021.
//

import SwiftUI
import MyLibrary

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
      TestView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

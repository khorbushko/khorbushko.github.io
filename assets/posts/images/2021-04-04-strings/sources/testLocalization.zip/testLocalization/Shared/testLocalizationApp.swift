//
//  testLocalizationApp.swift
//  Shared
//
//  Created by Kyryl Horbushko on 18.03.2021.
//

import SwiftUI

@main
struct testLocalizationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

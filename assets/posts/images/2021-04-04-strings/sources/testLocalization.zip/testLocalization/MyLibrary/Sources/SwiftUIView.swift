//
//  SwiftUIView.swift
//  
//
//  Created by Kyryl Horbushko on 18.03.2021.
//

import SwiftUI

public struct TestView: View {

  public init() {}

  public var body: some View {
    VStack {
    let string = L10n.welcome
      let text = NSLocalizedString("welcome", tableName: "Localizable", bundle: .module, value: "", comment: "")
      Text("welcome", bundle: .module)

      Text(text)
    }
  }
}

struct TestView_Previews: PreviewProvider {
  static var previews: some View {
    TestView()
      .environment(\.locale, Locale(identifier: "es"))
  }
}


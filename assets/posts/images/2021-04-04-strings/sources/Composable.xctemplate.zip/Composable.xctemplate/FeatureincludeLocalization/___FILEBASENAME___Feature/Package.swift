// swift-tools-version:5.3
// The swift-tools-version declares the minimum version of Swift required to build this package.
// localizableSP
// bartyCrouch

import PackageDescription

let package = Package(
    name: "___VARIABLE_productName:identifier___Feature",
    defaultLocalization: "en",
    platforms: [
        .iOS(.v14),
    ],
    products: [
        .library(
            name: "___VARIABLE_productName:identifier___Feature",
            targets: ["___VARIABLE_productName:identifier___Feature"]
        ),
    ],
    dependencies: [
        .package(
            name: "swift-composable-architecture",
            url: "https://github.com/pointfreeco/swift-composable-architecture",
            .exact("0.16.0")
        ),
    ],
    targets: [
        .target(
            name: "___VARIABLE_productName:identifier___Feature",
            dependencies: [
                .product(
                    name: "ComposableArchitecture",
                    package: "swift-composable-architecture"
                ),
            ],
            path: "Sources"
        ),
        .testTarget(
            name: "___VARIABLE_productName:identifier___FeatureTests",
            dependencies: [
                .target(name: "___VARIABLE_productName:identifier___Feature"),
            ],
            path: "Tests"
        ),
    ],
    swiftLanguageVersions: [.v5]
)

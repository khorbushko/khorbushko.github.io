//
//  ___FILEHEADER___
//

import Foundation

enum BartyCrouch {
  enum SupportedLanguage: String {

    case english = "en"
  }

  static func translate(
    key: String,
    translations: [SupportedLanguage: String],
    comment: String? = nil
  ) -> String {
    let typeName = String(describing: BartyCrouch.self)
    let methodName = #function

    debugPrint(
      "Warning: [BartyCrouch]",
      "Untransformed \(typeName).\(methodName) method call found with key '\(key)' and base translations '\(translations)'.",
      "Please ensure that BartyCrouch is installed and configured correctly."
    )

    return "BC: TRANSFORMATION FAILED!"
  }
}

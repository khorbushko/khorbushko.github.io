//
//  ___FILEHEADER___
//

import ___VARIABLE_productName:identifier___
import Combine
import ComposableArchitecture
import XCTest

extension ___VARIABLE_productName:identifier___Environment {
  static func resetServers() {
    <#function body#>
  }

  static var mock = ___VARIABLE_productName:identifier___Environment(
    <#fields#>
  )
}

final class ___VARIABLE_productName:identifier___Tests: XCTestCase {
  override func setUp() {
    super.setUp()

    ___VARIABLE_productName:identifier___Environment.resetServers()
  }

  override func tearDown() {
    super.tearDown()

    <#cleanUp#>
  }

  func /*@START_MENU_TOKEN@*/testSomething/*@END_MENU_TOKEN@*/() {
    let store = TestStore(
      initialState: ___VARIABLE_productName:identifier___State(),
      reducer: ___VARIABLE_productName:identifier___Reducers.defaultReducer,
      environment: .mock
    )

    store.assert(
      .send(<#parameters#>) {
        <#function body#>
      },
      .do {
        <#function body#>
      },
      .receive(<#parameters#>) {
        <#function body#>
      }
    )
  }
}

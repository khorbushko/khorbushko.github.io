//
//  ___FILEHEADER___
//

import Combine
import ComposableArchitecture
import Foundation

public struct ___VARIABLE_productName:identifier___State: Hashable {
  <#fields#>

  public init() {}
}

public enum ___VARIABLE_productName:identifier___Action: Equatable {
  case <#case#>
}

public struct ___VARIABLE_productName:identifier___Environment {
  <#fields#>

  public init() {}
}

public enum  ___VARIABLE_productName:identifier___Reducers {
  public static let defaultReducer = Reducer<___VARIABLE_productName:identifier___State, ___VARIABLE_productName:identifier___Action, ___VARIABLE_productName:identifier___Environment> {
    state, action, environment in
      switch action {
        case <#pattern#>:
          <#code#>
        default:
          <#code#>
      }
    }
}

//
//  ___FILEHEADER___
//

import ___VARIABLE_productName:identifier___Feature
import Combine
import ComposableArchitecture
import XCTest

extension ___VARIABLE_productName:identifier___FeatureEnvironment {
  static func resetServers() {
    <#function body#>
  }

  static var mock = ___VARIABLE_productName:identifier___FeatureEnvironment(
    <#fields#>
  )
}

final class ___VARIABLE_productName:identifier___FeatureTests: XCTestCase {
  override func setUp() {
    super.setUp()

    ___VARIABLE_productName:identifier___FeatureEnvironment.resetServers()
  }

  override func tearDown() {
    super.tearDown()

    <#cleanUp#>
  }

  func /*@START_MENU_TOKEN@*/testSomething/*@END_MENU_TOKEN@*/() {
    let store = TestStore(
      initialState: ___VARIABLE_productName:identifier___FeatureState(),
      reducer: ___VARIABLE_productName:identifier___FeatureReducers.defaultReducer,
      environment: .mock
    )

    store.assert(
      .send(<#parameters#>) {
        <#function body#>
      },
      .do {
        <#function body#>
      },
      .receive(<#parameters#>) {
        <#function body#>
      }
    )
  }
}

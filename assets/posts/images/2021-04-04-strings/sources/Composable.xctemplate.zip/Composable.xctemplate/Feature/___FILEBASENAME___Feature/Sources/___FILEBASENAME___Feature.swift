//
//  ___FILEHEADER___
//

import Foundation

public extension ___VARIABLE_productName:identifier___FeatureEnvironment {
  static var live = ___VARIABLE_productName:identifier___FeatureEnvironment(
    <#fields#>
  )

  static var preview = ___VARIABLE_productName:identifier___FeatureEnvironment(
    <#fields#>
  )
}

//
//  ___FILEHEADER___
//

import Combine
import ComposableArchitecture
import Foundation

public struct ___VARIABLE_productName:identifier___FeatureState: Hashable {
  <#fields#>

  public init() {}
}

public enum ___VARIABLE_productName:identifier___FeatureAction: Equatable {
  case <#case#>
}

public struct ___VARIABLE_productName:identifier___FeatureEnvironment {
  <#fields#>

  public init() {}
}

public enum  ___VARIABLE_productName:identifier___FeatureReducers {
  public static let defaultReducer = Reducer<___VARIABLE_productName:identifier___FeatureState, ___VARIABLE_productName:identifier___FeatureAction, ___VARIABLE_productName:identifier___FeatureEnvironment> {
    state, action, environment in
      switch action {
        case <#pattern#>:
          <#code#>
        default:
          <#code#>
      }
    }
}

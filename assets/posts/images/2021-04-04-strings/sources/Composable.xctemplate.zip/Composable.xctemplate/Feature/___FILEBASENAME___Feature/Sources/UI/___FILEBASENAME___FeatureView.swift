//___FILEHEADER___

import Combine
import ComposableArchitecture
import SwiftUI

struct ___VARIABLE_productName:identifier___FeatureView: View {
  let store: Store<___VARIABLE_productName:identifier___FeatureState, ___VARIABLE_productName:identifier___FeatureAction>

  init(store: Store<___VARIABLE_productName:identifier___FeatureState, ___VARIABLE_productName:identifier___FeatureAction>) {
    self.store = store
  }

  var body: some View {
    WithViewStore(store) { viewStore in
      Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
  }
}

struct ___VARIABLE_productName:identifier___FeatureView_Previews: PreviewProvider {
  static var previews: some View {
    ___VARIABLE_productName:identifier___FeatureView(
    store: Store(
      initialState: ___VARIABLE_productName:identifier___FeatureState(),
      reducer: ___VARIABLE_productName:identifier___FeatureReducers.defaultReducer,
      environment: ___VARIABLE_productName:identifier___FeatureEnvironment.preview
      )
    )
  }
}


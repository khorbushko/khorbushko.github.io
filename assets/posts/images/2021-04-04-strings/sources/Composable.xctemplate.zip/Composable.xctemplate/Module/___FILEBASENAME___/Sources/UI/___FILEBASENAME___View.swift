//___FILEHEADER___

import Combine
import ComposableArchitecture
import SwiftUI

struct ___VARIABLE_productName:identifier___View: View {
  let store: Store<___VARIABLE_productName:identifier___State, ___VARIABLE_productName:identifier___Action>

  init(store: Store<___VARIABLE_productName:identifier___State, ___VARIABLE_productName:identifier___Action>) {
    self.store = store
  }

  var body: some View {
    WithViewStore(store) { viewStore in
      Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
  }
}

struct ___VARIABLE_productName:identifier___View_Previews: PreviewProvider {
  static var previews: some View {
    ___VARIABLE_productName:identifier___View(
    store: Store(
      initialState: ___VARIABLE_productName:identifier___State(),
      reducer: ___VARIABLE_productName:identifier___Reducers.defaultReducer,
      environment: ___VARIABLE_productName:identifier___Environment.preview
      )
    )
  }
}


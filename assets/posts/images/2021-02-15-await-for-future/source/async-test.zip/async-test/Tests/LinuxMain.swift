import XCTest

import async_testTests

var tests = [XCTestCaseEntry]()
tests += async_testTests.allTests()
XCTMain(tests)

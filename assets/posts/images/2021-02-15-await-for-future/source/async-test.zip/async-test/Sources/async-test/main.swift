import Foundation
import _Concurrency

print("Hello, world!")

func runMeAsync() async {
    for idx in 1...3 {
        sleep(1)
        print("\(idx) at \(Date())")
    }
}

// error!

// Because only async code can call other async code, this proposal provides no way to initiate asynchronous code. This is intentional: all asynchronous code runs within the context of a “task” - https://github.com/apple/swift-evolution/blob/main/proposals/0296-async-await.md#launching-async-tasks

//runMeAsync() // error
//
//DispatchQueue.main.async {
//    await runMeAsync()
//}

// option 1
//we need async entry point

//let handle = Task.runDetached(operation: {
//    await runMeAsync()
//})
//
//Thread.sleep(forTimeInterval: 10) // needet for app holding
//
////DispatchQueue.main.async {
////    try? await asyncMethod(name: "From async")
////}
//
//runAsyncAndBlock {
//    try? await runMeAsync()
//}

// option 2
// reuse code
//func doSomething(_ callback: (() -> ())?) {
//    DispatchQueue.global().asyncAfter(deadline: .now() + 5) {
//        print("from \(#function) \(Date())")
//        callback?()
//    }
//}
//
//func doSomethingAsync() async -> () {
//    await withUnsafeContinuation { continuation in
//        doSomething {
//            continuation.resume(returning: ())
//        }
//    }
//}
//
//runAsyncAndBlock {
//    await doSomethingAsync()
//}


// option 3
// use result of async computation in function

func doSomething(_ callback: (() -> ())?) {
    DispatchQueue.global().asyncAfter(deadline: .now() + 5) {
        print("from \(#function) \(Date())")
        callback?()
    }
}

func doSomethingAsync2() async -> String {
    await withUnsafeContinuation { continuation in
        doSomething {
            continuation.resume(returning: #function)
        }
    }
}

@asyncHandler func doSomethingWithAsyncDataInsideFunction() {
    let result: String? = try? await doSomethingAsync2()
    print("The result is \(result), obtained in \(#function)")
}

doSomethingWithAsyncDataInsideFunction()

Thread.sleep(forTimeInterval: 10) // needet for app holding

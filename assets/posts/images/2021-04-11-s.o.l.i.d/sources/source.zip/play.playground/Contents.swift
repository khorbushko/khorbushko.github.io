//SRP

class Transport {

  func performMaintenance() {
    // maintanance can be done by command of specialists
  }

  func drive() {
    // drive within some drivers
  }
}

struct TransportData {
  // some data about transport
}

class MaintenanceTeam {
  func performMaintenance(_ object: TransportData) {
    // maintanance can be done by command of specialists
  }
}

class Driver {
  func drive(_ transport: TransportData) {
    // drive can be done within group of drivers
  }
}

protocol TransportControllable {

  func drive()
  func maintenance()
}

class Train: TransportControllable {

  private let data: TransportData
  private let driver: Driver
  private let maintenanceTeam: MaintenanceTeam

  init(
    data: TransportData,
    driver: Driver,
    maintenanceTeam: MaintenanceTeam
    ) {
    self.data = data
    self.driver = driver
    self.maintenanceTeam = maintenanceTeam
  }

  func drive() {
    driver.drive(data)
  }

  func maintenance() {
    maintenanceTeam.performMaintenance(data)
  }
}

// OCP

enum DriveMode {

  case basic
  case superFast
}

class Auto {

  func turnEngineOn() {

  }

  func addFuel() {

  }

  func drive(_ mode: DriveMode) {

  }
}

protocol Car {
  func turnEngineOn()
  func addFuel()
  func drive(_ mode: DriveMode)
}

class BasicCar: Car {
  func turnEngineOn() {

  }

  func addFuel() {

  }

  func drive(_ mode: DriveMode) {

  }
}

// inheritance
class SuperCar: BasicCar {
  override func drive(_ mode: DriveMode) {
    switch mode {
      case .basic:
        slowDrive()
      case .superFast:
        speedDrive()
    }
  }

  private func slowDrive() {
    // basic functionality
  }

  private func speedDrive() {
    // additional functionality
  }
}

// abstraction
class SuperCar2: Car {
  func turnEngineOn() {

  }

  func addFuel() {

  }

  func drive(_ mode: DriveMode) {
    switch mode {
      case .basic:
        slowDrive()
      case .superFast:
        speedDrive()
    }
  }

  private func slowDrive() {
    // basic functionality
  }

  private func speedDrive() {
    // additional functionality
  }
}

//LSP

//protocol Patient {
//  func tellSimptoms() -> String
//}
//
//class SickPerson: Patient {
//
//  func tellSimptoms() -> String {
//    "oh, ah"
//  }
//}
//
//class DeadPatient: Patient {
//  func tellSimptoms() -> String {
//    fatalError("dead patient can't talk")
//  }
//}
//
//class Doctor {
//  func inspectAPatient(patient: Patient) {
//    let simptoms = patient.tellSimptoms()
//    // do other stuff
//  }
//}
//
//let doctor = Doctor()
//doctor.askAPatient(patient: Patient())


protocol Patient {

}

protocol SimptomProvidablePatient: Patient {
  func tellSimptoms() -> String
}

class SickPerson: SimptomProvidablePatient {
  func tellSimptoms() -> String {
    "oh, ah"
  }
}

class VoicelessPatient: Patient {

}
class Doctor {
  func askAPatient(patient: SimptomProvidablePatient) {
    let simptoms = patient.tellSimptoms()
    // do other stuff
  }
}

let doctor = Doctor()
doctor.askAPatient(patient: SickPerson())

// ISP

protocol Bird {
  func speak()
  func fly()
  func jump()
}

class Sparrow: Bird {
  func jump() {
    // ok, sparrow can do this
  }
  func speak() {
    // ok, sparrow can do this too
  }
  func fly() {
    // ok, sparrow can do this also, it's a bird
  }
}

class Penguin: Bird {
  func jump() {
    // ok, penguin good at this - can jump up to 3 m!
  }
  func speak() {
    // ok, penguin can do this
  }
  func fly() {
    // oops, not possible to fly :(
  }
}


protocol Speakable {
  func speak()
}

protocol Flyable {
  func fly()
}

protocol Jumpable {
  func jump()
}

class Sparrow2: Speakable, Flyable, Jumpable {
  func jump() {
    // ok, sparrow can do this
  }
  func speak() {
    // ok, sparrow can do this too
  }
  func fly() {
    // ok, sparrow can do this also, it's a bird
  }
}

class Penguin2: Speakable, Jumpable {
  func jump() {
    // ok, penguin good at this - can jump up to 3 m!
  }
  func speak() {
    // ok, penguin can do this
  }
}

//DIP

struct File {

  var path: String
  var name: String
  var type: String
}

class FileHandle {

  func open(_ file: File) {

  }

  func close(_ file: File) {

  }
}

protocol FileRepresentable {
  var path: String { get }
  var name: String { get }
  var type: String { get }
}

protocol FileProcessable {
  func open(_ file: FileRepresentable)
  func close(_ file: FileRepresentable)
}

struct AnotherFile: FileRepresentable {

  var path: String
  var name: String
  var type: String
}

class AnotherFileHandle: FileProcessable {

  func open(_ file: FileRepresentable) {

  }

  func close(_ file: FileRepresentable) {

  }
}


//
//  ContentView.swift
//  swiftUIAnimations
//
//  Created by Kyryl Horbushko on 12/23/20.
//

import Foundation
import SwiftUI

struct ContentView: View {
    
//    @State private var scaleAmount: CGFloat = 1
//    @State private var scaleAmountX: CGFloat = 1
//    @State private var scaleAmountY: CGFloat = 1
    
    @State private var showCircle: Bool = false
    
    var body: some View {
        VStack {
            
            // Animations
            
//            Button(action: {
//                withAnimation {
////                    scaleAmount += 1
//                    scaleAmountX += (scaleAmountX > 1 ? -0.5 : 0.5)
//                    scaleAmountY += (scaleAmountY > 1 ? -0.75 : 0.75)
//                }
//            }, label: {
//                Text("Animate")
//            })
//
//            Text("Hello")
//                .padding()
//                .background(Color.red)
////                .scaleTo(scaleAmount)
//                .scaleWithGeometryEffectBy(scaleAmountX, valueY: scaleAmountY)
//                .animation(.reverseJump(duration: 2))
//
            Button(action: {
                withAnimation {
                    showCircle.toggle()
                }
            }, label: {
                Text("Animate Circle")
            })
            
            
            // Transitions
            
            // for transition view shoud be added/removed from hierarhy
            // in other case u can't see any transitions
            if showCircle {
                Circle()
                    .fill(Color.blue)
                    // simple usage
//                    .transition(.horizontalOffset)
                    // combined
                    .transition(
                        AnyTransition
                            .rectShaped
                            .combined(with: .opacity50)
                            .combined(with: .horizontalOffset)
                    )
                    // combination
//                    .transition(
//                        AnyTransition
//                            .asymmetric(
//                                insertion: .rectShaped,
//                                removal: .opacity50
//                            )
//                    )
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// simple animatableMOdifier
struct Scale: AnimatableModifier {
    var scaleAmount: CGFloat
    
    var animatableData: CGFloat{
        get { scaleAmount }
        set { scaleAmount = newValue }
    }
    
    func body(content: Content) -> some View {
        content.scaleEffect(scaleAmount)
    }
}

extension View {
    func scaleTo(_ value: CGFloat) -> some View {
        modifier(Scale(scaleAmount: value))
    }
}

// few animated values
struct ScaleEffect: GeometryEffect {
    var scaleAmountX: CGFloat
    var scaleAmountY: CGFloat
    
    var animatableData: AnimatablePair<CGFloat, CGFloat> {
        get {
            AnimatablePair(scaleAmountX, scaleAmountY)
        }
        set {
            scaleAmountX = newValue.first;
            scaleAmountY = newValue.second
        }
    }
    
    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(
            CGAffineTransform(scaleX: scaleAmountX, y: scaleAmountY)
        )
    }
}

extension View {
        
    func scaleWithGeometryEffectBy(
        _ valueX: CGFloat,
        valueY: CGFloat
    ) -> some View {
        modifier(
            ScaleEffect(
                scaleAmountX: valueX,
                scaleAmountY: valueY
            )
        )
    }
}

// with simple view modifier
struct Opacity: ViewModifier {
    var isActive: Bool
    func body(content: Content) -> some View {
        content
            .opacity(isActive ? 1 : 0.5)
    }
}

extension AnyTransition {
    static var opacity50: AnyTransition {
        .modifier(
            active: Opacity(isActive: false),
            identity: Opacity(isActive: true)
        )
    }
}

// with shape
extension AnyTransition {
    
    private struct Rect: Shape {
        
        var fillAmount: CGFloat
        var animatableData: CGFloat {
            get { fillAmount }
            set { fillAmount = newValue}
        }
        
        func path(in rect: CGRect) -> Path {
            Path { path in
                let width = rect.width * fillAmount
                let height = rect.height * fillAmount
                let originX = (rect.width - width) / 2.0
                let originY = (rect.height - height) / 2.0
                
                path.addRect(
                    CGRect(
                        x: originX,
                        y: originY,
                        width: width,
                        height: height
                    )
                )
            }
        }
    }
    
    private struct ClipRect: ViewModifier {
        let rect: Rect
        
        func body(content: Content) -> some View {
            content.clipShape(rect)
        }
    }
    
    static var rectShaped: AnyTransition {
        .modifier(
            active: ClipRect(rect: Rect(fillAmount: 0)),
            identity: ClipRect(rect: Rect(fillAmount: 1))
        )
    }
}

// with geometry effect
extension AnyTransition {
    
    private struct HorizontalOffsetEffect: GeometryEffect {
        
        var maxOffset: CGFloat
        var animatableData: CGFloat {
            get { maxOffset }
            set { maxOffset = newValue }
        }
        
        func effectValue(size: CGSize) -> ProjectionTransform {
            ProjectionTransform(
                CGAffineTransform(translationX: maxOffset, y: 0)
            )
        }
    }
    
    static var horizontalOffset: AnyTransition {
        .modifier(
            active: HorizontalOffsetEffect(maxOffset: -350),
            identity: HorizontalOffsetEffect(maxOffset: 150)
        )
    }
}

// custom curve
extension Animation {
    
    static var reverseJump: Animation {
        Animation.timingCurve(0, 2, 1, -2)
    }
    
    static func reverseJump(duration: TimeInterval = 0.35) -> Animation {
        Animation.timingCurve(0, 2, 1, -2, duration: duration)
    }
}

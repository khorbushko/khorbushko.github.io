//
//  swiftUIAnimationsApp.swift
//  swiftUIAnimations
//
//  Created by Kyryl Horbushko on 12/23/20.
//

import SwiftUI

@main
struct swiftUIAnimationsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


@dynamicMemberLookup
class Foo {

  // input must conform ExpressibleByStringLiteral or KeyPath
  // can return any type u like
  subscript(dynamicMember lookUp: String) -> String {
    switch lookUp {
      case "a"..<"d":
        return "hello"
      default:
        return " world"
    }
  }
}

let foo = Foo()
// generate dynamic members that does not exist
print(foo.a, foo.z)

// Output:
// hello  world

struct FooBar {
  var variable1: String
  var variable2: String
}

@dynamicMemberLookup
final class Bar {

  subscript<T>(
    dynamicMember keyPath: WritableKeyPath<FooBar, T>
  ) -> T {
    get { fooBar[keyPath: keyPath] }
    set { fooBar[keyPath: keyPath] = newValue }
  }

  private(set) var fooBar: FooBar

  // MARK: - Lifecycle

  init(fooBar: FooBar) {
    self.fooBar = fooBar
  }
}

var bar = Bar(
  fooBar: FooBar(
    variable1: "hello",
    variable2: " world"
  )
)
let firstVariable: String = bar.variable1
let secondVariable: String = bar.variable2
print(firstVariable, secondVariable)

// dynamic callable

@dynamicCallable
class FooFoo {

  func dynamicallyCall(
    withKeywordArguments args: KeyValuePairs<String, Int>
  ) -> String {
    "do something with keyword args \(args)"
  }

  func dynamicallyCall(
    withArguments args: [Int]
  ) -> String {
    "do something with args \(args)"
  }

}

let foofoo = FooFoo()
print(foofoo(value: 111))
print(foofoo(111))

//
//  City.swift
//  DijkstrasAlg
//
//  Created by Kyryl Horbushko on 23.11.2023.
//

import Foundation
import SwiftUI

struct City: Hashable {
  internal init(region: City.Region, name: String, position: City.Position) {
    self.region = region
    self.name = name
    self.place = position
  }
  
  enum Region: Hashable {
    case blue
    case brown
    case yellow
    case orange
    case purple
    case green
    case pink
  }

  struct Position: Hashable {
    let x: Float
    let y: Float
  }

  let region: City.Region
  let name: String
  let place: City.Position
}

extension City: Identifiable {
  var id: String {
    name
  }
}

extension City: CustomStringConvertible {
  var description: String {
    name
  }

  var color: Color {
    switch region {
      case .blue:
        return .blue
      case .brown:
        return .brown
      case .yellow:
        return .yellow
      case .orange:
        return .orange
      case .purple:
        return .purple
      case .green:
        return .green
      case .pink:
        return .pink
    }
  }
}

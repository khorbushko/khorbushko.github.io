//
//  MoveAroundUkraine.swift
//  DijkstrasAlg
//
//  Created by Kyryl Horbushko on 23.11.2023.
//

import Foundation

import Graph

enum MoveAroundUkraine {

  case train
  case car

  static func dijkstrasSetFor(movement type: Self) -> DijkstraSet<City> {
    let ukraineCityTrainMap = DijkstraSet<City>()

    let uzhgorod = ukraineCityTrainMap.createVertex(data: .uzhgorod)
    let drohobuch = ukraineCityTrainMap.createVertex(data: .drohobuch)
    let lviv = ukraineCityTrainMap.createVertex(data: .lviv)
    let ternopil = ukraineCityTrainMap.createVertex(data: .ternopil)
    let ivanoFrankivsk = ukraineCityTrainMap.createVertex(data: .ivanoFrankivsk)
    let chernivtsi = ukraineCityTrainMap.createVertex(data: .chernivtsi)

    let lutsk = ukraineCityTrainMap.createVertex(data: .lutsk)
    let kovel = ukraineCityTrainMap.createVertex(data: .kovel)
    let rivne = ukraineCityTrainMap.createVertex(data: .rivne)
    let zhutomyr = ukraineCityTrainMap.createVertex(data: .zhutomyr)
    let korosten = ukraineCityTrainMap.createVertex(data: .korosten)
    let kyiv = ukraineCityTrainMap.createVertex(data: .kyiv)

    let chernihiv = ukraineCityTrainMap.createVertex(data: .chernihiv)
    let konotop = ukraineCityTrainMap.createVertex(data: .konotop)
    let sumy = ukraineCityTrainMap.createVertex(data: .sumy)
    let poltava = ukraineCityTrainMap.createVertex(data: .poltava)
    let kharkiv = ukraineCityTrainMap.createVertex(data: .kharkiv)
    let pryluky = ukraineCityTrainMap.createVertex(data: .pryluky)

    let khmelnytskiy = ukraineCityTrainMap.createVertex(data: .khmelnytskiy)
    let kPodilskiy = ukraineCityTrainMap.createVertex(data: .kPodilskiy)
    let vinnutsya = ukraineCityTrainMap.createVertex(data: .vinnutsya)
    let bilaTserkva = ukraineCityTrainMap.createVertex(data: .bilaTserkva)
    let uman = ukraineCityTrainMap.createVertex(data: .uman)
    let balta = ukraineCityTrainMap.createVertex(data: .balta)

    let cherkasu = ukraineCityTrainMap.createVertex(data: .cherkasu)
    let kremenchyk = ukraineCityTrainMap.createVertex(data: .kremenchyk)
    let kropyvnytskiy = ukraineCityTrainMap.createVertex(data: .kropyvnytskiy)
    let dnipro = ukraineCityTrainMap.createVertex(data: .dnipro)
    let kryvyiRih = ukraineCityTrainMap.createVertex(data: .kryvyiRih)
    let zaporizzhya = ukraineCityTrainMap.createVertex(data: .zaporizzhya)

    let voznesensk = ukraineCityTrainMap.createVertex(data: .voznesensk)
    let odesa = ukraineCityTrainMap.createVertex(data: .odesa)
    let mykolaiv = ukraineCityTrainMap.createVertex(data: .mykolaiv)
    let kherson = ukraineCityTrainMap.createVertex(data: .kherson)
    let melitopol = ukraineCityTrainMap.createVertex(data: .melitopol)
    let simpheropol = ukraineCityTrainMap.createVertex(data: .simpheropol)

    let lozova = ukraineCityTrainMap.createVertex(data: .lozova)
    let lysychansk = ukraineCityTrainMap.createVertex(data: .lysychansk)
    let slovyanks = ukraineCityTrainMap.createVertex(data: .slovyanks)
    let luhansk = ukraineCityTrainMap.createVertex(data: .luhansk)
    let donetsk = ukraineCityTrainMap.createVertex(data: .donetsk)
    let mariupol = ukraineCityTrainMap.createVertex(data: .mariupol)

    switch type {
      case .car:
        ukraineCityTrainMap.add(.undirected,  from: uzhgorod, to: drohobuch, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: drohobuch, to: lviv, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: lviv, to: lutsk, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: uzhgorod, to: ivanoFrankivsk, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: ivanoFrankivsk, to: ternopil, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: ivanoFrankivsk, to: chernivtsi, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: lviv, to: ternopil, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: ternopil, to: khmelnytskiy, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: chernivtsi, to: kPodilskiy, weight: 3)

        ukraineCityTrainMap.add(.undirected, from: lutsk, to: kovel, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: lutsk, to: rivne, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: kovel, to: korosten, weight: 5)
        ukraineCityTrainMap.add(.undirected, from: rivne, to: zhutomyr, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: zhutomyr, to: vinnutsya, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: rivne, to: khmelnytskiy, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: korosten, to: zhutomyr, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: kyiv, to: zhutomyr, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: kyiv, to: bilaTserkva, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: kyiv, to: cherkasu, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: kyiv, to: chernihiv, weight: 3)

        ukraineCityTrainMap.add(.undirected, from: khmelnytskiy, to: vinnutsya, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: khmelnytskiy, to: kPodilskiy, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: vinnutsya, to: uman, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: vinnutsya, to: balta, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: balta, to: kPodilskiy, weight: 5)
        ukraineCityTrainMap.add(.undirected, from: balta, to: voznesensk, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: balta, to: odesa, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: uman, to: bilaTserkva, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: uman, to: cherkasu, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: uman, to: voznesensk, weight: 4)

        ukraineCityTrainMap.add(.undirected, from: voznesensk, to: mykolaiv, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: mykolaiv, to: odesa, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: mykolaiv, to: kryvyiRih, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: mykolaiv, to: kherson, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: kherson, to: melitopol, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: kherson, to: simpheropol, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: melitopol, to: simpheropol, weight: 5)
        ukraineCityTrainMap.add(.undirected, from: melitopol, to: kryvyiRih, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: melitopol, to: mariupol, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: melitopol, to: zaporizzhya, weight: 3)

        ukraineCityTrainMap.add(.undirected, from: dnipro, to: kryvyiRih, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: dnipro, to: zaporizzhya, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: dnipro, to: lozova, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: dnipro, to: kremenchyk, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: kremenchyk, to: kropyvnytskiy, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: kropyvnytskiy, to: voznesensk, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: kropyvnytskiy, to: kryvyiRih, weight: 3)

        ukraineCityTrainMap.add(.undirected, from: kremenchyk, to: cherkasu, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: kremenchyk, to: poltava, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: zaporizzhya, to: donetsk, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: cherkasu, to: pryluky, weight: 3)

        ukraineCityTrainMap.add(.undirected, from: mariupol, to: donetsk, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: donetsk, to: luhansk, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: donetsk, to: slovyanks, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: slovyanks, to: lozova, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: luhansk, to: lysychansk, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: lysychansk, to: lozova, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: lozova, to: kharkiv, weight: 3)

        ukraineCityTrainMap.add(.undirected, from: kharkiv, to: poltava, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: kharkiv, to: sumy, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: sumy, to: konotop, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: konotop, to: pryluky, weight: 2)
        ukraineCityTrainMap.add(.undirected, from: konotop, to: chernihiv, weight: 3)
        ukraineCityTrainMap.add(.undirected, from: pryluky, to: poltava, weight: 4)
        ukraineCityTrainMap.add(.undirected, from: pryluky, to: poltava, weight: 4)

      case .train:
        ukraineCityTrainMap.add(.directed, from: lviv, to: voznesensk, weight: 1)
        ukraineCityTrainMap.add(.directed, from: chernivtsi, to: kovel, weight: 1)
        ukraineCityTrainMap.add(.directed, from: ivanoFrankivsk, to: bilaTserkva, weight: 1)
        ukraineCityTrainMap.add(.directed, from: drohobuch, to: cherkasu, weight: 1)
        ukraineCityTrainMap.add(.directed, from: ternopil, to: lozova, weight: 1)
        ukraineCityTrainMap.add(.directed, from: uzhgorod, to: poltava, weight: 1)

        ukraineCityTrainMap.add(.directed, from: kyiv, to: kherson, weight: 1)
        ukraineCityTrainMap.add(.directed, from: lutsk, to: balta, weight: 1)
        ukraineCityTrainMap.add(.directed, from: zhutomyr, to: slovyanks, weight: 1)
        ukraineCityTrainMap.add(.directed, from: kovel, to: kremenchyk, weight: 1)
        ukraineCityTrainMap.add(.directed, from: korosten, to: drohobuch, weight: 1)
        ukraineCityTrainMap.add(.directed, from: rivne, to: pryluky, weight: 1)

        ukraineCityTrainMap.add(.directed, from: uman, to: melitopol, weight: 1)
        ukraineCityTrainMap.add(.directed, from: kPodilskiy, to: korosten, weight: 1)
        ukraineCityTrainMap.add(.directed, from: vinnutsya, to: lysychansk, weight: 1)
        ukraineCityTrainMap.add(.directed, from: bilaTserkva, to: kryvyiRih, weight: 1)
        ukraineCityTrainMap.add(.directed, from: balta, to: uzhgorod, weight: 1)
        ukraineCityTrainMap.add(.directed, from: khmelnytskiy, to: kharkiv, weight: 1)

        ukraineCityTrainMap.add(.directed, from: slovyanks, to: mykolaiv, weight: 1)
        ukraineCityTrainMap.add(.directed, from: lozova, to: kyiv, weight: 1)
        ukraineCityTrainMap.add(.directed, from: mariupol, to: chernivtsi, weight: 1)
        ukraineCityTrainMap.add(.directed, from: lysychansk, to: kropyvnytskiy, weight: 1)
        ukraineCityTrainMap.add(.directed, from: donetsk, to: uman, weight: 1)
        ukraineCityTrainMap.add(.directed, from: luhansk, to: konotop, weight: 1)

        ukraineCityTrainMap.add(.directed, from: poltava, to: odesa, weight: 1)
        ukraineCityTrainMap.add(.directed, from: kharkiv, to: zhutomyr, weight: 1)
        ukraineCityTrainMap.add(.directed, from: pryluky, to: mariupol, weight: 1)
        ukraineCityTrainMap.add(.directed, from: chernihiv, to: dnipro, weight: 1)
        ukraineCityTrainMap.add(.directed, from: konotop, to: ternopil, weight: 1)
        ukraineCityTrainMap.add(.directed, from: sumy, to: vinnutsya, weight: 1)

        ukraineCityTrainMap.add(.directed, from: cherkasu, to: simpheropol, weight: 1)
        ukraineCityTrainMap.add(.directed, from: zaporizzhya, to: rivne, weight: 1)
        ukraineCityTrainMap.add(.directed, from: kryvyiRih, to: luhansk, weight: 1)
        ukraineCityTrainMap.add(.directed, from: kremenchyk, to: kPodilskiy, weight: 1)
        ukraineCityTrainMap.add(.directed, from: dnipro, to: lviv, weight: 1)
        ukraineCityTrainMap.add(.directed, from: kropyvnytskiy, to: sumy, weight: 1)

        ukraineCityTrainMap.add(.directed, from: simpheropol, to: khmelnytskiy, weight: 1)
        ukraineCityTrainMap.add(.directed, from: mykolaiv, to: lutsk, weight: 1)
        ukraineCityTrainMap.add(.directed, from: voznesensk, to: donetsk, weight: 1)
        ukraineCityTrainMap.add(.directed, from: odesa, to: zaporizzhya, weight: 1)
        ukraineCityTrainMap.add(.directed, from: kherson, to: ivanoFrankivsk, weight: 1)
        ukraineCityTrainMap.add(.directed, from: melitopol, to: chernihiv, weight: 1)
    }

    return ukraineCityTrainMap
  }
}

//
//  City+Ukraine.swift
//  DijkstrasAlg
//
//  Created by Kyryl Horbushko on 23.11.2023.
//

import Foundation

extension City {
  static let lviv: City = .init(region: .pink, name: "Львів", position: .init(x: 4, y: 5.5))
  static let uzhgorod: City = .init(region: .pink, name: "Ужгород", position: .init(x: 1, y: 8.5))
  static let drohobuch: City = .init(region: .pink, name: "Дрогобич", position: .init(x: 2.5, y: 6.2))
  static let ternopil: City = .init(region: .pink, name: "Тернопіль", position: .init(x: 6.1, y: 7.1))
  static let ivanoFrankivsk: City = .init(region: .pink, name: "Івано-Франківськ", position: .init(x: 4.5, y: 7.8))
  static let chernivtsi: City = .init(region: .pink, name: "Чернівці", position: .init(x: 7.5, y: 8.4))

  static let lutsk: City = .init(region: .blue, name: "Луцьк", position: .init(x: 5.2, y: 4))
  static let kovel: City = .init(region: .blue, name: "Ковель", position: .init(x: 5.7, y: 2))
  static let rivne: City = .init(region: .blue, name: "Рівне", position: .init(x: 7.5, y: 4.5))
  static let zhutomyr: City = .init(region: .blue, name: "Житомир", position: .init(x: 12.2, y: 5.2))
  static let korosten: City = .init(region: .blue, name: "Коростень", position: .init(x: 12.1, y: 2.8))
  static let kyiv: City = .init(region: .blue, name: "Київ", position: .init(x: 15.5, y: 4.9))

  static let chernihiv: City = .init(region: .purple, name: "Чернігів", position: .init(x: 17, y: 2))
  static let poltava: City = .init(region: .purple, name: "Полтава", position: .init(x: 21.9, y: 6.3))
  static let konotop: City = .init(region: .purple, name: "Конотоп", position: .init(x: 19.8, y: 3.5))
  static let sumy: City = .init(region: .purple, name: "Суми", position: .init(x: 22, y: 4))
  static let kharkiv: City = .init(region: .purple, name: "Харків", position: .init(x: 24.2, y: 5.5))
  static let pryluky: City = .init(region: .purple, name: "Прилуки", position: .init(x: 18.5, y: 4.5))

  static let khmelnytskiy: City = .init(region: .green, name: "Хмельницький", position: .init(x: 9.6, y: 6.4))
  static let kPodilskiy: City = .init(region: .green, name: "Кам`янець-Подільський", position: .init(x: 9.2, y: 7.8))
  static let vinnutsya: City = .init(region: .green, name: "Вінниця", position: .init(x: 12.0, y: 7))
  static let bilaTserkva: City = .init(region: .green, name: "Біла Церква", position: .init(x: 14.8, y: 6.2))
  static let uman: City = .init(region: .green, name: "Умань", position: .init(x: 14.5, y: 7.8))
  static let balta: City = .init(region: .green, name: "Балта", position: .init(x: 13.6, y: 9.5))

  static let cherkasu: City = .init(region: .orange, name: "Черкаси", position: .init(x: 17.5, y: 6.8))
  static let kremenchyk: City = .init(region: .orange, name: "Кременчук", position: .init(x: 20.1, y: 7.2))
  static let kropyvnytskiy: City = .init(region: .orange, name: "Кропивницький", position: .init(x: 18.2, y: 8.2))
  static let dnipro: City = .init(region: .orange, name: "Дніпро", position: .init(x: 22.2, y: 8.2))
  static let kryvyiRih: City = .init(region: .orange, name: "Кривий Ріг", position: .init(x: 20.0, y: 9.8))
  static let zaporizzhya: City = .init(region: .orange, name: "Запоріжжя", position: .init(x: 23.2, y: 9.8))

  static let voznesensk: City = .init(region: .yellow, name: "Вознесенськ", position: .init(x: 16.5, y: 9.8))
  static let odesa: City = .init(region: .yellow, name: "Одеса", position: .init(x: 14.0, y: 13.2))
  static let mykolaiv: City = .init(region: .yellow, name: "Миколаїв", position: .init(x: 17.5, y: 11.0))
  static let kherson: City = .init(region: .yellow, name: "Херсон", position: .init(x: 19.3, y: 11.9))
  static let melitopol: City = .init(region: .yellow, name: "Мелітополь", position: .init(x: 23.5, y: 11.8))
  static let simpheropol: City = .init(region: .yellow, name: "Сімферополь", position: .init(x: 20.5, y: 15.5))

  static let lozova: City = .init(region: .brown, name: "Лозова", position: .init(x: 25.0, y: 7.2))
  static let lysychansk: City = .init(region: .brown, name: "Лисичанськ", position: .init(x: 28.8, y: 7.1))
  static let slovyanks: City = .init(region: .brown, name: "Слов`янськ", position: .init(x: 27.0, y: 8.0))
  static let luhansk: City = .init(region: .brown, name: "Луганськ", position: .init(x: 30.2, y: 8.1))
  static let donetsk: City = .init(region: .brown, name: "Донецьк", position: .init(x: 27.5, y: 9.0))
  static let mariupol: City = .init(region: .brown, name: "Маріуполь", position: .init(x: 27.0, y: 11.2))
}

//
//  MoveAroundUkraine+Select.swift
//  DijkstrasAlg
//
//  Created by Kyryl Horbushko on 23.11.2023.
//

import Foundation
import Algorithms

import Graph

extension MoveAroundUkraine {

  enum Rules {
    static let availableTrainTickets = 4
  }
}

extension MoveAroundUkraine {
  static func calculateFastestTripBetween(
    _ cities: [City],
    stream: AsyncStream<[Graph.Edge<City>]>.Continuation
  ) async -> [Graph.Edge<City>] {

    // STEP1: Determine all train Connections
    // thus trains not bidirectional we need mix them all and review each option
    let citiesGroupsForTrain = cities.permutations(ofCount: 2)
    let trainSet = MoveAroundUkraine.dijkstrasSetFor(movement: .train)

    var possibleSets: [[Graph.Edge<City>]] = []
    for group in citiesGroupsForTrain {
      if let vertexFrom = trainSet.adjacencyDict.keys.first(where: { $0.data == group[0]} ),
         let vertexTo = trainSet.adjacencyDict.keys.first(where: { $0.data == group[1]} ),
         let path = trainSet.dijkstra(from: vertexFrom, to: vertexTo) {
        possibleSets.append(path)
      }
    }

    // STEP2: select best matches based on steps, but no more than 4 steps in total
    // because according to game rules - each user have only 4 tickets
    var selectedTrainsSets: [[Graph.Edge<City>]] = []
    var currentStepsInTrainMove: Int = 1
    while selectedTrainsSets.flatMap({ $0 }).count < MoveAroundUkraine.Rules.availableTrainTickets {
      let dataToAppend = possibleSets.filter({ $0.count == currentStepsInTrainMove })
      selectedTrainsSets.append(contentsOf: dataToAppend)
      currentStepsInTrainMove += 1
    }

    // STEP3: build mixed set with selected trains and cars movements
    // to allow next fastest path search
    let carSet = MoveAroundUkraine.dijkstrasSetFor(movement: .car)
    for trains in selectedTrainsSets {
      trains.forEach {
        carSet.add(.directed, edge: $0)
      }
    }

    // STEP4: build possible cities sets -> 5,040 options...
    // we have 7 cities, and in theory we can mix all cities order for visiting
    // thus this provide different result in total trip length - need to change them all
    let possibleMovements = Array(cities.permutations(ofCount: cities.count)).lazy

    // preheat vertex for each city, to reduce q-ty of search in all vertextes
    let vertexes = cities.compactMap { city in
      trainSet.adjacencyDict.keys.first(where: { $0.data == city } )
    }

//    var bestPathLength: Int = 0
//    var bestPath: [Graph.Edge<City>] = []
//    let progressInitial = Progress(totalUnitCount: Int64(possibleMovements.count))
//    let clock = ContinuousClock()
//    let interval = clock.measure {
//      for combIndx in 0..<possibleMovements.count {
//        let orderedMovementSet = possibleMovements[combIndx]
//
//        var currentPath: [Graph.Edge<City>] = []
//      loop: for idx in 0...orderedMovementSet.count-2 {
//        let first = orderedMovementSet[idx]
//        let second = orderedMovementSet[idx+1]
//        if let vertexFrom = vertexes.first(where: { $0.data == first }),
//           let vertexTo = vertexes.first(where: { $0.data == second }),
////                 if let vertexFrom = trainSet.adjacencyDict.keys.first(where: { $0.data == first } ), //1
////                    let vertexTo = trainSet.adjacencyDict.keys.first(where: { $0.data == second } ), // 1
//            let path = carSet.dijkstra(from: vertexFrom, to: vertexTo) {
//
//          currentPath.append(contentsOf: path)
//          
//          if bestPathLength != 0 {
//            let currentPathLenght = currentPath.reduce(0, { $0 + ($1.weight ?? 0) })
//            if Int(currentPathLenght) > bestPathLength {
//              break loop
//            }
//          }
//
//        }
//      }
//
//        let length = currentPath.reduce(0, { $0 + ($1.weight ?? 0) })
//
//        if bestPathLength > Int(length) || bestPathLength == 0 {
//          bestPathLength = Int(length)
//          bestPath = currentPath
//        }
//
//        progressInitial.completedUnitCount += 1
//        print(progressInitial.fractionCompleted)
//      }
//    }
//
//    print(interval)
//    print("Best required \(bestPathLength) steps")
//    for edge in bestPath {
//      print("\(edge.source) -> \(edge.destination)")
//    }

//     Option 2 Improved

    let valueSet = carSet
    let processors = ProcessInfo.processInfo.activeProcessorCount
    let progress = Progress(totalUnitCount: Int64(possibleMovements.count))

    let task = Task {
      let concurrentResults: [Graph.Edge<City>] = await withTaskGroup(
        of: ([Graph.Edge<City>], Int).self
      ) {
        group in
        for i in 0..<Int(processors) {
          group.addTask {
            let lowerBound = Float(i)/Float(processors) * Float(possibleMovements.count)
            let upperBound = Float(i+1)/Float(processors) * Float(possibleMovements.count)
            let data = Array(possibleMovements[Int(lowerBound)..<Int(upperBound)])

            var bestPathLength: Int = .max
            var bestPath: [Graph.Edge<City>] = []

            for combIndx in 0..<data.count {
              let orderedMovementSet = data[combIndx]
              var currentPath: [Graph.Edge<City>] = []
            loop: for idx in 0...orderedMovementSet.count-2 {
              let first = orderedMovementSet[idx]
              let second = orderedMovementSet[idx+1]
              if let vertexFrom = vertexes.first(where: { $0.data == first }),
                 let vertexTo = vertexes.first(where: { $0.data == second }),
                 let path = valueSet.dijkstra(from: vertexFrom, to: vertexTo) {

                currentPath.append(contentsOf: path)
                let currentPathLenght = currentPath.reduce(0, { $0 + ($1.weight ?? 0) })
                if Int(currentPathLenght) > bestPathLength {
                  break loop
                }
              }
            }

              let length = currentPath.reduce(0, { $0 + ($1.weight ?? 0) })

              if bestPathLength > Int(length) {
                bestPathLength = Int(length)
                bestPath = currentPath
              }

              stream.yield(currentPath)

              progress.completedUnitCount += 1
              print(progress.fractionCompleted )
            }

            return (bestPath, bestPathLength)
          }
        }

        var bestPathLength: Int = 0
        var bestPath: [Graph.Edge<City>] = []

        let clock = ContinuousClock()
        let interval = await clock.measure {
          for await value in group {
            let length = value.1
            if bestPathLength > Int(length) || bestPathLength == 0 {
              bestPathLength = Int(length)
              bestPath = value.0
            }
          }
        }
        print(interval)

        stream.yield(bestPath)

        return bestPath
      }

      return concurrentResults
    }

//    Task {
//      let result = await task.value

//      print("Best required \(result.reduce(0, { $0 + ($1.weight ?? 0) })) steps")
//      for edge in result {
//        print("\(edge.source) -> \(edge.destination)")
//      }
//    }

    // option 1
    //    return bestPath

    // option 2
    return await task.value

  }
}

//
//  Vertex.swift
//
//
//  Created by Kyryl Horbushko on 23.11.2023.
//

import Foundation

public struct Vertex<T: Hashable> {
  public var data: T
}

extension Vertex: Hashable {
  public func hash(into hasher: inout Hasher) {
    hasher.combine("\(data)")
  }

  static public func ==(lhs: Vertex, rhs: Vertex) -> Bool {
    lhs.data == rhs.data
  }
}

extension Vertex: CustomStringConvertible {
  public var description: String {
    "\(data)"
  }
}

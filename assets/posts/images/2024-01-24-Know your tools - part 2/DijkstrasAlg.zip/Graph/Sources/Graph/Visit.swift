//
//  Visit.swift
//
//
//  Created by Kyryl Horbushko on 23.11.2023.
//

import Foundation

public enum Visit<Element: Hashable> {
  case source
  case edge(Edge<Element>)
}

extension Graphable {
  public func route(to destination: Vertex<Element>, in tree: [Vertex<Element>: Visit<Element>]) -> [Edge<Element>] {
    var vertex = destination
    var path: [Edge<Element>] = []

    while let visit = tree[vertex],
          case .edge(let edge) = visit {

      path = [edge] + path
      vertex = edge.source
    }

    return path
  }

  public func distance(to destination: Vertex<Element>, in tree: [Vertex<Element>: Visit<Element>]) -> Double {
    let path = route(to: destination, in: tree)
    let distance = path.compactMap({ $0.weight })
    return distance.reduce(0, { $0 + $1 })
  }
}

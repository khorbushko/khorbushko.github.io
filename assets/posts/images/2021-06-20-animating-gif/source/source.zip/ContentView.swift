//
//  ContentView.swift
//  testGifPlayer
//
//  Created by Kyryl Horbushko on 15.06.2021.
//

import SwiftUI

struct ContentView: View {
  
  @State var flag: Bool = false
    var body: some View {
      VStack {
        Text("Demo gif player")
        
        Gif(name: "giphy", bundle: .main, duration: .default)
          .frame(width: 250, height: 200)
        
        try? GifPlayerView(name: "giphy", bundle: .main, speed: 1)
          .frame(width: 250, height: 200)
      }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




// test 1

import UIKit
import ImageIO

public enum GifPlayer {
  public enum GifFailure: Error {
    case noSourceFile
    case noSourceData
    case invalidSetOfImages
  }
  
  private enum Constants {
    enum Extension {
      static let gif = "gif"
    }
  }
  
  // MARK: - Public
  
  public static func gif(named: String, bundle: Bundle = .main) throws -> UIImage {
    if let resourceURL = bundle.url(forResource: named, withExtension: Constants.Extension.gif) {
      let data = try Data(contentsOf: resourceURL)
      if let source = CGImageSourceCreateWithData(data as CFData, nil) {
        if let gif = GifPlayer.animatedImageWithSource(source) {
          return gif
        } else {
          throw GifFailure.invalidSetOfImages
        }
      } else {
        throw GifFailure.noSourceData
      }
    } else {
      throw GifFailure.noSourceFile
    }
  }
  
  static func delayForImageAtIndex(_ index: Int, source: CGImageSource) -> Double {
    var delay = 0.1
    
    let cfProperties = CGImageSourceCopyPropertiesAtIndex(source, index, nil)
    let gifProperties: CFDictionary = unsafeBitCast(
      CFDictionaryGetValue(
        cfProperties,
        Unmanaged.passUnretained(kCGImagePropertyGIFDictionary).toOpaque()
      ),
      to: CFDictionary.self
    )
    
    var delayObject: AnyObject = unsafeBitCast(
      CFDictionaryGetValue(
        gifProperties,
        Unmanaged.passUnretained(kCGImagePropertyGIFUnclampedDelayTime).toOpaque()
      ),
      to: AnyObject.self
    )
    
    if delayObject.doubleValue == 0 {
      delayObject = unsafeBitCast(
        CFDictionaryGetValue(
          gifProperties,
          Unmanaged.passUnretained(kCGImagePropertyGIFDelayTime).toOpaque()
        ),
        to: AnyObject.self
      )
    }
    
    delay = min(delayObject as? Double ?? 0, 0.1)
    return delay
  }
  
  static func animatedImageWithSource(_ source: CGImageSource) -> UIImage? {
    let count = CGImageSourceGetCount(source)
    
    let images = (0..<count)
      .compactMap({ CGImageSourceCreateImageAtIndex(source, $0, nil) })
    let delaysInMiliseconds = (0..<count)
      .map({ GifPlayer.delayForImageAtIndex($0, source: source) })
      .map { Int($0 * 1000.0) }
    
    let durationInSeconds = Double(delaysInMiliseconds.reduce(0, +)) / 1000.0
    
    let delay = delaysInMiliseconds.compactMap({ $0 }).max() ?? 1
    let frames: [[UIImage]] = (0...images.count-1).map({
      let image = UIImage(cgImage: images[$0])
      let framesPerImage = Int(delaysInMiliseconds[$0] / delay)
      
      return [UIImage].init(repeating: image, count: framesPerImage)
    })
    let animatedImages = frames.flatMap({ $0 })
    
    let animation = UIImage.animatedImage(
      with: animatedImages,
      duration: durationInSeconds
    )
    
    return animation
  }
}


struct GifView: UIViewRepresentable {
  let name: String
  
  func makeUIView(context: Context) -> UIView {
    UIView()
  }
  
  func updateUIView(_ uiView: UIView, context: Context) {
    let image = try? GifPlayer.gif(named: name)
    let imageView: UIImageView = UIImageView(image: image)
    uiView.addSubview(imageView)
  }
}


// test 2

public struct Gif: View {
  
  public enum Duration {
    case `default`
    case custom(Double)
  }
  
  private let duration: Duration
  private let images: [Image]
  private let originalDuration: TimeInterval
  
  internal init(
    name: String,
    bundle: Bundle,
    duration: Gif.Duration
  ) {
    self.duration = duration
    
    let gifDataProvider = GifDataProvider(name: name, bundle: bundle)
    if let gifData = try? gifDataProvider.read() {
      self.originalDuration = gifData.duration
      self.images = gifData.images
    } else {
      self.originalDuration = 0
      self.images = []
    }
  }

  @State private var flag: Bool = false
  
  private var animation: Animation {
    switch duration {
      case .custom(let duration):
        return Animation.linear(duration: duration)
          .repeatForever(autoreverses: false)
      case .default:
        return Animation.linear(duration: originalDuration)
          .repeatForever(autoreverses: false)
    }
  }
  
  public var body: some View {
    Rectangle()
      .modifier(
        GifAnimatableModifier(
          images: images,
          duration: originalDuration,
          progress: flag ? 1 : 0
        )
      )
      .onAppear(perform: {
        withAnimation(animation) {
          flag.toggle()
        }
      })
  }
}

struct GifAnimatableModifier: AnimatableModifier {
  
  private let images: [Image]
  private let duration: TimeInterval
  
  var progress: Double
  
  var animatableData: Double {
    get { progress }
    set { progress = newValue }
  }
  
  init(
    images: [Image],
    duration: TimeInterval,
    progress: Double
  ) {
    self.progress = progress
    self.images = images
    self.duration = duration
  }
  
  func body(content: Content) -> some View {
    content
      .overlay(
        imageForProgress(progress)
          .resizable()
      )
  }
  
  private func imageForProgress(_ progress: Double) -> Image {
    let durationPerImage = duration / Double(images.count)
    let currentTime = progress * duration
    let currentImage = Int(currentTime / durationPerImage)
    let idx = max(min(images.count-1, currentImage), 0)
    let image = images[idx]
    return image
  }
}

struct GifDataProvider {
  struct GifData {
    let images: [Image]
    let duration: Double
  }
  
  enum GifFailure: Error {
    case noSourceFile
    case noSourceData
    case invalidSetOfImages
  }
  
  private enum Extension {
    static let gif = "gif"
  }
  
  private let name: String
  private let bundle: Bundle

  init(name: String, bundle: Bundle) {
    self.bundle = bundle
    self.name = name
  }
  
  func read() throws -> GifData {
    if let resourceURL = bundle.url(forResource: name, withExtension: Extension.gif) {
      if let data = try? Data(contentsOf: resourceURL) {
        if let source = CGImageSourceCreateWithData(data as CFData, nil) {
          
          let count = CGImageSourceGetCount(source)
          
          let images = (0..<count)
            .compactMap({ CGImageSourceCreateImageAtIndex(source, $0, nil) })
          let delaysInMiliseconds = (0..<count)
            .map({ delayForImageAtIndex($0, source: source) })
            .map { Int($0 * 1000.0) }
          
          let durationInSeconds = Double(delaysInMiliseconds.reduce(0, +)) / 1000.0
          
          let gcd = delaysInMiliseconds.compactMap({ $0 }).max() ?? 1
          let frames: [[UIImage]] = (0...images.count-1).map({
            let image = UIImage(cgImage: images[$0])
            let framesPerImage = Int(delaysInMiliseconds[$0] / gcd)
            
            return [UIImage].init(repeating: image, count: framesPerImage)
          })
          let animatedImages = frames.flatMap({ $0 })
          
          let suImages = animatedImages.map({ Image(uiImage: $0) })
          let duration = durationInSeconds
          return GifData(images: suImages, duration: duration)
        } else {
          throw GifFailure.invalidSetOfImages
        }
      } else {
        throw GifFailure.noSourceData
      }
    } else {
      throw GifFailure.noSourceFile
    }
  }
  
  // MARK: - Private
  
  private func delayForImageAtIndex(_ index: Int, source: CGImageSource) -> Double {
    var delay = 0.1
    
    let cfProperties = CGImageSourceCopyPropertiesAtIndex(source, index, nil)
    let gifProperties: CFDictionary = unsafeBitCast(
      CFDictionaryGetValue(
        cfProperties,
        Unmanaged.passUnretained(kCGImagePropertyGIFDictionary).toOpaque()
      ),
      to: CFDictionary.self
    )
    
    var delayObject: AnyObject = unsafeBitCast(
      CFDictionaryGetValue(
        gifProperties,
        Unmanaged.passUnretained(kCGImagePropertyGIFUnclampedDelayTime).toOpaque()
      ),
      to: AnyObject.self
    )
    
    if delayObject.doubleValue == 0 {
      delayObject = unsafeBitCast(
        CFDictionaryGetValue(
          gifProperties,
          Unmanaged.passUnretained(kCGImagePropertyGIFDelayTime).toOpaque()
        ),
        to: AnyObject.self
      )
    }
    
    delay = max(delayObject as? Double ?? 0, 0.1)
    return delay
  }
}

// test 3

import ImageIO.CGImageAnimation

final class GifImageAnimator {
  enum GifFailure: Error {
    case noSourceFile
  }
  
  enum Extension {
    static let gif = "gif"
  }
  
  private let name: String
  private let bundle: Bundle
  private let data: CFData
  private var stop: Bool = false
  private let speed: Double
  
  init(
    name: String,
    bundle: Bundle,
    speed: Double = 1
  ) throws {
    self.bundle = bundle
    self.name = name
    self.speed = speed
    
    if let resourceURL = bundle.url(forResource: name, withExtension: Extension.gif) {
      let data = try Data(contentsOf: resourceURL)
      self.data = data as CFData
    } else {
      throw GifFailure.noSourceFile
    }
  }
  
  func stopPlaying() {
    self.stop = true
  }
  
  func animateWithFrameHandle(_ handle: @escaping (Int, CGImage) -> ()) -> OSStatus {
    let status: OSStatus = CGAnimateImageDataWithBlock(data, nil, { idx, image, value in
      value.pointee = self.stop
      handle(idx, image)
    })
    return status
  }
  
  private func dictinary() -> CFDictionary {
    var delay = 0.1
    if let source = CGImageSourceCreateWithData(data as CFData, nil) {
      let cfProperties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil)
      let gifProperties: CFDictionary = unsafeBitCast(
        CFDictionaryGetValue(
          cfProperties,
          Unmanaged.passUnretained(kCGImagePropertyGIFDictionary).toOpaque()
        ),
        to: CFDictionary.self
      )
      
      var delayObject: AnyObject = unsafeBitCast(
        CFDictionaryGetValue(
          gifProperties,
          Unmanaged.passUnretained(kCGImagePropertyGIFUnclampedDelayTime).toOpaque()
        ),
        to: AnyObject.self
      )
      
      if delayObject.doubleValue == 0 {
        delayObject = unsafeBitCast(
          CFDictionaryGetValue(
            gifProperties,
            Unmanaged.passUnretained(kCGImagePropertyGIFDelayTime).toOpaque()
          ),
          to: AnyObject.self
        )
      }
      
      delay = max(delayObject as? Double ?? 0, 0.1)
    }
    
    return [
      kCGImageAnimationStartIndex: 0,
      kCGImageAnimationDelayTime: delay * speed,
      kCGImageAnimationLoopCount: kCFNumberPositiveInfinity as Any
    ] as CFDictionary
  }
}

import Combine
import UIKit

final class GifAnimator: ObservableObject {
  private let animator: GifImageAnimator
  @Published var image: Image?
  @Published var isFailure: Bool = false

  init(
    name: String,
    bundle: Bundle,
    speed: Double = 1
  ) throws {
    animator = try .init(name: name, bundle: bundle, speed: speed)
  }
  
  func startAnimating() {
    let status = animator.animateWithFrameHandle { _, frame in
      self.image = Image(uiImage: .init(cgImage: frame))
    }
    
    if status != 0 {
      isFailure = true
    }
  }
  
  func stopAnimating() {
    animator.stopPlaying()
  }
}

import SwiftUI

public struct GifPlayerView: View {
  @ObservedObject private var imageAnimator: GifAnimator

  public init(name: String, bundle: Bundle, speed: Double = 1) throws {
    imageAnimator = try .init(name: name, bundle: bundle, speed: speed)
  }
    
  public var body: some View {
    VStack {
      imageAnimator.image?
        .resizable()
    }
    .onAppear {
      imageAnimator.startAnimating()
    }.onDisappear {
      imageAnimator.stopAnimating()
    }
  }
}

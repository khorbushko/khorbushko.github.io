import Foundation
import Combine

// SHARE

// sample 1
var tokens: Set<AnyCancellable> = []

//let dataPublisher =
//  [1, 2, 3, 4]
//  .publisher
//  .delay(for: 1, scheduler: DispatchQueue.main)
//  .map { _ -> String in
//    let charCode = Int.random(in: 9_000...10_000)
//    return String(Character(UnicodeScalar(charCode)!))
//  }
//  .share()  // --> comment this line to see the diff
//
//dataPublisher
//  .sink { (value) in
//    print("Pub1 : \(value)")
//  }
//  .store(in: &tokens)
//
//dataPublisher
//  .sink { (value) in
//    print("Pub2 : \(value)")
//  }
//  .store(in: &tokens)

// sample 2

//let publisher = Timer.publish(every: 1, on: .main, in: .default)
//  .autoconnect()
//  .scan(0, { (x, y) -> Int in x + 1 })
//  .share() // --> comment this line to see the diff
//
//publisher
//  .sink {
//    print("1 - ", $0)
//  }
//  .store(in: &tokens)
//
//DispatchQueue.global().asyncAfter(deadline: .now() + 4) {
//  publisher
//    .sink {
//      print("2 - ", $0)
//    }
//    .store(in: &tokens)
//}

//let pass = PassthroughSubject<String, Never>()
//
//let dataPublisher =
//  [1, 2, 3, 4]
//  .publisher
//  .map { _ -> String in
//    let charCode = Int.random(in: 9_000...10_000)
//    return String(Character(UnicodeScalar(charCode)!))
//  }
//  .multicast(subject: pass)
//
//dataPublisher
//  .sink { (value) in
//    print("Pub1 : \(value)")
//  }
//  .store(in: &tokens)
//
//dataPublisher
//  .sink { (value) in
//    print("Pub2 : \(value)")
//  }
//  .store(in: &tokens)
//
//dataPublisher.connect()

// share replay

import Foundation
import Combine

public enum ShareReplayScope {
  case forever
  case whileConnected
}

extension Publishers {
  public final class ShareReplayScopePublisher<Upstream: Publisher>: Publisher {
    public typealias Output = Upstream.Output
    public typealias Failure = Upstream.Failure

    private let lock = NSRecursiveLock()
    private let upstream: Upstream
    private let capacity: Int
    private let scope: ShareReplayScope
    private var replay = [Output]()
    private var subscriptions = [ShareReplaySubscription<Output, Failure>]()
    private var completion: Subscribers.Completion<Failure>? = nil

    init(upstream: Upstream, capacity: Int, scope: ShareReplayScope) {
      self.upstream = upstream
      self.capacity = capacity
      self.scope = scope
    }

    private func relay(_ value: Output) {
      lock.lock(); defer { lock.unlock() }
      switch scope {
        case .forever where completion != nil:
          return
        default:
          replay.append(value)
          if replay.count > capacity {
            replay.removeFirst()
          }
      }

      subscriptions.forEach { $0.receive(value) }
    }

    private func complete(_ completion: Subscribers.Completion<Failure>) {
      lock.lock(); defer { lock.unlock() }

      subscriptions.forEach { $0.receive(completion: completion) }

      switch scope {
        case .whileConnected:
          replay.removeAll()
          subscriptions.removeAll()
        case .forever:
          self.completion = completion
      }
    }

    public func receive<S: Subscriber>(
      subscriber: S
    ) where Failure == S.Failure, Output == S.Input {
      lock.lock(); defer { lock.unlock() }

      let subscription = ShareReplaySubscription(
        subscriber: subscriber,
        replay: replay,
        capacity: capacity,
        completion: completion
      )

      subscriptions.append(subscription)
      subscriber.receive(subscription: subscription)

      guard subscriptions.count == 1 else { return }
      let sink = AnySubscriber(receiveSubscription: { subscription in
        subscription.request(.unlimited)
      }, receiveValue: {
        [weak self] (value: Output) -> Subscribers.Demand in
        self?.relay(value)
        return .none
      }, receiveCompletion: { [weak self] in
        self?.complete($0)
      })

      upstream.subscribe(sink)
    }
  }
}

fileprivate final class ShareReplaySubscription<Output, Failure>: Subscription
where Failure: Error
{
  let capacity: Int
  var subscriber: AnySubscriber<Output, Failure>? = nil
  var demand: Subscribers.Demand = .none
  var buffer: [Output]
  var completion: Subscribers.Completion<Failure>? = nil

  init<S: Subscriber>(subscriber: S,
                      replay: [Output],
                      capacity: Int,
                      completion: Subscribers.Completion<Failure>?
  ) where Failure == S.Failure, Output == S.Input {
    self.subscriber = AnySubscriber(subscriber)
    self.buffer = replay
    self.capacity = capacity
    self.completion = completion
  }

  private func complete(with completion: Subscribers.Completion<Failure>) {
    guard let subscriber = subscriber else { return }
    self.subscriber = nil
    self.completion = nil
    self.buffer.removeAll()
    subscriber.receive(completion: completion)
  }

  private func emitAsNeeded() {
    guard let subscriber = subscriber else { return }
    while self.demand > .none && !buffer.isEmpty {
      self.demand -= .max(1)
      let nextDemand = subscriber.receive(buffer.removeFirst())
      if nextDemand != .none {
        self.demand += nextDemand
      }
    }
    if let completion = completion {
      complete(with: completion)
    }
  }

  func request(_ demand: Subscribers.Demand) {
    if demand != .none {
      self.demand += demand
    }
    emitAsNeeded()
  }

  func cancel() {
    complete(with: .finished)
  }

  func receive(_ input: Output) {
    guard subscriber != nil else { return }
    buffer.append(input)
    if buffer.count > capacity {
      buffer.removeFirst()
    }
    emitAsNeeded()
  }

  func receive(completion: Subscribers.Completion<Failure>) {
    guard let subscriber = subscriber else { return }
    self.subscriber = nil
    self.buffer.removeAll()
    subscriber.receive(completion: completion)
  }
}

extension Publisher {
  public func shareReplay(
    _ capacity: Int = .max,
    scope: ShareReplayScope = .forever
  ) -> Publishers.ShareReplayScopePublisher<Self> {
    return Publishers.ShareReplayScopePublisher(
      upstream: self,
      capacity: capacity,
      scope: scope
    )
  }
}


let dataPublisher =
  [1, 2, 3, 4]
  .publisher
  .delay(for: 1, scheduler: DispatchQueue.main)
  .map { _ -> String in
    let charCode = Int.random(in: 9_000...10_000)
    return String(Character(UnicodeScalar(charCode)!))
  }
  .shareReplay()

dataPublisher
  .sink { (value) in
    print("Pub1 : \(value)")
  }
  .store(in: &tokens)

dataPublisher
  .delay(for: 1, scheduler: DispatchQueue.main)
  .sink { (value) in
    print("Pub2 : \(value)")
  }
  .store(in: &tokens)

import UIKit
import XCTest

// FAKE

//final class SystemInfo {
//    var foo: Int?
//    var bar: Int?
//}
//
//protocol SystemInformationProvider {
//    func fetchSystemInfo() -> SystemInfo
//}
//
//final class SystemInfoViewModel {
//
//    let infoProvider: SystemInformationProvider
//
//    // MARK: - Lifecycle
//
//    init(infoProvider: SystemInformationProvider) {
//        self.infoProvider = infoProvider
//    }
//
//    func fetchSystemInfo() -> SystemInfo {
//        // simplified for sample logic
//        infoProvider.fetchSystemInfo()
//    }
//}
//
//final class SystemInfoViewModelTest: XCTestCase {
//
//    // This is a fake object
//    private final class FakeSystemInfoProvider: SystemInformationProvider {
//        func fetchSystemInfo() -> SystemInfo {
//            let info = SystemInfo()
//            info.bar = 1
//            info.foo = 2
//            return info
//        }
//    }
//
//    private var sut: SystemInfoViewModel!
//    private var provider: FakeSystemInfoProvider!
//
//    // MARK: - Lifecycle
//
//    override func setUp() {
//        super.setUp()
//
//        configureSUT()
//    }
//
//    override func tearDown() {
//        super.tearDown()
//
//        sut = nil
//        provider = nil
//
//        XCTAssertNil(sut)
//        XCTAssertNil(provider)
//    }
//
//    // MARK: - Tests
//
//    func testGivenViewModelWhenCreatedShouldProvideSystemInfoWithCorrectBarValue() {
//        let system = sut.fetchSystemInfo()
//        XCTAssertEqual(system.bar, 1, "bar value should be ...")
//    }
//
//    // MARK: - Private
//
//    private func configureSUT() {
//        provider = FakeSystemInfoProvider()
//        sut = SystemInfoViewModel(infoProvider: provider)
//
//        XCTAssertNotNil(provider)
//        XCTAssertNotNil(sut)
//    }
//}

// Stub

//final class SystemInfo {
//    var foo: Int?
//    var bar: Int?
//}
//
//protocol SystemInformationProvider {
//    func fetchSystemInfo() -> SystemInfo
//}
//
//final class SystemInfoViewModel {
//
//    let infoProvider: SystemInformationProvider
//
//    // MARK: - Lifecycle
//
//    init(infoProvider: SystemInformationProvider) {
//        self.infoProvider = infoProvider
//    }
//
//    func fetchSystemInfo() -> SystemInfo {
//        // simplified for sample logic
//        infoProvider.fetchSystemInfo()
//    }
//}
//
//final class SystemInfoViewModelTest: XCTestCase {
//
//    // This is a stub object
//    private final class StubSystemInfoProvider: SystemInformationProvider {
//        // state that define return value
//        var returnSystemInfoOptionA: Bool = true
//        func fetchSystemInfo() -> SystemInfo {
//            if returnSystemInfoOptionA {
//                let info = SystemInfo()
//                info.foo = 1
//                return info
//            } else {
//                return SystemInfo()
//            }
//        }
//    }
//
//    private var sut: SystemInfoViewModel!
//    private var provider: StubSystemInfoProvider!
//
//    // MARK: - Lifecycle
//
//    override func setUp() {
//        super.setUp()
//
//        configureSUT()
//    }
//
//    override func tearDown() {
//        super.tearDown()
//
//        sut = nil
//        provider = nil
//
//        XCTAssertNil(sut)
//        XCTAssertNil(provider)
//    }
//
//    // MARK: - Tests
//
//    func testGivenViewModelWhenCreatedShouldCallSystemInfoProviderWhenFetchSystemInfoData() {
//        // change existing stub state to retrive data we need
//        provider.returnSystemInfoOptionA = true
//
//        let info = sut.fetchSystemInfo()
//        XCTAssertEqual(info.foo, 1)
//    }
//
//    // MARK: - Private
//
//    private func configureSUT() {
//        provider = StubSystemInfoProvider()
//        sut = SystemInfoViewModel(infoProvider: provider)
//
//        XCTAssertNotNil(provider)
//        XCTAssertNotNil(sut)
//    }
//}

// Mock

//protocol SystemInformationProvider {
//    var systemVersion: Int { get }
//
//    func changeSystemVersionTo(_ version: Int)
//}
//
//final class SystemInfoViewModel {
//
//    let infoProvider: SystemInformationProvider
//
//    // MARK: - Lifecycle
//
//    init(infoProvider: SystemInformationProvider) {
//        self.infoProvider = infoProvider
//    }
//
//    func changeVersion(_ version: Int) {
//        infoProvider.changeSystemVersionTo(version)
//    }
//}
//
//final class SystemInfoViewModelTest: XCTestCase {
//
//    // This is a mock object
//    private final class MockSystemInfoProvider: SystemInformationProvider {
//        private(set) var systemVersion: Int = 0 // value
          // state changed during testsing
//        private(set) var changeSystemCallCount: Int = 0
//
//        func changeSystemVersionTo(_ version: Int) {
//            // simplified logic for demo
//            systemVersion = version
//            changeSystemCallCount += 1
//        }
//
//        func verifyVersionChange(_ expectedVersion: Int, callCount: Int) {
//            XCTAssertEqual(expectedVersion, systemVersion)
//            XCTAssertEqual(callCount, changeSystemCallCount)
//        }
//    }
//
//    private var sut: SystemInfoViewModel!
//    private var provider: MockSystemInfoProvider!
//
//    // MARK: - Lifecycle
//
//    override func setUp() {
//        super.setUp()
//
//        configureSUT()
//    }
//
//    override func tearDown() {
//        super.tearDown()
//
//        sut = nil
//        provider = nil
//
//        XCTAssertNil(sut)
//        XCTAssertNil(provider)
//    }
//
//    // MARK: - Tests
//
//    func testGivenViewModelWhenCreatedShouldBeAbleToChangeVersion() {
//        let newVersion = 1111
//        sut.changeVersion(newVersion)
//        provider.verifyVersionChange(newVersion, callCount: 1)
//    }
//
//    // MARK: - Private
//
//    private func configureSUT() {
//        provider = MockSystemInfoProvider()
//        sut = SystemInfoViewModel(infoProvider: provider)
//
//        XCTAssertNotNil(provider)
//        XCTAssertNotNil(sut)
//    }
//}

// Dummy

//protocol SystemInformationProvider {
//    func performOperation()
//}
//
//final class SystemInfoViewModel {
//
//    let infoProvider: SystemInformationProvider
//
//    private(set) var someValue: Int = 0
//
//    // MARK: - Lifecycle
//
//    init(infoProvider: SystemInformationProvider) {
//        self.infoProvider = infoProvider
//    }
//
//    func doSometingNotRelatedToInfoProvider() {
//        someValue += 1
//    }
//}
//
//final class SystemInfoViewModelTest: XCTestCase {
//
//    // This is a dummy object
//    private final class DummySystemInfoProvider: SystemInformationProvider {
//        func performOperation() {
//            /*do nothing*/
//        }
//    }
//
//    private var sut: SystemInfoViewModel!
//    private var provider: DummySystemInfoProvider!
//
//    // MARK: - Lifecycle
//
//    override func setUp() {
//        super.setUp()
//
//        configureSUT()
//    }
//
//    override func tearDown() {
//        super.tearDown()
//
//        sut = nil
//        provider = nil
//
//        XCTAssertNil(sut)
//        XCTAssertNil(provider)
//    }
//
//    // MARK: - Tests
//
//    func testGivenViewModelWhenCreatedShouldBeAbleToDoSomething() {
//        XCTAssertEqual(sut.someValue, 0)
//        sut.doSometingNotRelatedToInfoProvider()
//        XCTAssertEqual(sut.someValue, 1)
//    }
//
//    // MARK: - Private
//
//    private func configureSUT() {
//        provider = DummySystemInfoProvider()
//        sut = SystemInfoViewModel(infoProvider: provider)
//
//        XCTAssertNotNil(provider)
//        XCTAssertNotNil(sut)
//    }
//}
//

import SwiftUI
import Foundation
import Charts

@main
@available(iOS 17.0, *)
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            PreviewView()
        }
    }
}

@available(iOS 17.0, *)
struct PreviewView: View {
    @State var progress: Double = Double.random(in: 0...1)
    let stress = StressModel(
        range3: 0...30,
        range2: 30...80
    )

    let stress2 = StressModel(
        range3: 0...60,
        range2: 60...80
    )

    var body: some View {
        VStack {
            StressIndicator(
                title: "",
                stateDescription: "",
                displayValue: 90,
                stressModel: .constant(stress),
                targetProgress: $progress,
                titleLable: {
                    EmptyView()
                }
            )
            .frame(width: 250)

                StressIndicator(
                    title: "Title",
                    stateDescription: "Subtitle",
                    displayValue: 60,
                    stressModel: .constant(stress2),
                    targetProgress: $progress,
                    titleLable: {
                        Text("🐱")
                    }
                )
                .frame(width: 150)

                StressIndicator(
                    title: "Title",
                    stateDescription: "",
                    displayValue: 0,
                    stressModel: .constant(stress2),
                    targetProgress: .constant(0),
                    titleLable: {
                        Text("🐱")
                    }
                )
                .frame(width: 150)

            Slider(value: $progress)
                .tint(.red)
        }
    }
}

enum StressType: Hashable, CaseIterable {
    case state1
    case state2
    case state3

    var title: String {
        switch self {
            case .state1:
                return "State1"
            case .state2:
                return "State2"
            case .state3:
                return "State3"
        }
    }

    var color: Color {
        switch self {
            case .state1:
                return Color.blue
            case .state2:
                return Color.blue.opacity(0.5)
            case .state3:
                return Color.red
        }
    }


    var index: Int {
        switch self {
            case .state1:
                return 2
            case .state2:
                return 1
            case .state3:
                return 0
        }
    }
}


struct StressModel: Hashable {
    struct LevelComponent: Hashable {
        let type: StressType
        let range: ClosedRange<Int>
    }

    let state1Range: ClosedRange<Int>
    let state2Range: ClosedRange<Int>
    let state3Range: ClosedRange<Int>

    var models: [LevelComponent] {
        [
            .init(type: .state3, range: state3Range),
            .init(type: .state2, range: state2Range),
            .init(type: .state1, range: state1Range)
        ]
    }

    init(
        range3: ClosedRange<Int>,
        range2: ClosedRange<Int>
    ) {
        self.state3Range = max(0, range3.lowerBound)
        ...
        min(100, range3.upperBound)

        self.state2Range = min(self.state3Range.upperBound + 1, range2.lowerBound + 1)
        ...
        min(99, range2.upperBound)

        self.state1Range = min(99, range2.upperBound)...100
    }

    // 0...100
    func determineKind(for value: Double) -> StressType {
        switch Int(value.rounded()) {
            case state1Range:
                return .state1
            case state2Range:
                return .state2
            default:
                return .state3
        }
    }

    static func initial() -> StressModel {
        StressModel(
            range3: 0...34,
            range2: 35...65
        )
    }
}



fileprivate enum Constants {
    static let angleDelta: Double = 45
    static let innerOffsetPercentage: Double = 0.65
}

@available(iOS 17.0, *)
struct StressIndicator<Label: View>: View {
    struct Style {
        var backgroundColor: Color = Color.gray
        var indicatorColor: Color = Color.orange
        var sectionNamelabelsColor: Color = Color.green
        var tintColor: Color = Color.blue
    }

    private struct TrapezoidIndicator: Shape {
        var progress: CGFloat
        var thickness: CGFloat
        var offset: CGFloat = 0.0
        var outerScale: CGFloat = 1.0

        var animatableData: CGFloat {
            get { progress }
            set { progress = newValue }
        }

        var degreePerOnePercent: Double {
            (360.0 - Double(Constants.angleDelta) * 2.0) / 100.0
        }

        func path(in rect: CGRect) -> Path {
            let center = CGPoint(x: rect.midX, y: rect.midY)
            let radius = min(rect.width, rect.height) / 2

            let angle = Angle.degrees(
                degreePerOnePercent * Double(progress) * 100.0 + Constants.angleDelta
            )

            let ax = cos(angle.radians)
            let ay = sin(angle.radians)

            let base = CGPoint(
                x: center.x + ax * radius,
                y: center.y + ay * radius
            )

            let innerBase = CGPoint(
                x: center.x + ax * radius * offset,
                y: center.y + ay * radius * offset
            )

            let perpX = -ay / 8
            let perpY = ax / 8

            let p1 = CGPoint(
                x: base.x + perpX * thickness * outerScale,
                y: base.y + perpY * thickness * outerScale
            )
            let p2 = CGPoint(
                x: base.x - perpX * thickness * outerScale,
                y: base.y - perpY * thickness * outerScale
            )

            let scale: Double = 0.1 + 0.9 * (1.0 - Double(abs(offset - 0.5)) * 2.0)
            let ip1 = CGPoint(
                x: innerBase.x + perpX * thickness * scale,
                y: innerBase.y + perpY * thickness * scale
            )
            let ip2 = CGPoint(
                x: innerBase.x - perpX * thickness * scale,
                y: innerBase.y - perpY * thickness * scale
            )

            var path = Path()
            path.move(to: ip1)
            path.addLine(to: p1)
            path.addLine(to: p2)
            path.addLine(to: ip2)
            path.closeSubpath()
            return path
        }
    }

    private struct SectorModel: Identifiable, Equatable {
        var id: Int { index }
        let index: Int
        let value: Double
        var type: StressType?

        var color: Color {
            type?.color ?? .clear
        }

        var isHidden: Bool {
            type == nil
        }
    }

    private struct LabelModel: Identifiable, Equatable {
        let id = UUID()
        let type: StressType
        let angle: Angle

        var title: String {
            type.title
        }
    }

    let title: String
    let stateDescription: String
    let displayValue: Int
    @Binding var stressModel: StressModel
    @Binding var targetProgress: Double
    @ViewBuilder var titleLable: () -> Label
    var style: Style = .init()
    @State private var animateAppearence = false

    @State private var progress: CGFloat = 0.0
    @State private var visibleModels: [SectorModel] = []
    @State private var appearenceProgress: Double = 0

    private let sectorsCount: Int = 73
    private let sectionCornerRadius: CGFloat = 0

    private var models: [SectorModel] {
        var result: [SectorModel] = []

        for idx in 0..<invisibleSectors {
            result.append(SectorModel(
                index: idx,
                value: valueWeightPerSector,
                type: nil
            ))
        }

        let visibleCount = sectorsCount - invisibleSectors * 2
        let weightOfSectorPercent = Double(visibleCount) / 100.0

        var visiblePart: [SectorModel] = []
        for level in stressModel.models {
            let lower = Int(Double(level.range.lowerBound) * weightOfSectorPercent)
            let upper = Int(Double(level.range.upperBound) * weightOfSectorPercent)
            for idx in lower..<upper {
                visiblePart.append(SectorModel(
                    index: result.count + idx,
                    value: valueWeightPerSector,
                    type: level.type
                ))
            }
        }

        result.append(contentsOf: visiblePart)
        assert(result.count < sectorsCount)
        while result.count < sectorsCount {
            result.append(SectorModel(
                index: result.count,
                value: valueWeightPerSector,
                type: nil
            ))
        }

        return result
    }

    private var labelModels: [LabelModel] {
        var labelsToReturn: [LabelModel] = []

        let grouped = Dictionary(grouping: models) {
            $0.type
        }
            .compactMap { (type, group) -> (StressType, [SectorModel])? in
                guard let t = type else {
                    return nil
                }
                return (t, group)
            }

        for (type, group) in grouped {
            guard let first = group.first,
                  let last = group.last else {
                continue
            }

            let midIndex = (Double(first.index) + Double(last.index) + 1.0) / 2.0
            var angle = midIndex * valueWeightPerSector

            let chartRotation: Double = 90.0
            angle += chartRotation

            labelsToReturn.append(
                LabelModel(
                    type: type,
                    angle: .degrees(angle)
                )
            )
        }
        return labelsToReturn
    }

    private var invisibleSectorDegree: Double {
        Constants.angleDelta
    }

    private var sectorsPerDeegree: Double {
        Double(sectorsCount) / Double(360)
    }

    private var invisibleSectors: Int {
        Int(sectorsPerDeegree * invisibleSectorDegree)
    }

    private var valueWeightPerSector: Double {
        Double(360) / Double(sectorsCount)
    }

    var body: some View {
        GeometryReader { proxy in
            let containerDim = min(proxy.size.width, proxy.size.height)

            ZStack {
                Chart(progress == 0 ? [] : visibleModels) { sectorModel in
                    SectorMark(
                        angle: .value("Value", sectorModel.value),
                        innerRadius: .ratio(Constants.innerOffsetPercentage),
                        outerRadius: .inset(0),
                        angularInset: 0.75
                    )
                    .cornerRadius(sectionCornerRadius)
                    .foregroundStyle(sectorModel.color)
                }
                .animation(animateAppearence ? .easeOut : .none, value: progress)
                .chartOverlay { proxy in
                    TrapezoidIndicator(
                        progress: progress,
                        thickness: max(12, min(proxy.plotSize.width, proxy.plotSize.height) * 0.1),
                        offset: 0.3,
                    )
                    .fill(style.indicatorColor)
                    .frame(width: proxy.plotSize.width, height: proxy.plotSize.height)
                    .rotationEffect(Angle(degrees: -90))
                    .shadow(
                        color: style.indicatorColor.opacity(0.3),
                        radius: 3,
                        x: -5,
                        y: -5
                    )
                    .animation(.easeOut(duration: 0.75), value: progress)
                }
                .chartBackground(content: { _ in
                    Chart(models) { sectorModel in
                        SectorMark(
                            angle: .value("ValueBg", sectorModel.value),
                            innerRadius: .ratio(Constants.innerOffsetPercentage),
                            outerRadius: .inset(0),
                            angularInset: 0.75
                        )
                        .cornerRadius(sectionCornerRadius)
                        .foregroundStyle(
                            sectorModel.isHidden
                            ? sectorModel.color
                            : style.backgroundColor
                        )
                    }
                    .opacity(progress == 0 ? 1 : 0)

                })
                .rotationEffect(Angle(degrees: 180))

                VStack(spacing: 4) {
                    let valueToShow = displayValue == 0 ? "-" : "\(displayValue)"
                    Text("\(valueToShow)")
                        .foregroundStyle(style.tintColor)
                        .font(.system(size: containerDim * 0.15, weight: .semibold))

                    HStack(spacing: 2) {
                        Spacer()
                        Text(title)
                            .foregroundStyle(style.tintColor)
                            .font(.system(size: containerDim * 0.075, weight: .semibold))
                            .multilineTextAlignment(.center)
                        titleLable()
                        Spacer()
                    }
                    .frame(width: proxy.size.width * 0.5)
                }
                .animation(.easeOut, value: appearenceProgress)
                .scaleEffect(appearenceProgress)
                .frame(height: proxy.size.height / 3)
                .opacity(progress == 0 ? 0 : 1)

                VStack {
                    Spacer()
                        .frame(height: containerDim * 0.75)

                    Text(stateDescription)
                        .foregroundStyle(style.tintColor)
                        .font(.system(size: containerDim * 0.075, weight: .semibold))
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: containerDim * 0.4)
                        .animation(.easeOut, value: appearenceProgress)
                        .scaleEffect(appearenceProgress)
                        .opacity(appearenceProgress)
                }

                GeometryReader { geo in
                    let radius = min(geo.size.width, geo.size.height) / 2
                    ForEach(labelModels) { label in
                        let ax = cos(label.angle.radians)
                        let ay = sin(label.angle.radians)

                        let additionalYOffset: Double = 12

                        let r = radius * 1.32
                        let x = geo.size.width / 2 + ax * r
                        let y = geo.size.height / 2 + ay * r + additionalYOffset

                        Text(label.title)
                            .font(.system(size: containerDim * 0.06, weight: .semibold))
                            .foregroundStyle(style.sectionNamelabelsColor)
                            .position(x: x, y: y)
                    }
                }
                .animation(.easeOut, value: progress)
                .scaleEffect(appearenceProgress)
                .opacity(appearenceProgress)
                .opacity(progress == 0 ? 0 : 1)
            }
            .onAppear {
                progress = clamp(targetProgress)
                refreshData()
            }
            .onChange(of: targetProgress) { _, newValue in
                withAnimation(.easeOut) {
                    progress = clamp(newValue)
                }
            }
            .onChange(of: stressModel) { _, _ in
                if !animateAppearence {
                    refreshData()
                }
            }
        }
    }

    private func refreshData() {
        if animateAppearence {
            Task {
                let drawingSystemRequiredDelayInNanoSec: UInt64 = 100_000_000
                try? await Task.sleep(nanoseconds: drawingSystemRequiredDelayInNanoSec)

                await MainActor.run {
                    visibleModels = []
                }

                for (i, model) in models.enumerated() {
                    try? await Task.sleep(nanoseconds: UInt64(i))
                    await MainActor.run {
                        withAnimation(.easeOut) {
                            visibleModels.append(model)
                            appearenceProgress = Double(visibleModels.count) / Double(sectorsCount)
                            if appearenceProgress >= 1.0 {
                                animateAppearence = false
                            }
                        }
                    }
                }
            }
        } else {
            visibleModels = models
            appearenceProgress = 1.0
        }
    }

    private func clamp(_ value: CGFloat) -> CGFloat {
        min(max(value, 0.0), 1.0)
    }
}

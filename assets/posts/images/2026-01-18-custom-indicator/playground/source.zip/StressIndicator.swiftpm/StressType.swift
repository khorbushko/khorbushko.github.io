//
//  StressType.swift
//  StressIndicator
//
//  Created by Kyrylo Horbushko on 18.01.2026.
//


//
//  StressType 2.swift
//  StressIndicator
//
//  Created by Kyrylo Horbushko on 18.01.2026.
//


import SwiftUI
import Foundation
import Charts
import SwiftUI
import SwiftUI
import Foundation
import Charts
import SwiftUI

//
//  testWindowGroupApp.swift
//  Shared
//
//  Created by Kyryl Horbushko on 24.04.2021.
//

import SwiftUI

NSWindow.allowsAutomaticWindowTabbing

@main
struct testWindowGroupApp: App {
  
  @Environment(\.openURL) var openURL
  
  var body: some Scene {
    
    WindowGroup {
      ContentView()
        .frame(width: 200, height: 200)
        .handlesExternalEvents(preferring: ["*"], allowing: ["*"])
    }
    .commands {
      CommandMenu("MyMenu") {
        Button("Show my Scene") {
          openURL(URL(string: "myApp://myScene")!)
        }
        .keyboardShortcut("w")
      }
    }
    .handlesExternalEvents(matching: ["main"])
    
    MyScene()
      .handlesExternalEvents(matching: ["myScene"])

    
    Settings {
      VStack {
        Text("Bonjur")
      }
      .frame(width: 300, height: 400)
    }

//   uncomment to see a bug
    
//    Settings {
//      VStack {
//        Text("Bonjur2")
//      }
//      .frame(width: 300, height: 400)
//    }
  }
}

struct MyScene: Scene {
  var body: some Scene {
    WindowGroup {
      MyView()
        .frame(width: 200, height: 200)
        .background(Color.red)
    }
  }
}


struct MyView: View {
  var body: some View {
    Text("Aloha")
  }
}

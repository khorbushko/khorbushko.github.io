import Combine

extension Publisher {
    public func mappper<Result>(
        _ transform: @escaping (Output) -> Result
    ) -> Publishers.Mapper<Self, Result> {
        Publishers.Mapper(upstream: self, transform: transform)
    }
}

extension Publishers {
    public struct Mapper<Upstream: Publisher, Output>: Publisher {
        public typealias Failure = Upstream.Failure
        public let upstream: Upstream
        public let transformClosure: (Upstream.Output) -> Output
        
        public init(
            upstream: Upstream,
            transform: @escaping (Upstream.Output) -> Output
        ) {
            self.upstream = upstream
            self.transformClosure = transform
        }
        
        public func receive<S>(subscriber: S)
        where S: Subscriber,
              Output == S.Input,
              S.Failure == Upstream.Failure {
            upstream.subscribe(
                MapperSubscriber<S>(
                    subscriber: subscriber,
                    mapClosure: transformClosure
                )
            )
        }
    }
}

extension Publishers.Mapper {
    private struct MapperSubscriber<S: Subscriber>: Subscriber
    where S.Input == Output,
          S.Failure == Upstream.Failure {
        
        typealias Input = Upstream.Output
        typealias Failure = Upstream.Failure
        
        private let subscriber: S
        private let mapClosure: (Input) -> Output
        let combineIdentifier: CombineIdentifier = .init()
        
        fileprivate init(
            subscriber: S,
            mapClosure: @escaping (Input) -> Output
        ) {
            self.subscriber = subscriber
            self.mapClosure = mapClosure
        }
        
        func receive(subscription: Subscription) {
            subscriber.receive(subscription: subscription)
        }
        
        func receive(_ input: Input) -> Subscribers.Demand {
            subscriber.receive(mapClosure(input))
        }
        
        func receive(completion: Subscribers.Completion<Upstream.Failure>) {
            subscriber.receive(completion: completion)
        }
    }
}

// tests

let token = [1,2,3,4]
    .publisher
    .mappper { value in
        "\(value)"
    }
    .sink { (completionn) in

    } receiveValue: { (result) in
        print("mapped values :", result, type(of: result))
    }

token
    

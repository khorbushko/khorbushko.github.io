#include <cstdint>
#include <stdexcept>
#include <random>
#include <iostream>
#include <format>
#include <numeric>
#include <vector>
#include <cmath>
#include <algorithm>
#include <string>

class RSA
{

public:
    RSA()
    {
        std::random_device rd;
        std::mt19937 gen(rd()); // Mersenne Twister
        std::uniform_int_distribution<> distr(1, 100);

        do
        {
            m_primeP = distr(gen);
        } while (!isPrime(m_primeP));

        do
        {
            m_primeQ = distr(gen);
        } while (!isPrime(m_primeQ));

        std::cout << std::format("P - {}, Q - {}\n", m_primeP, m_primeQ);

        m_modulusN = m_primeP * m_primeQ;
        std::cout << "Modulus " << m_modulusN << "\n";

        m_eulerTotient = (m_primeP - 1) * (m_primeQ - 1);
        std::cout << "Euler’s totient function " << m_eulerTotient << "\n";

        long long coprime{0};

        std::vector<long long> primeFactors = getPrimeFactors(m_eulerTotient);
        std::cout << std::format("Prime factorization of {} is\n", m_eulerTotient);
        outputVector(primeFactors);

        long long maxPrime = *std::max_element(primeFactors.begin(), primeFactors.end());

        if (maxPrime < m_eulerTotient)
        {
            std::vector<long long> primeNumbers = primeForNumberFrom(maxPrime, m_eulerTotient);
            std::cout << std::format("\nPossible values for exponent are:\n");
            outputVector(primeNumbers);

            std::uniform_int_distribution<> dist(0, primeNumbers.size() - 1);
            int location = dist(gen);
            m_encryptionExponent = primeNumbers.at(location);
            std::cout << std::format("\nSelected encr exponent is {}\n", m_encryptionExponent);

            m_publicKey.push_back(m_encryptionExponent);
            m_publicKey.push_back(m_modulusN);
            std::cout << std::format("\nPublic key:\n");
            outputVector(m_publicKey);

            // choose first one exponent such so (d * e) mod Φ(n) = 1
            // next can be (first one exponent + N * Euler’s totient function), where
            // N = 1...n
            m_decryptionExponent = modInverse(m_encryptionExponent, m_eulerTotient);
            std::cout << std::format("\nSelected decr exponent is {}\n", m_decryptionExponent);

            m_privateKey.push_back(m_decryptionExponent);
            m_privateKey.push_back(m_modulusN);
            std::cout << std::format("\nPrivate key:\n");
            outputVector(m_privateKey);
        }
        else
        {
            throw std::invalid_argument{
                "invalid random range maxPrime > m_eulerTotient"};
        }
    };

    // C = M^e mod n. Each block is little-endian, fixed width: holds any value in [0, n).
    std::string encrypt(const std::string &plaintext)
    {
        const int blockBytes = ciphertextBlockBytes();
        std::string result;
        result.reserve(plaintext.size() * static_cast<size_t>(blockBytes));

        for (size_t i{0}; i < plaintext.size(); ++i)
        {
            const std::uint64_t m = static_cast<unsigned char>(plaintext[i]);
            const long long decValue = powerMod(m, m_encryptionExponent, m_modulusN);
            const std::uint64_t c = static_cast<std::uint64_t>(decValue);
            for (int b{0}; b < blockBytes; ++b)
            {
                const auto byte = static_cast<unsigned char>((c >> (8 * b)) & 0xFFu);
                result.push_back(static_cast<char>(byte));
            }
        }

        return result;
    }

    std::string decrypt(const std::string &cipher)
    {
        // Must use the same byte width as encrypt() so each RSA block lines up in the buffer.
        const int blockBytes = ciphertextBlockBytes();
        // Every block is exactly blockBytes long; anything else means corrupt or truncated input.
        if (blockBytes < 1 || (cipher.size() % static_cast<size_t>(blockBytes)) != 0)
        {
            throw std::invalid_argument("decrypt: cipher length is not a multiple of block size");
        }

        // Rebuilt plaintext (one original char per cipher block).
        std::string result;
        // Avoid reallocations: one output char per block of input bytes.
        result.reserve(cipher.size() / static_cast<size_t>(blockBytes));

        // Walk the raw cipher in steps of one full block (little-endian bytes).
        for (size_t i{0}; i < cipher.size(); i += static_cast<size_t>(blockBytes))
        {
            // Integer value c in [0, n) — the RSA ciphertext for this character.
            std::uint64_t c{0};
            // Reassemble c from blockBytes bytes (LSB first; matches encrypt’s output order).
            for (int b{0}; b < blockBytes; ++b)
            {
                // OR in each byte in the right 8-bit lane; unsigned char avoids sign-extension bugs.
                c |= static_cast<std::uint64_t>(
                         static_cast<unsigned char>(cipher[i + static_cast<size_t>(b)]))
                     << (8 * b);
            }
            // RSA: m = c^d mod n (same modulus and private exponent as used at key setup).
            const std::uint64_t m =
                static_cast<std::uint64_t>(powerMod(c, m_decryptionExponent, m_modulusN));
            // This toy scheme packs one ASCII byte per block; values above 255 would be invalid.
            if (m > 255u)
            {
                throw std::runtime_error("decrypt: recovered byte out of char range (message too long for n)");
            }
            // Push the recovered byte into the output string (narrow to char safely).
            result.push_back(static_cast<char>(static_cast<unsigned char>(m)));
        }

        return result;
    }

private:
    long long m_primeP{0};
    long long m_primeQ{0};
    long long m_modulusN{0};
    long long m_eulerTotient{0};

    long long m_encryptionExponent{0};
    long long m_decryptionExponent{0};

    std::vector<long long> m_publicKey{};
    std::vector<long long> m_privateKey{};

    // Manual Euclidean Algorithm to find coprime
    int gcd(long long a, long long b)
    {
        while (b != 0)
        {
            long long temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    std::vector<long long> getPrimeFactors(long long n)
    {
        std::vector<long long> factors;
        // Handle the factor 2 separately to allow for incrementing by 2 in the loop
        while (n % 2 == 0)
        {
            factors.push_back(2);
            n /= 2;
        }
        // Check odd numbers from 3 up to sqrt(n)
        for (long long i = 3; i * i <= n; i += 2)
        {
            while (n % i == 0)
            {
                factors.push_back(i);
                n /= i;
            }
        }
        // If n is still > 1, the remaining n must be prime
        if (n > 1)
            factors.push_back(n);
        return factors;
    }

    bool isPrime(int num)
    {
        if (num <= 1)
            return false;
        if (num == 2)
            return true;
        if (num % 2 == 0)
            return false;

        for (int i = 3; i <= std::sqrt(num); i += 2)
        {
            if (num % i == 0)
                return false;
        }
        return true;
    }

    std::vector<long long> primeForNumberFrom(long long from, long long to)
    {
        std::vector<long long> result{};
        std::cout << "\nPrimes between " << from << " and " << to << ": \n";

        for (long long i{from + 1}; i < to; ++i)
        {
            if (isPrime(i))
            {
                result.push_back(i);

                std::cout << i << " ";
            }
        }

        std::cout << "\n";

        return result;
    }

    // Returns d such that (d * e) % phi == 1
    long long modInverse(long long e, long long phi)
    {
        long long m0 = phi, t, q;
        long long x0 = 0, x1 = 1;

        if (phi == 1)
            return 0;

        while (e > 1)
        {
            // q is quotient
            q = e / phi;
            t = phi;

            // phi is remainder now, process same as Euclid's algo
            phi = e % phi;
            e = t;
            t = x0;

            x0 = x1 - q * x0;
            x1 = t;
        }

        // Make x1 positive if it is negative
        if (x1 < 0)
            x1 += m0;

        return x1;
    }

    /**
     * Calculates (base^exp) % mod
     */
    long long powerMod(std::uint64_t base, long long exp, long long mod)
    {
        std::uint64_t res = 1;
        base %= mod; // Update base if it is more than or equal to mod

        while (exp > 0)
        {
            // If exp is odd, multiply base with result
            if (exp % 2 == 1)
            {
                res = (res * base) % mod;
            }
            // Square the base and halve the exponent
            base = (base * base) % mod;
            exp /= 2;
        }
        return res;
    }

    /// Bytes needed to store any value in [0, n) for the current modulus.
    /// 
    /// After RSA encryption, one block is a number c = m^e mod N, and 
    /// it is always in 0 .. N−1 inclusive. The helper question: 
    /// “How many bytes do we need, in a fixed width, to store any such c?”
    /// It does not use N directly; it uses N − 1, because the largest
    /// possible ciphertext in one block is N − 1.
    /// 
    int ciphertextBlockBytes() const
    {
        const auto n = static_cast<std::uint64_t>(m_modulusN);
        if (n <= 1u)
        {
            return 1;
        }
        int bytes{0};

        /*
        Shift v right by 8 bits repeatedly until it
        becomes 0, counting shifts.
        That count is the number of non-zero bytes 
        in the value N − 1 in base 256, i.e. the minimum B 
        so that you can store every value in 0 .. N−1 using
        B bytes (e.g. little-endian, with high bytes zero for small values).
        */
        for (std::uint64_t v = n - 1u; v > 0u; v >>= 8u)
        {
            ++bytes;
        }
        return bytes;
    }

    void outputVector(const std::vector<long long> &items)
    {
        for (const int &item : items)
        {
            std::cout << item << ' ';
        }

        std::cout << "\n";
    }
};
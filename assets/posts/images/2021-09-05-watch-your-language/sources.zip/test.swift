import Foundation

@inlinable
func valueORDefault<T>(value: @autoclosure () throws -> T?, defaultValue: @autoclosure () throws -> T) rethrows -> T {
  try value() ?? (try defaultValue())
}

var optionalValue: String? = "I love coffee"
let defaultValue: String = "yep"

func test__1() -> String {
  valueORDefault(value: optionalValue, defaultValue: defaultValue)
}

func test__2() -> String {
  optionalValue ?? defaultValue
}
//
//  DynamicTestView.swift
//  dynamicProperty
//
//  Created by Kyryl Horbushko on 1/6/21.
//

import Foundation
import SwiftUI

//class ExampleClass: DynamicProperty { }
//struct ExampleStruct: DynamicProperty { }


//protocol DefaultValueProvidable {
//    static func defaultValue() -> Self
//}
//
//@propertyWrapper
//struct StoredValue<T>: DynamicProperty where T: DefaultValueProvidable {
//
//    var wrappedValue: T {
//        get {
//            UserDefaults.standard.value(forKey: "testKey.storedValue") as? T ?? T.defaultValue()
//        }
//        nonmutating set {
//            UserDefaults.standard.setValue(newValue, forKey: "testKey.storedValue")
//        }
//    }
//
//    init(wrappedValue value: T) {
//        self.wrappedValue = value
//    }
//}
//
//extension Int: DefaultValueProvidable {
//    static func defaultValue() -> Self {
//        0
//    }
//}

@propertyWrapper
struct StoredValue<T>: DynamicProperty  {

    final private class Storage: ObservableObject {
        var value: T {
            willSet {
                objectWillChange.send()
            }
        }

        init(_ value: T) {
            self.value = value
        }
    }

    @ObservedObject private var storage: Storage

    var wrappedValue: T {
        get {
            storage.value
        }
        nonmutating set {
            storage.value = newValue
        }
    }

    init(wrappedValue value: T) {
        self.storage = Storage(value)
    }
}

struct DynamicTestView: View {
    
    @StoredValue private var testValue: Int = 0
    
    var body: some View {
        VStack {
            Text("Testing DynamicProperty")
                .padding()
                .background(testValue % 2 == 0 ? Color.red : Color.green)
            
            Button(action: {
                testValue += 1
            }, label: {
                Text("Tap")
            })
        }
    }
}

struct DynamicTestView_Previews: PreviewProvider {
    static var previews: some View {
        DynamicTestView()
    }
}

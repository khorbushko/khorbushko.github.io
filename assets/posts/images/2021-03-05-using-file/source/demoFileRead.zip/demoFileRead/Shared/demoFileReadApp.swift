//
//  demoFileReadApp.swift
//  Shared
//
//  Created by Kyryl Horbushko on 05.03.2021.
//

import SwiftUI

@main
struct demoFileReadApp: App {

  init() {
//    if let path = Bundle.main.path(forResource: "Text", ofType: "txt"),
//       let file = try? FileReader(path){
//      while let line = try? file.readNextLine() {
//        print(line)
//      }
//    }

    let path = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first
    let file = path?.appendingPathComponent("CreatedFile.txt")

    if let writer = try? FileWriter(file!.path) {
      let text = "Hello world"
      try? writer.write(text)
    }

//    if let remover = try? FileRemover(file!.path) {
//      try? remover.remove()
//    }

    if let dispatchReader = try? DispatchIOReader(file!.path) {
      try? dispatchReader.read(byteRange: 0..<300) { (result) in
        switch result {
          case .failure(let error):
            print(error)
          case .success(let resultTuple):
            let data = resultTuple.0?.compactMap({ UInt8($0) }) ?? []
            let text = String(data: Data(data), encoding: .utf8)
            print("Read - ", text)
        }
      }
    }

    // InputStream
    let inputStream = InputStream(url: file!)
    inputStream?.open()
    while inputStream?.hasBytesAvailable == true {
      let buff = UnsafeMutablePointer<UInt8>.allocate(capacity: 8)
      let result = inputStream?.read(buff, maxLength: 5)

      let bytesArray = UnsafeBufferPointer(start: buff, count: 8).map{$0}
      print("read \(result) bytes ", String(data: Data(bytesArray), encoding: .utf8))
    }

    inputStream?.close()

    let outputStream = OutputStream(url: file!, append: true)
    outputStream?.open()

    let data = "Aloha".data(using: .utf8)
    var buffer = Array(data!)
    let result = outputStream?.write(&buffer, maxLength: 5)
    print("write \(result) bytes ", String(data: try! Data(contentsOf: file!), encoding: .utf8))
    outputStream?.close()
  }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

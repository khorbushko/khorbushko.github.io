//
//  FileRemover.swift
//  demoFileRead
//
//  Created by Kyryl Horbushko on 05.03.2021.
//

import Foundation

final class FileRemover {

  enum Failure: Error {
    case cantFindFile(String)
    case cantRemove
  }

  private var path: String?

  init(_ path: String) throws {
    let file = fopen(path, "w")
    if file == nil {
      throw Failure.cantFindFile(path)
    } else {
      fclose(file)
      self.path = path
    }
  }

  func remove() throws {
    let name = [Int8](path!.utf8.map { Int8($0) })
    let err = Darwin.remove(name)
    if err != 0 {
      throw Failure.cantRemove
    }
  }
}

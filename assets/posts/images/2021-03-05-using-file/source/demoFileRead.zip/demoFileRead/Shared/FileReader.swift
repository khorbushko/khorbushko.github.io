//
//  FileReade.swift
//  demoFileRead
//
//  Created by Kyryl Horbushko on 05.03.2021.
//

import Foundation

final class FileReader {

  enum Failure: Error {
    case cantReadFile(String)
    case cantReadLine
  }

  private var file: UnsafeMutablePointer<FILE>?

  // MARK: - Lifecycle

  init(_ path: String) throws {
    file = fopen(path, "r")
    if file == nil {
      throw Failure.cantReadFile(path)
    }
  }

  deinit {
    fclose(file)
  }

  // MARK: - Public

  func readNextLine() throws -> String? {
    var line: String
    repeat {
      // create buffer
      var buffer = [CChar](repeating: 0, count: 1024)

      // Reads characters from stream and stores them as a C string into str until
      // (num-1) characters have been read or either a newline or the end-of-file
      // is reached, whichever happens first.
      if fgets(&buffer, Int32(buffer.count), file) == nil {

        // Checks if the error indicator associated with stream is set,
        // returning a value different from zero if it is.
        if ferror(file) != 0 {
          throw Failure.cantReadLine
        }

        return nil
      }
      // append line
      line = String(cString: buffer)
    } while line.lastIndex(of: "\n") == nil
    return line
  }
}


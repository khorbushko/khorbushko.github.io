//
//  DispatchIOReader.swift
//  demoFileRead
//
//  Created by Kyryl Horbushko on 05.03.2021.
//

import Foundation

final class DispatchIOReader {

  typealias IsReadingCompleted = Bool

  enum Failure: Error {
    case cantFindFile
    case cantFindChannel
    case readingIssue(Int32)
  }

  var channel: DispatchIO?

  init(_ path: String) throws {
    let inputPath = [Int8](path.utf8.map { Int8($0) })
    channel = DispatchIO(
      type: .random,
      path: inputPath,
      oflag: 0,
      mode: 0,
      queue: .main,
      cleanupHandler: { (errCode) in

      })

    if channel == nil {
      throw Failure.cantFindFile
    }

    channel?.setLimit(lowWater: .max)
  }

  deinit {
    channel?.close()
    channel = nil
  }

  // MARK: - Public

  func read(
    byteRange: CountableRange<Int>,
    queue: DispatchQueue = .main,
    completion: @escaping (Result<(DispatchData?, IsReadingCompleted), Error>) -> Void
  ) throws {
    if let channel = channel {
      // `off_t` This is a data type defined in the sys/types.h header file (of fundamental type unsigned long) and is used to measure the file offset in bytes from the beginning of the file. It is defined as a signed, 32-bit integer, but if the programming environment enables large files off_t is defined to be a signed, 64-bit integer.

      channel.read(
        offset: off_t(byteRange.startIndex),
        length: byteRange.count,
        queue: queue,
        ioHandler: { done, data, errorCode in
          if errorCode != 0 {
            completion(.failure(Failure.readingIssue(errorCode)))
          } else {
            completion(.success((data, done)))
          }
      })
    } else {
      throw Failure.cantFindChannel
    }
  }
}

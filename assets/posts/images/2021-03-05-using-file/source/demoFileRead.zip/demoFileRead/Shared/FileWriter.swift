//
//  FileWriter.swift
//  demoFileRead
//
//  Created by Kyryl Horbushko on 05.03.2021.
//

import Foundation

final class FileWriter {

  enum Failure: Error {
    case cantCreateFile(String)
    case writeError
  }

  var file: UnsafeMutablePointer<FILE>?

  init(_ path: String) throws {
    file = fopen(path, "w")
    if file == nil {
      throw Failure.cantCreateFile(path)
    }
  }

  deinit {
    fclose(file)
  }

  func write(_ text: String) throws {
    let buffer = [UInt8](text.utf8)
    let writtenCharCount = fwrite(buffer, MemoryLayout<UInt8>.size, buffer.count, file);

    // chronize a file's in-core state with storage device
    // map a stream pointer to a file descriptor
    fsync(fileno(file));

    if writtenCharCount != buffer.count {
      throw Failure.writeError
    }
  }
}

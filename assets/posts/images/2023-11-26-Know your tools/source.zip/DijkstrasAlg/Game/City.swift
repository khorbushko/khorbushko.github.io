//
//  City.swift
//  DijkstrasAlg
//
//  Created by Kyryl Horbushko on 23.11.2023.
//

import Foundation

struct City: Hashable {
  enum Region: Hashable {
    case blue
    case brown
    case yellow
    case orange
    case purple
    case green
    case pink
  }

  let region: City.Region
  let name: String
}

extension City: CustomStringConvertible {
  var description: String {
    name
  }
}

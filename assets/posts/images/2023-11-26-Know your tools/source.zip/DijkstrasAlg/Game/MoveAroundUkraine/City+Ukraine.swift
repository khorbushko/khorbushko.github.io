//
//  City+Ukraine.swift
//  DijkstrasAlg
//
//  Created by Kyryl Horbushko on 23.11.2023.
//

import Foundation

extension City {
  static let lviv: City = .init(region: .pink, name: "Львів")
  static let uzhgorod: City = .init(region: .pink, name: "Ужгород")
  static let drohobuch: City = .init(region: .pink, name: "Дрогобич")
  static let ternopil: City = .init(region: .pink, name: "Тернопіль")
  static let ivanoFrankivsk: City = .init(region: .pink, name: "Івано-Франківськ")
  static let chernivtsi: City = .init(region: .pink, name: "Чернівці")

  static let lutsk: City = .init(region: .blue, name: "Луцьк")
  static let kovel: City = .init(region: .blue, name: "Ковель")
  static let rivne: City = .init(region: .blue, name: "Рівне")
  static let zhutomyr: City = .init(region: .blue, name: "Житомир")
  static let korosten: City = .init(region: .blue, name: "Коростень")
  static let kyiv: City = .init(region: .blue, name: "Київ")

  static let chernihiv: City = .init(region: .purple, name: "Чернігів")
  static let poltava: City = .init(region: .purple, name: "Полтава")
  static let konotop: City = .init(region: .purple, name: "Конотоп")
  static let sumy: City = .init(region: .purple, name: "Суми")
  static let kharkiv: City = .init(region: .purple, name: "Харків")
  static let pryluky: City = .init(region: .purple, name: "Прилуки")

  static let khmelnytskiy: City = .init(region: .green, name: "Хмельницький")
  static let kPodilskiy: City = .init(region: .green, name: "Кам`янець-Подільський")
  static let vinnutsya: City = .init(region: .green, name: "Вінниця")
  static let bilaTserkva: City = .init(region: .green, name: "Біла Церква")
  static let uman: City = .init(region: .green, name: "Умань")
  static let balta: City = .init(region: .green, name: "Балта")

  static let cherkasu: City = .init(region: .orange, name: "Черкаси")
  static let kremenchyk: City = .init(region: .orange, name: "Кременчук")
  static let kropyvnytskiy: City = .init(region: .orange, name: "Кропивницький")
  static let dnipro: City = .init(region: .orange, name: "Дніпро")
  static let kryvyiRih: City = .init(region: .orange, name: "Кривий Ріг")
  static let zaporizzhya: City = .init(region: .orange, name: "Запоріжжя")

  static let voznesensk: City = .init(region: .yellow, name: "Вознесенськ")
  static let odesa: City = .init(region: .yellow, name: "Одеса")
  static let mykolaiv: City = .init(region: .yellow, name: "Миколаїв")
  static let kherson: City = .init(region: .yellow, name: "Херсон")
  static let melitopol: City = .init(region: .yellow, name: "Мелітополь")
  static let simpheropol: City = .init(region: .yellow, name: "Сімферополь")

  static let lozova: City = .init(region: .purple, name: "Лозова")
  static let lysychansk: City = .init(region: .purple, name: "Лисичанськ")
  static let slovyanks: City = .init(region: .purple, name: "Слов`янськ")
  static let luhansk: City = .init(region: .purple, name: "Луганськ")
  static let donetsk: City = .init(region: .purple, name: "Донецьк")
  static let mariupol: City = .init(region: .purple, name: "Маріуполь")
}

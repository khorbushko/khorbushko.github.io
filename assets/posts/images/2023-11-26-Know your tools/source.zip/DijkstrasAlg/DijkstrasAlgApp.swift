//
//  DijkstrasAlgApp.swift
//  DijkstrasAlg
//
//  Created by Kyryl Horbushko on 14.11.2023.
//

import SwiftUI

@main
struct DijkstrasAlgApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}


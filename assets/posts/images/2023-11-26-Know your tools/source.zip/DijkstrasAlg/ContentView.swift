//
//  ContentView.swift
//  DijkstrasAlg
//
//  Created by Kyryl Horbushko on 14.11.2023.
//

import SwiftUI

import Graph

struct ContentView: View {

  init() {

    let cities: [City] = [
      .lviv,
      .lutsk,
      .cherkasu,
      .vinnutsya,
      .poltava,
      .voznesensk,
      .lozova
    ]

    Task {
      let result = await MoveAroundUkraine.calculateFastestTripBetween(cities)

      print("Best required \(result.reduce(0, { $0 + ($1.weight ?? 0) })) steps")
      for edge in result {
        print("\(edge.source) -> \(edge.destination)")
      }
    }

  }

  var body: some View {
    VStack {
      Image(systemName: "globe")
        .imageScale(.large)
        .foregroundStyle(.tint)
      Text("Hello, world!")

      

    }
    .padding()
  }
}


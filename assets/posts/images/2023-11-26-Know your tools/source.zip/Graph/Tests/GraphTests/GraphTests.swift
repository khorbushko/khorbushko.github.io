import XCTest
@testable import Graph

final class GraphTests: XCTestCase {

}

import Foundation

class Random {

  func callAsFunction(_ range: Range<Int>) -> Int {
    Int.random(in: range)
  }

  func callAsFunction<T>(_ range: Range<T>) -> T where T: FixedWidthInteger {
    T.random(in: range)
  }

  func generateRandom() -> (_ range: Range<Int>) -> Int {
    { inputRange in Int.random(in: inputRange) }
  }
}

let random = Random()
let num = random(0..<100)

let num2 = random.generateRandom()(0..<100)

let lowerBounds: UInt8 = 0
let upperBounds: UInt8 = .max
let num3 = random(lowerBounds..<upperBounds)

//
//  gesturesApp.swift
//  gestures
//
//  Created by Kyryl Horbushko on 12/30/20.
//

import SwiftUI

@main
struct gesturesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  ContentView.swift
//  gestures
//
//  Created by Kyryl Horbushko on 12/30/20.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        TapGestureDemoView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct CombinatedGestureDemoView: View {
    @GestureState private var dragTranslation: CGSize = .zero
    @GestureState private var isLongPressActivated = false
    @State private var isScaled = false
    
    var body: some View {
        Text("Hello")
            .padding()
            .background(isLongPressActivated ? Color.green: Color.red)
            .cornerRadius(4)
            .scaleEffect(isScaled ? 1.2 : 1)
            .offset(x: dragTranslation.width, y: dragTranslation.height)
            .gesture(
                LongPressGesture(minimumDuration: 1.0)
                    .updating(
                        $isLongPressActivated,
                        body: { (currentState, state, transaction) in
                            state = currentState
                        })
                    // on End LongPressGesture
                    .onEnded({ (_) in
                        isScaled = true
                    })
                    .sequenced(before: DragGesture())
                    .updating(
                        $dragTranslation,
                        body: { (value, state, transition) in
                            // value can contain as many sequence element as u added
                            switch value {
                            // select only one that we need
                            case .second(let isLongPressActivated, let dragValue) where isLongPressActivated == true:
                                state = dragValue?.translation ?? .zero
                            default:
                                break
                            }
                        }
                    )
                    // on End sequence
                    .onEnded({ (_) in
                        isScaled = false
                    })
            )
            .animation(.easeInOut)
    }
}

struct HoverGestureDemoView: View {
    
    var body: some View {
        Text("Hello")
            .padding(50)
            .background(Color.red)
            .cornerRadius(4)
            .hoverEffect(.highlight)
            .onHover(perform: { hovering in
                print("hower event triggered")
            })
    }
}

struct MagnificationGestureDemoView: View {
    @GestureState private var scaleAmount: CGFloat = 1
    
    var body: some View {
        Text("Hello")
            .padding(50)
            .background(Color.red)
            .cornerRadius(4)
            .scaleEffect(scaleAmount)
            .gesture(
                MagnificationGesture()
                    .updating(
                        $scaleAmount,
                        body: { (value, state, transition) in
                            state = value
                        }
                    )
            )
            .animation(.easeInOut)
    }
}

struct RotationGestureDemoView: View {
    @GestureState private var rotationAngle: Angle = .zero
    
    var body: some View {
        Text("Hello")
            .padding(50)
            .background(Color.red)
            .cornerRadius(4)
            .hueRotation(rotationAngle)
            .gesture(
                RotationGesture()
                    .updating(
                        $rotationAngle,
                        body: { (value, state, transition) in
                            state = Angle(degrees: value.degrees)
                        }
                    )
            )
            .animation(.easeInOut)
    }
}


struct DragGestureDemoView: View {
    @GestureState private var dragTranslation: CGSize = .zero
    
    var body: some View {
        Text("Hello")
            .padding()
            .cornerRadius(4)
            .offset(x: dragTranslation.width, y: dragTranslation.height)
            .gesture(
                DragGesture()
                    .updating(
                        $dragTranslation,
                        body: { (value, state, transition) in
                            state = value.translation
                        }
                    )
            )
            .animation(.easeInOut)
    }
}

struct LongPressGestureDemoView: View {
    @GestureState private var isLongPressActivated: Bool = false
    @State private var tapCount: Int = 0
    
    var body: some View {
        Text("Hello \(tapCount)")
            .padding()
            .background(isLongPressActivated ? Color.red : Color.green)
            .cornerRadius(4)
            // .animation(.easeInOut) // animate all changes
            .gesture(
                LongPressGesture(
                    minimumDuration: 1,
                    maximumDistance: 10
                )
                // SwiftUI invokes the updating callback as soon as it recognizes the gesture and whenever the value of the gesture changes
                .updating(
                    $isLongPressActivated,
                    // currentState - type of Value -> Bool
                    // gestureState - type of @GestureState
                    // transaction - object to pass an animation between views in a view hierarchy. The context of the current state-processing update
                    body: { (currentState, gestureState, transaction) in
                        print("On updating: \(currentState), \(gestureState), \(transaction)")
                        // any transformation from
                        // type of @GestureState to
                        // type of Value -> Bool
                        gestureState = currentState
                        
                        // transaction for gesture
                        transaction.animation = Animation.easeInOut(duration: 1.0)
                    }
                )
                // called when Value changed
                // value - Value -> Bool
                .onChanged({ (value) in
                    print("On changed: \(value)")
                })
                .onEnded({ (value) in
                    tapCount += 1
                    print("On Ended - \(value)")
                })
            )
    }
}


struct TapGestureDemoView: View {
    @State private var tapCount: Int = 0
    
    var body: some View {
        Text("Hello \(tapCount)")
            .gesture(
                TapGesture()
                    .onEnded({ (_) in
                        tapCount += 1
                    })
            )
    }
}


//
//  ContentView.swift
//  testWebViewCommunicationApp
//
//  Created by Kyryl Horbushko on 11/11/24.
//

import SwiftUI
import WebKit
import Combine

/// This define main protocol for communication
/// in bettween app and web. This is just a helper, to reduce typos
/// in the app code-base
enum JSHandleProtocol {
  static let name = "jsHandler"

  enum Func {
    static let soldItem = "markAsSold"

    /// markAsSold(\"\(product)\", \"\(price)\", \"\(id)\")
    static func createSoldJSRequest(
      itemName: String,
      itemPrice: String,
      itemID: String
    ) -> String {
      soldItem + "(\"\(itemName)\", \"\(itemPrice)\", \"\(itemID)\")"
    }
  }

  enum Events {
    enum Params {
      static let username = "username"
      static let password = "password"

      static let price = "price"
      static let id = "id"
      static let itemName = "product"
    }

    static let name = "event"
    static let preparation = "initialization"
    static let saleStarted = "start"
    static let saleCanceled = "cancel"
    static let saleCompleted = "complete"
    static let itemSoldNotification = "sold"
  }
}

final class ContentViewViewModel: ObservableObject {
  enum Page {
    static let login = "login"
    static let product = "product"
  }

  struct SaleProduct {
    let price: String
    let id: String
    let itemName: String

    var numericPriceValue: Double {
      Double(price.replacingOccurrences(of: "$", with: "")) ?? 0
    }

    var description: String {
      "\(itemName), \(price), \(id)"
    }

    static func createFrom(_ msg: [String: Any]) -> Self? {
      if let price = msg[JSHandleProtocol.Events.Params.price] as? String,
         let productID = msg[JSHandleProtocol.Events.Params.id] as? String,
         let product = msg[JSHandleProtocol.Events.Params.itemName] as? String {
        return .init(price: price, id: productID, itemName: product)
      }
      return nil
    }
  }

  @Published var showCompleteButton = false
  @Published var selectedProducts: [SaleProduct] = []

  var selectedProductDisplayMsg: String? {
    if selectedProducts.isEmpty {
      return nil
    }

    let itemsToBuy = selectedProducts.count
    let sum = selectedProducts
      .map({ $0.numericPriceValue })
      .reduce(0, +)
    return "\(itemsToBuy) for $\(sum)"
  }

  let webViewHandle: WebViewJSHandler = .init(handleName: JSHandleProtocol.name)
  private var cancelable: Set<AnyCancellable> = .init()

  init() {
    webViewHandle.communicationChannel
      .sink { action  in

        switch action {
          case .message(let msg):
            if let event = msg[JSHandleProtocol.Events.name] as? String {
              switch event {

                case JSHandleProtocol.Events.preparation:
                  if let userName = msg[JSHandleProtocol.Events.Params.username] as? String,
                     let password = msg[JSHandleProtocol.Events.Params.password] as? String {
                    self.initialize(userName, password: password)
                  }

                case JSHandleProtocol.Events.saleStarted:
                  if let item = SaleProduct.createFrom(msg) {

                    self.onStartPurchaseItem(
                      item: item
                    )
                  }

                case JSHandleProtocol.Events.saleCanceled:
                  if let productID = msg[JSHandleProtocol.Events.Params.id] as? String {
                    self.onCancelSale(for: productID)
                  }

                case JSHandleProtocol.Events.saleCompleted:
                  if let item = SaleProduct.createFrom(msg) {
                    self.onCompletePurchaseItem(item: item)
                  }

                case JSHandleProtocol.Events.itemSoldNotification:
                  if let item = SaleProduct.createFrom(msg) {
                    self.onSOLDItem(item: item)
                  }

                default:
                  break
              }
            }
          case .parameters(let params):
            print("RECEIVED params: \(params)")
          case .unknown(let something):
            print("RECEIVED unexpected: \(something)")
        }
      }
      .store(in: &cancelable)

    try? webViewHandle.load(Page.login, bundle: .main)
  }

  private func initialize(_ userName: String, password: String) {
    try? webViewHandle.load(Page.product, bundle: .main)
  }

  private func onStartPurchaseItem(
    item: SaleProduct
  ) {
    showCompleteButton = true
    selectedProducts.append(item)
  }

  private func onCompletePurchaseItem(
    item: SaleProduct
  ) {
    selectedProducts
      .removeAll(where: { $0.id == item.id })

    webViewHandle.executeSoldJSFor(item: item) { status, response in
      print("completeSale js result - \(status), \(String(describing: response))")

      if self.selectedProducts.isEmpty {
        self.showCompleteButton = false
        self.selectedProducts = []
      }
    }
  }

  private func onCancelSale(for productID: String) {
    selectedProducts
      .removeAll(where: { $0.id == productID })

    if selectedProducts.isEmpty {
      showCompleteButton = false
      selectedProducts = []
    }
  }

  private func onSOLDItem(
    item: SaleProduct
  ) {
    print("completeSALE for - \(item.description)")
  }

  func completeAllSale() {
    for product in selectedProducts {
      print("Sale process completed for product: \(product)")
      webViewHandle.executeSoldJSFor(item: product) { status, response in
        // in real world app u need to handle async states here
        // this code is just for demo
        print("completeSale js result - \(status), \(String(describing: response))")
      }
    }

    showCompleteButton = false
    selectedProducts = []
  }
}

fileprivate extension WebViewJSHandler {

  func executeSoldJSFor(
    item: ContentViewViewModel.SaleProduct,
    callback: @escaping JSResponse) {
      let js = JSHandleProtocol.Func.createSoldJSRequest(
        itemName: item.itemName,
        itemPrice: item.price,
        itemID: item.id
      )
      self.executeJS(jsString: js, callback: callback)
  }
}

struct ContentView: View {
  @ObservedObject var viewModel = ContentViewViewModel()

  var body: some View {
    VStack {
      WebView(webViewHandle: viewModel.webViewHandle)

      if viewModel.showCompleteButton,
         let product = viewModel.selectedProductDisplayMsg {
        Button(action: viewModel.completeAllSale) {
          Text("Complete Sale for \(product)")
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .padding()
      }
    }
  }
}

struct WebView: UIViewRepresentable {
  let webViewHandle: WebViewJSHandler

  func makeUIView(context: Context) -> WKWebView {
    webViewHandle.webView
  }

  func updateUIView(_ uiView: WKWebView, context: Context) { }
}

#Preview {
  ContentView()
}


//
//struct ContentView: View {
//  @ObservedObject var viewModel = ContentViewViewModel()
//
//  var body: some View {
//    VStack {
//      WebView(showCompleteButton: $showCompleteButton, selectedProduct: $selectedProduct, onReceiveEvent: registerCredentials, actionPublisher: actionPublisher)
//      if showCompleteButton, let product = selectedProduct {
//        Button(action: completeSale) {
//          Text("Complete Sale for \(product)")
//            .padding()
//            .frame(maxWidth: .infinity)
//            .background(Color.blue)
//            .foregroundColor(.white)
//            .cornerRadius(10)
//        }
//        .padding()
//      }
//    }
//  }
//
//  func completeSale() {
//    print("Sale process completed for product: \(selectedProduct ?? "Unknown")")
//    showCompleteButton = false
//    selectedProduct = nil
//
//    actionPublisher.send(.completeSale)
//  }
//
//  func registerCredentials() {
//    print("Credentials received by native app")
//    actionPublisher.send(.credentialsReceived)
//
//
//  }
//}
//
//struct WebView: UIViewRepresentable {
//  @Binding var showCompleteButton: Bool
//  @Binding var selectedProduct: String?
//
//  let onReceiveEvent: () -> Void
//  let actionPublisher: any Publisher<Action, Never>
//
//  enum Action {
//    case credentialsReceived
//    case completeSale
//  }
//
//  func makeCoordinator() -> Coordinator {
//    Coordinator(self)
//  }
//
//  func complete() {
//  }
//
//  func makeUIView(context: Context) -> WKWebView {
//    let webView = WKWebView()
//    webView.navigationDelegate = context.coordinator
//    webView.configuration.userContentController.add(context.coordinator, name: "jsHandler")
//
//    print("INIT ------")
//    if let localHTML = Bundle.main.url(forResource: "login", withExtension: "html") {
//      webView.loadFileURL(localHTML, allowingReadAccessTo: localHTML)
//    }
//
//    context.coordinator.actionSubscriber = actionPublisher
//      .sink { action in
//        switch action {
//          case .credentialsReceived:
//            if let localHTML = Bundle.main.url(forResource: "product", withExtension: "html") {
//              webView.loadFileURL(localHTML, allowingReadAccessTo: localHTML)
//            }
//          case .completeSale:
//            let js = "markAsSold(\"productName\", \"price\", \"1\")"
//            webView.evaluateJavaScript(js, completionHandler: nil)
//        }
//      }
//
//    return webView
//  }
//
//  func updateUIView(_ uiView: WKWebView, context: Context) { }
//
//  class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
//    var parent: WebView
//    var actionSubscriber: Cancellable?
//
//    init(_ parent: WebView) {
//      self.parent = parent
//    }
//
//    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
//      if message.name == "jsHandler",
//         let messageBody = message.body as? [String: Any] {
//
//        print("RAW: \(messageBody)")
//
//        if let action = messageBody["action"] as? String {
//
//          if let productName = messageBody["product"] as? String,
//             let price = messageBody["price"] as? String,
//             let elementID = messageBody["id"] as? String {
//            print("Received action \(action): \(productName), price: \(price)")
//
//            if action == "start" {
//              // Notify the web view to update UI for "Complete" and "Cancel" buttons
//              print("Execute start purchase ")
//              let js = "startPurchaseWithButtons(\"\(productName)\")"
//              message.webView?.evaluateJavaScript(js, completionHandler: nil)
//              self.parent.selectedProduct = productName
//              self.parent.showCompleteButton = true
//
//            } else if action == "complete" {
//              print("Execute SOLD ")
//              let js = "markAsSold(\"\(productName)\", \"\(price)\", \"\(elementID)\")"
//              message.webView?.evaluateJavaScript(js, completionHandler: nil)
//              self.parent.showCompleteButton = false
//              self.parent.selectedProduct = nil
//            }
//          }
//
//          if action == "cancel" || action == "sold" {
//            print("Received action \(action)")
//            //            DispatchQueue.main.async {
//            self.parent.showCompleteButton = false
//            self.parent.selectedProduct = nil
//
//            //            }
//
//          }
//        }
//
//        if let username = messageBody["username"] as? String,
//           let password = messageBody["password"] as? String {
//          print("PROCESSING username: \(username), password: \(password)")
//
//          self.parent.onReceiveEvent()
//
//          // Handle username and password here, e.g., authenticate user
//        }
//      }
//    }
//  }
//}
//
//
//#Preview {
//  ContentView()
//}


//struct SwiftUIWebView: UIViewRepresentable {
//  let urlRequest: URLRequest
//  func makeCoordinator() -> Coordinator {
//    Coordinator(self)
//  }
//
//  func makeUIView(context: Context) -> WKWebView {
//    let webView = WKWebView()
//    webView.load(urlRequest)
//    return webView
//  }
//
//  func updateUIView(_ uiView: WKWebView, context: Context) { }
//
//  final class Coordinator: NSObject {
//    var parent: SwiftUIWebView
//
//    init(_ parent: SwiftUIWebView) {
//      self.parent = parent
//
//      /// do whatever you needed with WebView
//    }
//  }
//}

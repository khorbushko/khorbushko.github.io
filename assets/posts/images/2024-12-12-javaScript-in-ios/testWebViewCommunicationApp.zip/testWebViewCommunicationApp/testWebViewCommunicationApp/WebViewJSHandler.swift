//
//  WebViewHandler.swift
//  testWebViewCommunicationApp
//
//  Created by Kyryl Horbushko on 12/12/24.
//

import Foundation
@preconcurrency import WebKit
import Combine

public typealias JSResponse = (_ status: Bool, _ response: Any?) -> Void

final public class WebViewJSHandler: NSObject {
  public enum Failure: Error {
    case incorrectURLString
  }

  public enum Event {
    case message([String: Any])
    case parameters([String: Any])
    case unknown(Any)
  }

  
  public struct JSFunc {
    public let functionString: String
    public let callback: JSResponse

    public static func make(
      with jsString: String,
      callback: @escaping JSResponse
    ) -> JSFunc {
      JSFunc(functionString: jsString, callback: callback)
    }
  }

  public private(set) var webView: WKWebView!
  public private(set) var handleName: String!
  public let communicationChannel: PassthroughSubject<WebViewJSHandler.Event, Never> = .init()
  private var pageLoaded = false
  private var pendingFunctions: [JSFunc] = []

  public convenience init(
    handleName: String,
    webView: WKWebView = WKWebView()
  ) {
    self.init()

    self.handleName = handleName
    self.webView = webView

#if DEBUG
    self.webView.isInspectable = true
#endif

    webView.configuration.userContentController
      .add(self, name: handleName)
    webView.navigationDelegate = self
  }

  public override init() {
    super.init()
  }

  public func executeJS(jsString: String, callback: @escaping JSResponse) {
    let jsFunc = JSFunc.make(with: jsString, callback: callback)

    if pageLoaded {
      runJS(jsFunc)
    } else {
      addFunction(jsFunc)
    }
  }

  public func load(_ fileName: String, bundle: Bundle) throws {
    if let localHTML = bundle.url(forResource: fileName, withExtension: "html") {
      pageLoaded = false

      webView.loadFileURL(localHTML, allowingReadAccessTo: localHTML)
    } else {
      throw WebViewJSHandler.Failure.incorrectURLString
    }
  }

  public func load(_ request: String) throws {
    if let url = URL(string: request) {
      pageLoaded = false

      let urlRequest = URLRequest(url: url)
      webView.load(urlRequest)
    } else {
      throw WebViewJSHandler.Failure.incorrectURLString
    }
  }

  public func load(_ request: URLRequest) {
    pageLoaded = false

    webView.load(request)
  }

  // MARK: - Private functions

  private func addFunction(_ function: JSFunc) {
    pendingFunctions.append(function)
  }

  private func runJS(_ function: JSFunc) {
    webView.evaluateJavaScript(function.functionString) { response, error in
      if let error = error {
        function.callback(false, error)
      } else {
        function.callback(true, response)
      }
    }
  }

  private func callPendingFunctions() {
    for function in pendingFunctions {
      runJS(function)
    }
    pendingFunctions.removeAll()
  }
}

// MARK: - WKNavigationDelegate

extension WebViewJSHandler: WKNavigationDelegate {
  public func webView(
    _ webView: WKWebView,
    didFinish navigation: WKNavigation
  ) {
    pageLoaded = true
    callPendingFunctions()
  }

  public func webView(
    _ webView: WKWebView,
    decidePolicyFor navigationAction: WKNavigationAction,
    decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
  ) {
    if let urlString = navigationAction.request.url?.absoluteString,
       urlString.starts(with: handleName) {
      let values = urlString.parseParametersFromUrlString()
      communicationChannel.send(.parameters(values))
    }

    decisionHandler(.allow)
  }
}

extension WebViewJSHandler: WKScriptMessageHandler {

  // MARK: - WKScriptMessageHandler

  public func userContentController(
    _ userContentController: WKUserContentController,
    didReceive message: WKScriptMessage
  ) {

    if message.name == handleName {
      if let body = message.body as? [String: Any] {
        communicationChannel.send(.message(body))
      } else if let bodyString = message.body as? String {
        let values = bodyString.parseParametersFromUrlString()
        communicationChannel.send(.parameters(values))
      } else {
        communicationChannel.send(.unknown(message.body))
      }
    }
  }
}

fileprivate extension String {

  // MARK: String+ParseURLParams

  func parseParametersFromUrlString() -> [String: Any] {
    var parameters:[String: Any] = [: ]

    if let convertedString = self.removingPercentEncoding {
      URLComponents(string: convertedString)?.queryItems?
        .compactMap({ $0 })
        .forEach({
          parameters[$0.name] = $0.value
        })
    }

    return parameters
  }
}

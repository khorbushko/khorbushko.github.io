//
//  testWebViewCommunicationAppApp.swift
//  testWebViewCommunicationApp
//
//  Created by Kyryl Horbushko on 12/11/24.
//

import SwiftUI

@main
struct testWebViewCommunicationAppApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}

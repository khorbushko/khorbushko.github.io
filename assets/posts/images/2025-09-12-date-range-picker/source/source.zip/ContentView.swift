import Foundation
import SwiftUI

struct DateComponentPicker: View {
    enum PickerMode {
        case yearOnly
        case yearAndMonth
    }

    @Binding var selectedDate: Date
    let mode: PickerMode
    let yearRange: ClosedRange<Int>

    private let monthFormatter: DateFormatter = {
        ValueFormatter.monthFormatter
    }()

    private var currentYear: Int {
        Calendar.current.component(.year, from: Date())
    }

    private var currentMonth: Int {
        Calendar.current.component(.month, from: Date())
    }

    private var monthNames: [String] {
        let selectedYear = Calendar.current.component(.year, from: selectedDate)
        let maxMonth = (selectedYear == currentYear) ? currentMonth : 12

        return (1...maxMonth)
            .compactMap { month in
                guard let date = Calendar.current.date(from: DateComponents(month: month)) else {
                    return nil
                }
                return monthFormatter.string(from: date)
            }
    }

    init(
        selection: Binding<Date>,
        mode: PickerMode = .yearOnly,
        yearRange: ClosedRange<Int> = 1900...2060
    ) {
        self._selectedDate = selection
        self.mode = mode

        let todayYear = Calendar.current.component(.year, from: Date())
        self.yearRange = yearRange.clamped(to: yearRange.lowerBound...todayYear)

        adjustDateIfNeeded()
    }

    var body: some View {
        HStack(spacing: 0) {
            if mode == .yearAndMonth {
                monthPicker
                    .frame(maxWidth: .infinity)
            }
            yearPicker
                .frame(maxWidth: .infinity)
        }
        .padding(.horizontal)
    }

    private var yearPicker: some View {
        Picker("Year", selection: Binding(
            get: {
                Calendar.current.component(.year, from: selectedDate)
            },
            set: {
                updateDate(year: $0)
            }
        )) {
            ForEach(yearRange, id: \.self) { year in
                Text(displayYear(year: year))
                    .tag(year)
            }
        }
        .pickerStyle(WheelPickerStyle())
        .frame(height: 350)
        .colorScheme(.dark)
    }

    private var monthPicker: some View {
        Picker("Month", selection: Binding(
            get: {
                min(Calendar.current.component(.month, from: selectedDate), currentMonthIfNeeded())
            },
            set: {
                updateDate(month: $0)
            }
        )) {
            ForEach(Array(monthNames.enumerated()), id: \.offset) { index, monthName in
                Text(monthName)
                    .tag(index + 1)
            }
        }
        .pickerStyle(WheelPickerStyle())
        .colorScheme(.dark)
        .frame(height: 350)
    }

    private func adjustDateIfNeeded() {
        let year = Calendar.current.component(.year, from: selectedDate)
        let adjustedYear = min(max(year, yearRange.lowerBound), yearRange.upperBound)

        var adjustedMonth = Calendar.current.component(.month, from: selectedDate)
        if adjustedYear == currentYear {
            adjustedMonth = min(adjustedMonth, currentMonth)
        }

        updateDate(year: adjustedYear, month: adjustedMonth)
    }

    private func updateDate(
        year: Int? = nil,
        month: Int? = nil
    ) {
        var components = Calendar.current.dateComponents(
            [
                .year,
                .month,
                .day,
                .hour,
                .minute,
                .second,
                .nanosecond,
                .timeZone
            ],
            from: selectedDate
        )

        if let year = year {
            components.year = year
        }
        if let month = month {
            components.month = month
            if let day = components.day,
               let newDate = Calendar.current.date(from: components),
               let range = Calendar.current.range(of: .day, in: .month, for: newDate) {
                components.day = min(day, range.count)
            }
        }

        if let newDate = Calendar.current.date(from: components) {
            Task {
                await MainActor.run {
                    selectedDate = newDate
                }
            }
        }
    }

    private func currentMonthIfNeeded() -> Int {
        let selectedYear = Calendar.current.component(.year, from: selectedDate)
        return selectedYear == currentYear ? currentMonth : 12
    }

    private func displayYear(year: Int) -> String {
        let formatter = NumberFormatter()
        formatter.usesGroupingSeparator = false
        return formatter.string(from: NSNumber(value: year)) ?? "\(year)"
    }
}

#Preview {

    struct DemoView: View {
        @State var date: Date = .now
        @State var isShown: Bool = false

        var body: some View {
            VStack {
                Button("Press me") {
                    isShown = true
                }
            }
            .popover(isPresented: $isShown, content: {
                DateComponentPicker(
                    selection: $date,
                    mode: .yearAndMonth
                )
            })
        }
    }

    return DemoView()

}

import Foundation
import SwiftUI
import Observation

struct RangeDatePickerView: View {
    @Environment(\.calendar) var calendar
    @Binding var dates: Set<DateComponents>
    @State private var previousDates: Set<DateComponents> = []
    private let datePickerComponents: Set<Calendar.Component> = [
        .calendar,
        .era,
        .year,
        .month,
        .day
    ]

    let showHint: Bool
    let minimumIntervalDays: Int
    let supportedDateRange: Range<Date>
    let onDateSelected: (([Date]) -> Void)?

    var datesBinding: Binding<Set<DateComponents>> {
        Binding {
            dates
        } set: { newValue in
            if newValue.isEmpty {
                dates = newValue
                previousDates = newValue
            } else if newValue.count > dates.count {
                if newValue.count == 1 {
                    dates = newValue
                    previousDates = newValue
                } else if newValue.count == 2 {
                    if isValidRange(selectedDates: newValue) {
                        dates = filledRange(selectedDates: newValue)
                        previousDates = newValue
                    } else {
                        if let newlyAddedDate = getNewlyAddedDate(from: dates, newSet: newValue) {
                            dates = [newlyAddedDate]
                            previousDates = [newlyAddedDate]
                        }
                    }
                } else if let firstMissingDate = newValue.subtracting(dates).first {
                    dates = [firstMissingDate]
                    previousDates = [firstMissingDate]
                } else {
                    dates = []
                    previousDates = []
                }
            } else if let firstMissingDate = dates.subtracting(newValue).first {
                dates = [firstMissingDate]
                previousDates = [firstMissingDate]
            } else {
                dates = []
                previousDates = []
            }
        }
    }

    var body: some View {
        VStack(spacing: 50) {
            MultiDatePicker(
                "",
                selection: datesBinding,
                in: supportedDateRange
            )
            .datePickerStyle(.graphical)
            .frame(height: 300)
            .tint(Color.green)
            .colorScheme(.dark)

            Text("Minimum range: \(minimumIntervalDays) days")
                .font(Font.subheadline)
                .italic()
                .foregroundColor(Color.white)
                .opacity(showHint ? 1 : 0)
        }
        .onChange(of: dates, perform: { newValue in
            let dates = newValue
                .compactMap { calendar.date(from: $0) }
                .sorted()
            if dates.count >= minimumIntervalDays {
                onDateSelected?(dates)
            }
        })
        .padding()
        .background(Color.clear)
    }

    private func filledRange(
        selectedDates: Set<DateComponents>
    ) -> Set<DateComponents> {
        let allDates = selectedDates
            .compactMap {
                calendar.date(from: $0)
            }
        let sortedDates = allDates.sorted()
        var datesToAdd = [DateComponents]()
        if let first = sortedDates.first,
           let last = sortedDates.last {
            var date = first
            while date < last {
                if let nextDate = calendar
                    .date(byAdding: .day, value: 1, to: date) {
                    if !sortedDates.contains(nextDate) {
                        let dateComponents = calendar
                            .dateComponents(datePickerComponents, from: nextDate)
                        datesToAdd.append(dateComponents)
                    }
                    date = nextDate
                } else {
                    break
                }
            }
        }
        return selectedDates.union(datesToAdd)
    }

    private func isValidRange(
        selectedDates: Set<DateComponents>
    ) -> Bool {
        let dates = selectedDates
            .compactMap {
                calendar.date(from: $0)
            }
            .sorted()

        guard dates.count == 2,
              let startDate = dates.first,
              let endDate = dates.last else {
            return false
        }

        let isSelectedPeriodInAllowedRange = startDate > supportedDateRange.lowerBound && endDate < supportedDateRange.upperBound

        let daysDifference = calendar.dateComponents(
            [.day],
            from: startDate,
            to: endDate)
            .day ?? 0
        let totalDaysInRange = abs(daysDifference) + 1
        let minimumLengthForPeriodIsCorrect = totalDaysInRange >= minimumIntervalDays
        return minimumLengthForPeriodIsCorrect && isSelectedPeriodInAllowedRange
    }

    private func getNewlyAddedDate(
        from oldSet: Set<DateComponents>,
        newSet: Set<DateComponents>
    ) -> DateComponents? {
        newSet.subtracting(oldSet).first
    }
}

#Preview {
    struct DemoView: View {
        @State private var customRangeSelectedDates: [Date] = []
        @State private var customRangePickDates: Set<DateComponents> = []
        var inDateRange: Range<Date> = {
            let components = DateComponents(year: 2000, month: 1, day: 1)
            let minDate = Calendar.current.date(from: components)
            ?? Date(timeIntervalSince1970: 0)
            return minDate..<Date.now
        }()

        var body: some View {
            RangeDatePickerView(
                dates: $customRangePickDates,
                showHint: true,
                minimumIntervalDays: 2,
                supportedDateRange: inDateRange,
                onDateSelected: { dates in
                    customRangeSelectedDates = dates
                })
        }
    }

    return DemoView()
}

import SwiftUI

struct SegmentDateRangePickerView: View {

    private enum Constants {
        static let endIntervalDate = Date.now
        static let startIntervalDate = Calendar.current
            .date(byAdding: .day, value: -6, to: endIntervalDate)
        ?? endIntervalDate
    }

    enum Interval: Equatable {
        struct Period: Equatable {
            let start: Date
            let end: Date

            var range: [Date] {
                start.datesInBetweenTo(end)
            }
        }
        case week(Period)
        case month(Date)
        case year(Date)
        case custom(Period)

        static let weekNow: Interval = .week(
            .init(
                start: Constants.startIntervalDate,
                end: Constants.endIntervalDate
            ))

        var yearRepresentationRange: [Date] {
            switch self {
                case .year(let date):
                    return date.firstDaysOfYearUntilMonth()
                default:
                    return []
            }
        }

        var monthRepresentationRange: [Date] {
            switch self {
                case .month(let date):
                    return date.monthDaysRespectingToday()
                default:
                    return []
            }
        }

        var start: Date {
            switch self {
                case .week(let period):
                    return period.start
                case .month(let date):
                    return date
                case .year(let date):
                    return date
                case .custom(let period):
                    return period.start
            }
        }

        var end: Date {
            switch self {
                case .week(let period):
                    return period.end
                case .month(let date):
                    return date
                case .year(let date):
                    return date
                case .custom(let period):
                    return period.end
            }
        }
    }

    @State private var weekPickDate = Constants.startIntervalDate
    @State private var monthPickDate = Constants.endIntervalDate
    @State private var yearPickDate = Constants.endIntervalDate
    @State private var customRangeSelectedDates: [Date] = []
    @State private var customRangePickDates: Set<DateComponents> = []
    @State private var prevCustomRangePickDates: Set<DateComponents> = []

    @State private var segmentInterval: CalendarInterval = .week
    @State private var dateTitle: String = ""

    @State private var isSaveAction: Bool = false
    @State private var showDatePicker: Bool = false

    @Binding var interval: Interval

    private let tintColor = Color.white
    private let titleFont = Font.headline
    private let backgroundColor = Color.secondary
    private let actionTint = Color.white
    private let pickerTint = Color.green

    var minimumIntervalDays: Int = 2
    var showHintMessage: Bool = true
    var inDateRange: Range<Date> = {
        let components = DateComponents(year: 2000, month: 1, day: 1)
        let minDate = Calendar.current.date(from: components)
        ?? Date(timeIntervalSince1970: 0)
        return minDate..<Date.now
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            SegmentPicker(selectedSegment: $segmentInterval)

            HStack {
                Text(dateTitle)
                    .font(titleFont)
                    .foregroundColor(tintColor)

                Spacer()

                Image(systemName: "calendar")
                    .renderingMode(.template)
                    .foregroundColor(tintColor)
                    .padding(8)
            }
            .contentShape(Rectangle())
            .onTapGesture {
                withAnimation {
                    prevCustomRangePickDates = customRangePickDates

                    isSaveAction = false
                    showDatePicker.toggle()
                }
            }
            .padding()
            .sheet(isPresented: $showDatePicker, onDismiss: {
                if !isSaveAction {
                    customRangePickDates = prevCustomRangePickDates
                }
            }) {
                datePicker
            }
            .onAppear(perform: initialDataPropagation)
            .onChange(of: segmentInterval) { newValue in
                switch newValue {
                    case .week:
                        updateWeekPeriod()
                    case .month:
                        updateMonthPeriod()
                    case .year:
                        updateYearPeriod()
                    case .custom:
                        updateCustomPeriod()
                }

                updateTitle()
            }
        }
    }

    @ViewBuilder
    private var datePicker: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 10)
            HStack {
                Spacer()
                Button("Save") {
                    Task {
                        switch interval {
                            case .week:
                                updateWeekPeriod()
                            case .month:
                                updateMonthPeriod()
                            case .year:
                                updateYearPeriod()
                            case .custom:
                                customRangePickDates = customRangeSelectedDates.toDateComponentsSet()
                                prevCustomRangePickDates = []

                                updateCustomPeriod()
                        }

                        updateTitle()

                        isSaveAction = true
                        showDatePicker.toggle()
                    }
                }
                .tint(actionTint)
            }

            buildDatePickerView()
            Spacer()
        }
        .padding()
        .presentationDetents([.medium, .fraction(0.6)])
        .background(backgroundColor)
    }

    private func buildDatePickerView() -> some View {
        Group {
            switch segmentInterval {
                case .week:
                    weekPickerView
                case .custom:
                    customDatePicker
                case .month:
                    monthDatePicker
                case .year:
                    yearDatePicker
            }
        }
        .id(segmentInterval)
    }

    private var weekPickerView: some View {
        VStack {
            DatePicker(
                "",
                selection: $weekPickDate,
                in: inDateRange.lowerBound...inDateRange.upperBound,
                displayedComponents: [.date]
            )
            .datePickerStyle(.graphical)
            .tint(pickerTint)
            .colorScheme(.dark)
        }
    }
    private var monthDatePicker: some View {
        VStack {
            DateComponentPicker(
                selection: $monthPickDate,
                mode: .yearAndMonth
            )
        }
    }

    private var yearDatePicker: some View {
        VStack {
            DateComponentPicker(
                selection: $yearPickDate,
                mode: .yearOnly,
                yearRange: inDateRange.lowerBound.year()...Date.now.year()
            )
        }
    }

    private var customDatePicker: some View {
        RangeDatePickerView(
            dates: $customRangePickDates,
            showHint: showHintMessage,
            minimumIntervalDays: minimumIntervalDays,
            supportedDateRange: inDateRange,
            onDateSelected: { dates in
                customRangeSelectedDates = dates
            })
    }

    private func updateWeekPeriod() {
        let dates = weekPickDate.next7Days(trimFuture: true)
            .sorted()
        if let start = dates.first,
           let end = dates.last {
            interval = .week(.init(start: start, end: end))
        }
    }

    private func updateMonthPeriod() {
        interval = .month(monthPickDate)
    }

    private func updateYearPeriod() {
        interval = .year(yearPickDate)
    }

    private func updateCustomPeriod() {
        let periodDates = customRangePickDates
            .sortedDates()
        if let start = periodDates.first,
           let end = periodDates.last {
            interval = .custom(.init(start: start, end: end))
        }
    }

    private func updateTitle() {
        dateTitle = periodTitle(from: interval)
    }

    private func initialDataPropagation() {
        updateTitle()
        customRangePickDates = Constants.startIntervalDate.next7Days(trimFuture: true)
            .toDateComponentsSet()
    }

    private func periodTitle(from dateInterval: Interval) -> String {
        switch dateInterval {
            case .week(let weekRange):
                return "\(ValueFormatter.formatShorterDate(weekRange.start)) - \(ValueFormatter.formatShorterDate(weekRange.end))"
            case .custom(let customRange):
                return "\(ValueFormatter.formatShorterDate(customRange.start)) - \(ValueFormatter.formatShorterDate(customRange.end))"

            case .month(let date):
                return "\(ValueFormatter.shortMonthYearFormatter.string(from: date))"
            case .year(let date):
                return "\(ValueFormatter.shortYearFormatter.string(from: date))"
        }
    }
}

fileprivate extension Set where Element == DateComponents {
    func sortedDates() -> [Date] {
        let calendar = Calendar.current
        let sortedDates = self
            .compactMap { calendar.date(from: $0) }
            .sorted()
        return sortedDates
    }
}

fileprivate extension Array where Element == Date {
    func toDateComponentsSet(
        components: Set<Calendar.Component> = [.year, .month, .day],
        using calendar: Calendar = .current
    ) -> Set<DateComponents> {
        Set(self.map { calendar.dateComponents(components, from: $0) })
    }
}

enum ValueFormatter {

    static let shortDateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd, yyyy"
        return formatter
    }()
    static let shortDateNoYearFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd"
        return formatter
    }()
    static let dateNoYearFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM dd"
        return formatter
    }()
    static let shortMonthYearFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM yyyy"
        return formatter
    }()
    static let shortYearFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy"
        return formatter
    }()
    static let monthFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM"
        return formatter
    }()
    static func formatShorterDate(_ date: Date) -> String {
        let formatter = date.year() == Date.now.year() ? shortDateNoYearFormatter : shortDateFormatter

        return formatter.string(from: date)
    }
}

extension Date {

    func year() -> Int {
        Calendar.current.component(.year, from: self)
    }

    func datesInBetweenTo(_ endDate: Date) -> [Date] {
        let calendar = Calendar.current
        let normalizedStart = calendar.startOfDay(for: self)
        let normalizedEnd = calendar.startOfDay(for: endDate)

        guard normalizedStart <= normalizedEnd else {
            return []
        }

        if let numberOfDays = calendar
            .dateComponents([.day], from: normalizedStart, to: normalizedEnd)
            .day {
            return (0..<(numberOfDays+1))
                .compactMap { dayOffset in
                    calendar.date(byAdding: .day, value: dayOffset, to: normalizedStart)
                }
        } else {
            return []
        }
    }

    /// Returns all the days of selected week (Gregorian week).
    /// - If week is current → from Mon until today (inclusive).
    /// - If week is past → all days for week (Mon–Sun).
    /// - Parameters:
    ///   - fullWeek: If true → return full week (Mon–Sun). If false → from Mon until the selected date.
    ///   - trimFuture: If true → cut off any dates beyond today.
    func dateWeekDates(fullWeek: Bool = false, trimFuture: Bool = false) -> [Date] {
        var calendar = Calendar.current
        let gregorianWeekStart = 2 // Monday is start of the week in Ukraine
        calendar.firstWeekday = gregorianWeekStart

        let components = calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: self)
        guard let weekStart = calendar.date(from: components) else {
            return []
        }

        let startOfWeek = calendar.startOfDay(for: weekStart)
        let endOfSelected = calendar.startOfDay(for: self)
        let today = calendar.startOfDay(for: Date())

        var days: [Date] = []
        var current = startOfWeek

        if fullWeek {
            for _ in 0..<7 {
                if trimFuture && current > today { break }
                days.append(current)
                guard let next = calendar.date(byAdding: .day, value: 1, to: current) else { break }
                current = next
            }
        } else {
            while current <= endOfSelected {
                if trimFuture && current > today { break }
                days.append(current)
                guard let next = calendar.date(byAdding: .day, value: 1, to: current) else { break }
                current = next
            }
        }

        return days
    }

    /// Returns all the 1st days of each month.
    /// - If year is current → from January until current month (inclusive).
    /// - If year is past → all months (Jan–Dec).
    /// - If year is future → from January until current month (inclusive).
    func firstDaysOfYearUntilMonth() -> [Date] {
        let calendar = Calendar.current
        let today = Date()

        let targetYear = calendar.component(.year, from: self)
        let currentYear = calendar.component(.year, from: today)
        let currentMonth = calendar.component(.month, from: today)

        let endMonth: Int
        if targetYear < currentYear {
            endMonth = 12
        } else {
            endMonth = currentMonth
        }

        var dates: [Date] = []

        for month in 1...endMonth {
            var components = DateComponents()
            components.year = targetYear
            components.month = month
            components.day = 1

            if let firstDay = calendar.date(from: components) {
                dates.append(firstDay)
            }
        }

        return dates
    }

    /// Returns days of the month for the given date.
    /// - If month < current month → full month.
    /// - If month == current or future month → from 1st until today.
    func monthDaysRespectingToday() -> [Date] {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let targetDay = calendar.startOfDay(for: self)

        let targetComponents = calendar.dateComponents([.year, .month], from: targetDay)
        let todayComponents = calendar.dateComponents([.year, .month], from: today)

        guard let targetYear = targetComponents.year,
              let targetMonth = targetComponents.month,
              let todayYear = todayComponents.year,
              let todayMonth = todayComponents.month else {
            return []
        }

        var firstComponents = targetComponents
        firstComponents.day = 1
        guard let firstDayOfMonth = calendar.date(from: firstComponents) else {
            return []
        }

        guard let range = calendar.range(of: .day, in: .month, for: firstDayOfMonth),
              let lastDayOfMonth = calendar.date(byAdding: .day, value: range.count - 1, to: firstDayOfMonth) else {
            return []
        }

        let cutoff: Date
        if (targetYear < todayYear) || (targetYear == todayYear && targetMonth < todayMonth) {
            cutoff = lastDayOfMonth
        } else {
            cutoff = today
        }

        var days: [Date] = []
        var current = firstDayOfMonth
        while current <= cutoff {
            days.append(current)
            guard let next = calendar.date(byAdding: .day, value: 1, to: current) else { break }
            current = next
        }

        return days
    }

    var isToday: Bool {
        Calendar.current.isDateInToday(self)
    }

    /// Returns 6 previous days plus the current day (total 7 days).
    func last7Days() -> [Date] {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: self)

        var days: [Date] = []

        for offset in (-6...0) {
            if let date = calendar.date(byAdding: .day, value: offset, to: today) {
                days.append(date)
            }
        }

        return days
    }

    /// Returns current date + next 6 days (7 total).
    /// - Parameter trimFuture: If true, dates after today are trimmed.
    func next7Days(trimFuture: Bool = false) -> [Date] {
        let calendar = Calendar.current
        let startDate = calendar.startOfDay(for: self)
        let today = calendar.startOfDay(for: Date())

        var days: [Date] = []

        for offset in 0...6 {
            guard let date = calendar
                .date(byAdding: .day, value: offset, to: startDate) else {
                continue
            }
            if trimFuture && date > today {
                break
            }
            days.append(date)
        }

        return days
    }
}


enum CalendarInterval: String, SegmentPickerElement {
    case week, month, year, custom
}

protocol SegmentPickerElement: Hashable, Identifiable, CaseIterable {

    var id: String { get }
    var title: String? { get }
}

extension SegmentPickerElement
    where Self: RawRepresentable, RawValue == String {
    var id: String {
        rawValue
    }
    var title: String? {
        rawValue.capitalized
    }
}

struct SegmentPicker<T: SegmentPickerElement>: View {
    @Binding var selectedSegment: T
    @Namespace private var animationNamespace

    var body: some View {
        container
            .background(Color.secondary.opacity(0.5))
            .cornerRadius(9)
            .frame(maxWidth: .infinity)
    }

    private var container: some View {
        HStack(spacing: 6) {
            ForEach(Array(T.allCases)) { segment in
                segmentButton(segment)
                if segment != Array(T.allCases).last {
                    Divider()
                        .frame(height: 20)
                        .background(Color.black)
                }
            }
        }
        .padding(4)
        .animation(
            .interactiveSpring(
                response: 0.4,
                dampingFraction: 0.7,
                blendDuration: 0.7
            ),
            value: selectedSegment
        )
    }

    private func segmentButton(_ segment: T) -> some View {
        Text(segment.title ?? "")
            .font(.body)
            .foregroundStyle(
                isSelected(segment)
                ? Color.secondary
                : Color.green
            )
            .frame(height: 28)
            .frame(maxWidth: .infinity)
            .contentShape(Capsule())
            .background {
                if isSelected(segment) {
                    RoundedRectangle(cornerRadius: 7)
                        .fill(Color.green)
                        .matchedGeometryEffect(
                            id: "activeSegment",
                            in: animationNamespace
                        )
                }
            }
            .onTapGesture {
                withAnimation(.snappy) {
                    selectedSegment = segment
                }
            }
    }

    private func isSelected(_ segment: T) -> Bool {
        segment == selectedSegment
    }
}


enum Demo: String, SegmentPickerElement {
    case one
    case two
    case three
}

#Preview {
    
    StatefulPreviewWrapper(Demo.one) { value in
        SegmentPicker(
            selectedSegment: value
        )
        .padding()
    }
}

struct PreviewWrapper: View {
    static let end = Date.now
    static let start = Calendar.current.date(byAdding: .day, value: -6, to: end) ?? end

    @State private var interval: SegmentDateRangePickerView.Interval = .week(.init(start: start, end: end))

    @State private var start: String = ""
    @State private var end: String = ""

    var body: some View {
        VStack {
            SegmentDateRangePickerView(
                interval: $interval
            )
            .padding()
            .background(Color.secondary)

            Spacer()
        }
        .onAppear(perform: {
            start = start.description
            end = end.description
        })
        .onChange(of: interval) {  newValue in
            switch newValue {
                case .year(let date):
                    start = date.description
                    end = date.description
                case .month(let date):
                    start = date.description
                    end = date.description
                case .week(let period):
                    start = period.start.description
                    end = period.end.description
                case .custom(let period):
                    start = period.start.description
                    end = period.end.description
            }
        }
        .background(Color.gray)

        Spacer()
    }
}


import Foundation
import SwiftUI

struct StatefulPreviewWrapper<Value, Content: View>: View {
    @State private var value: Value
    private let content: (Binding<Value>) -> Content

    init(_ value: Value, @ViewBuilder content: @escaping (Binding<Value>) -> Content) {
        _value = State(initialValue: value)
        self.content = content
    }

    var body: some View {
        content($value)
    }
}

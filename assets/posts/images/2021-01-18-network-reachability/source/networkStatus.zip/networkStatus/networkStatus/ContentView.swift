//
//  ContentView.swift
//  networkStatus
//
//  Created by Kyryl Horbushko on 1/18/21.
//

import SwiftUI

final class ViewModel {
    let reachability = NetworkReachability()
    let networkMonitor = NetworkMonitor()
    let ashley = ReachabilityAshley()
    
    init() {
        reachability?.startListening()
        networkMonitor.startListening()
        ashley?.startListening()
    }
    
    deinit {
        reachability?.stopListening()
        networkMonitor.stopListening()
        ashley?.stopListening()
    }
}

struct ContentView: View {
    let viewModel = ViewModel()
    @State private var isNetworkAvailable: Bool = false
    @State private var isNetworkAvailable2: Bool = false
    @State private var isNetworkAvailable3: Bool = false
    
    var body: some View {
        VStack {
            Text("NetworkReachability!")
                .foregroundColor(isNetworkAvailable ? Color.green : Color.red)
                .padding()
            Text("NetworkMonitor!")
                .foregroundColor(isNetworkAvailable2 ? Color.green : Color.red)
                .padding()
            Text("ReachabilityAshley!")
                .foregroundColor(isNetworkAvailable3 ? Color.green : Color.red)
                .padding()
            
        }
        .onReceive(
            (viewModel.reachability?.networkStatusHandler)
                .empty()
                .receive(on: DispatchQueue.main),
            perform: { status in
                switch status {
                case .unknown:
                    isNetworkAvailable = false
                case .notReachable:
                    isNetworkAvailable = false
                case .reachable:
                    isNetworkAvailable = true
                }
            }
        )
        .onReceive(
            viewModel.networkMonitor.networkStatusHandler
                .receive(on: DispatchQueue.main),
            perform: { status in
                // avoid simo update of state variables
                // demo purpose
                DispatchQueue.main.async {
                    switch status {
                    case .unknown:
                        isNetworkAvailable2 = false
                    case .notReachable:
                        isNetworkAvailable2 = false
                    case .reachable:
                        isNetworkAvailable2 = true
                    }
                }
            }
        )
        .onReceive(
            (viewModel.ashley?.networkStatusHandler)
                .empty()
                .receive(on: DispatchQueue.main),
            perform: { status in
                // avoid simo update of state variables
                // demo purpose
                DispatchQueue.main.async {
                    switch status {
                    case .unknown:
                        isNetworkAvailable3 = false
                    case .notReachable:
                        isNetworkAvailable3 = false
                    case .reachable:
                        isNetworkAvailable3 = true
                    }
                }
            }
        )
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// ext

import Combine

extension Optional where Wrapped: Combine.Publisher {
    func empty() -> AnyPublisher<Wrapped.Output, Wrapped.Failure> {
        self?.eraseToAnyPublisher() ?? Empty().eraseToAnyPublisher()
    }
}

//
//  NetworkReachabilityProvider.swift
//
//
//  Created by Kyryl Horbushko on 1/18/21.
//

import Foundation
import Combine

protocol NetworkReachabilityProvider: class {
    var networkStatusHandler: AnyPublisher<NetworkReachabilityStatus, Never> { get }
    
    func stopListening()
    func startListening() -> AnyPublisher<Bool, Never>
}

public enum NetworkReachabilityStatus: Equatable {
    public enum ConnectionType {
        case ethernetOrWiFi
        case wwan
    }
    
    case unknown
    case notReachable
    case reachable(ConnectionType)
}

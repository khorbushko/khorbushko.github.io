//
//  networkStatusApp.swift
//  networkStatus
//
//  Created by Kyryl Horbushko on 1/18/21.
//

import SwiftUI

@main
struct networkStatusApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

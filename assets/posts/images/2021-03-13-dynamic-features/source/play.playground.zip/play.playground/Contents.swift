import Foundation

// AnyKeyPath

final class Bar {
  var foo: Int?
  var fooBar: String?
}

final class Foo {
  var bar: Bar?
}

let barObject = Bar()
barObject.foo = 1
barObject.fooBar = "hello"
let fooObject = Foo()
fooObject.bar = barObject

let fooBarKeyPath: AnyKeyPath = \Foo.bar!
let barFooKeyPath: AnyKeyPath = \Bar.foo

let value1 = barObject[keyPath: fooBarKeyPath]
// return 1

let value2 = fooObject[keyPath: fooBarKeyPath]
// return nil

let appendedKeyPath = fooBarKeyPath.appending(path: barFooKeyPath)
// ReferenceWritableKeyPath<AnotherTestObject, Optional<Int>>

let value3 = fooObject[keyPath: appendedKeyPath!]
// return 1

let anyKeyPathArray = [
  fooBarKeyPath,
  barFooKeyPath
]
// Array<AnyKeyPath>

// static variables

//let anyKeyPathRootValue = AnyKeyPath.rootType
// Fatal error: Method must be overridden: file Swift/KeyPath.swift, line 140

//let anyKeyPathValueType = PartialKeyPath<Bar>.rootType
// Fatal error: Method must be overridden: file Swift/KeyPath.swift, line 140

let concreateKeyPathRootValue = KeyPath<Bar, Int>.rootType
let concreateKeyPathValueType = KeyPath<Bar, Int>.valueType

// PartialKeyPath

let barPaths = [\Bar.foo, \Bar.fooBar]
// [PartialKeyPath<Bar>]

barPaths.forEach { (path) in
  print(barObject[keyPath: path])
}

extension Sequence {
  func transform<T, V>(
    transform byKeyPath: KeyPath<Element, T>,
    block: ((T) -> V)
  ) -> [V] {
    map { (object) -> V in
      block(object[keyPath: byKeyPath])
    }
  }
}

struct FooBar {

  var bar: Int
}

let barsObjects = [
  FooBar(bar: 1),
  FooBar(bar: 2),
  FooBar(bar: 3)
]

let result = barsObjects
  .transform(transform: \FooBar.bar) {
    "\($0)"
  }

print(result)

///

protocol DataExpressible {

}

struct DataInfo<Element>: Collection where Element: DataExpressible {
  typealias Index = Array<Element>.Index

  subscript(position: Index) -> Element {
    components[position]
  }

  let components: [Element]

  var startIndex: Index {
    components.startIndex
  }

  var endIndex: Index {
    components.endIndex
  }

  func index(after i: Index) -> Index {
    components.index(after: i)
  }
}

extension String {

  static var newLine: String { "\n" }
}

extension DataInfo where Element: LocalizedError {

  var log: String {
    [
      description(for: \.errorDescription, separator: .newLine),
      description(for: \.failureReason, separator: .newLine),
      description(for: \.recoverySuggestion, separator: .newLine),
      description(for: \.helpAnchor, separator: .newLine)
    ]
    .compactMap({ $0 })
    .joined(separator: .newLine)
  }

  private func description(for keyPath: KeyPath<Element, String?>, separator: String) -> String {
    components
      .compactMap { $0[keyPath: keyPath] }
      .joined(separator: separator)
  }
}

struct FooError: LocalizedError, DataExpressible {
  private (set) var failureReason: String?

  init(failureReason: String) {
    self.failureReason = failureReason
  }
}

let info = DataInfo(
  components: [
    FooError(failureReason: "reason 1"),
    FooError(failureReason: "reason 2")
  ]
)

let log = info.log
print(log)

// WritableKeyPath

struct Some {

  var variable: Int
}

let someVar = Some(variable: 2)

let someKeyPath = \Some.variable
type(of: someKeyPath)
//someVar[keyPath: someKeyPath] = 2
